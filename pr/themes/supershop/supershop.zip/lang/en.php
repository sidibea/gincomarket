<?php

global $_LANG;
$_LANG = array();
$_LANG['404_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['address_19f823c6453c2b1ffd09cb715214813d'] = 'Required field';
$_LANG['address_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Company';
$_LANG['address_20db0bfeecd8fe60533206a2b5e9891a'] = 'First name';
$_LANG['address_41c2fff4867cc204120f001e7af20f7a'] = 'Mobile phone';
$_LANG['address_46a2a41cc6e552044816a2d04634545d'] = 'State';
$_LANG['address_57d056ed0984166336b7879c2af3657f'] = 'City';
$_LANG['address_59716c97497eb9694541f7c3d37b1a4d'] = 'Country';
$_LANG['address_7cb32e708d6b961d476baced73d362bb'] = 'VAT number';
$_LANG['address_8d3f5eff9c40ee315d452392bed5309b'] = 'Last name';
$_LANG['address_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_LANG['address_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_LANG['address_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['address_fe66abce284ec8589e7d791185b5c442'] = 'Home phone';
$_LANG['addresses_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
$_LANG['addresses_729a51874fe901b092899e9e8b31c97a'] = 'Are you sure?';
$_LANG['addresses_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['addresses_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Add a new address';
$_LANG['addresses_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_LANG['authentication_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Forgot your password?';
$_LANG['authentication_0ba7583639a274c434bbe6ef797115a4'] = 'Register';
$_LANG['authentication_195fbb57ffe7449796d23466085ce6d8'] = 'May';
$_LANG['authentication_19f823c6453c2b1ffd09cb715214813d'] = 'Required field';
$_LANG['authentication_1b539f6f34e8503c97f6d3421346b63c'] = 'July';
$_LANG['authentication_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Company';
$_LANG['authentication_20db0bfeecd8fe60533206a2b5e9891a'] = 'First name';
$_LANG['authentication_3fcf026bbfffb63fb24b8de9d0446949'] = 'April';
$_LANG['authentication_41ba70891fb6f39327d8ccb9b1dafb84'] = 'August';
$_LANG['authentication_41c2fff4867cc204120f001e7af20f7a'] = 'Mobile phone';
$_LANG['authentication_46a2a41cc6e552044816a2d04634545d'] = 'State';
$_LANG['authentication_57d056ed0984166336b7879c2af3657f'] = 'City';
$_LANG['authentication_59716c97497eb9694541f7c3d37b1a4d'] = 'Country';
$_LANG['authentication_659e59f062c75f81259d22786d6c44aa'] = 'February';
$_LANG['authentication_688937ccaf2a2b0c45a1c9bbba09698d'] = 'June';
$_LANG['authentication_7cb32e708d6b961d476baced73d362bb'] = 'VAT number';
$_LANG['authentication_7e823b37564da492ca1629b4732289a8'] = 'November';
$_LANG['authentication_82331503174acbae012b2004f6431fa5'] = 'December';
$_LANG['authentication_86f5978d9b80124f509bdb71786e929e'] = 'January';
$_LANG['authentication_8d3f5eff9c40ee315d452392bed5309b'] = 'Last name';
$_LANG['authentication_b357b524e740bc85b9790a0712d84a30'] = 'Email address';
$_LANG['authentication_b78a3223503896721cca1303f776159b'] = 'Title';
$_LANG['authentication_cc5d90569e1c8313c2b1c2aab1401174'] = 'September';
$_LANG['authentication_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_LANG['authentication_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_LANG['authentication_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['authentication_eca60ae8611369fe28a02e2ab8c5d12e'] = 'October';
$_LANG['authentication_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'March';
$_LANG['authentication_fe66abce284ec8589e7d791185b5c442'] = 'Home phone';
$_LANG['best-sales_3cb29f0ccc5fd220a97df89dafe46290'] = 'Best sellers';
$_LANG['breadcrumb_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['cms_0557fa923dcee4d0f86b1409f5c2167f'] = 'Back';
$_LANG['cms_d3c42ceb9bee8c44815b53f36e496925'] = 'List of subcategories in %s:';
$_LANG['contact-form_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Message';
$_LANG['contact-form_7bc873cba11f035df692c3549366c722'] = '-- Choose --';
$_LANG['contact-form_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['contact-form_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
$_LANG['contact-form_b357b524e740bc85b9790a0712d84a30'] = 'Email address';
$_LANG['contact-form_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_LANG['contact-form_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['discount_29aa46cc3d2677c7e0f216910df600ff'] = 'Free shipping';
$_LANG['discount_689202409e48743b914713f96d93947c'] = 'Value';
$_LANG['discount_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_LANG['discount_6adf97f83acf6453d4a6a4b1070f3754'] = 'None';
$_LANG['discount_8c1279db4db86553e4b9682f78cf500e'] = 'Expiration date';
$_LANG['discount_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['discount_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_LANG['discount_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['discount_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_LANG['discount_befcac0f9644a7abee43e69f49252ac4'] = 'Tax excluded';
$_LANG['discount_ca0dbad92a874b2f69b549293387925e'] = 'Code';
$_LANG['discount_f4a0d7cb0cd45214c8ca5912c970de13'] = 'Tax included';
$_LANG['errors_0557fa923dcee4d0f86b1409f5c2167f'] = 'Back';
$_LANG['guest-tracking_6a1e265f92087bb6dd18194833fe946b'] = 'Email';
$_LANG['guest-tracking_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
$_LANG['guest-tracking_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_LANG['history_0b3db27bc15f682e92ff250ebb167d4b'] = 'Back to your account.';
$_LANG['history_3ec365dd533ddb7ef3d1c111186ce872'] = 'Details';
$_LANG['history_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_LANG['history_466eadd40b3c10580e3ab4e8061161ce'] = 'Invoice';
$_LANG['history_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['history_bcd1b68617759b1dfcff0403a6b5a8d1'] = 'PDF';
$_LANG['history_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Payment';
$_LANG['history_ec53a8c4f07baed5d8825072c89799be'] = 'Status';
$_LANG['identity_19f823c6453c2b1ffd09cb715214813d'] = 'Required field';
$_LANG['identity_20db0bfeecd8fe60533206a2b5e9891a'] = 'First name';
$_LANG['identity_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['identity_8d3f5eff9c40ee315d452392bed5309b'] = 'Last name';
$_LANG['identity_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_LANG['identity_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_LANG['live_edit_79030d996976f29a5e986a42d8f026e5'] = 'Unable to save the module\'s position';
$_LANG['live_edit_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_LANG['live_edit_d3d2e617335f08df83599665eef8a418'] = 'Close';
$_LANG['live_edit_d8dcfab18b3a6eba56d617dd1dcb1ba7'] = 'Close LiveEdit';
$_LANG['live_edit_da87eac3848a0d55560bdd129a0e134b'] = 'Unable to unregister the hook';
$_LANG['live_edit_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_LANG['manufacturer-list_0e1e874dde345d19583102a9fd63fb7e'] = 'Manufacturers';
$_LANG['manufacturer-list_3426bf3cca12b1f6550fd8bd36171e2f'] = 'View products';
$_LANG['manufacturer-list_df25de42c84837baf5fa15049a8bc764'] = 'View';
$_LANG['my-account_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Addresses';
$_LANG['my-account_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_LANG['my-account_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['my-account_a82868319826fb092b73968e661b5b38'] = 'Vouchers';
$_LANG['my-account_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_LANG['my-account_e06d7593c1cd6dabef450be6c3da7091'] = 'Merchandise returns';
$_LANG['nbr-product-page_498f79c4c5bbde77f1bceb6c86fd0f6d'] = 'Show';
$_LANG['order-address-multishipping-products_03ab340b3f99e03cff9e84314ead38c0'] = 'Qty';
$_LANG['order-address-multishipping-products_0c458988127eb2150776881e2ef3f0c4'] = 'Shipping address';
$_LANG['order-address-multishipping-products_a4d3b161ce1309df1c4e25df28694b7b'] = 'Submit';
$_LANG['order-address-multishipping-products_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['order-address-multishipping-products_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['order-address-multishipping_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
$_LANG['order-address-multishipping_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Addresses';
$_LANG['order-address-multishipping_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Add a new address';
$_LANG['order-address-multishipping_db671b8ceed664eaecb59a4e6075ec9f'] = 'Please start by selecting an address.';
$_LANG['order-address-multishipping_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['order-address-multishipping_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_LANG['order-address-product-line_69d08bd5f8cf4e228930935c3f13e42f'] = 'In stock';
$_LANG['order-address-product-line_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_LANG['order-address_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
$_LANG['order-address_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Addresses';
$_LANG['order-address_86024cad1e83101d97359d7351051156'] = 'Products';
$_LANG['order-address_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Add a new address';
$_LANG['order-address_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['order-address_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_LANG['order-address_f5bf48aa40cad7891eb709fcf1fde128'] = 'Product';
$_LANG['order-carrier_068f80c7519d0528fb08e82137a72131'] = 'Products';
$_LANG['order-carrier_0d9175fe89fb80d815e7d03698b6e83a'] = 'Gift';
$_LANG['order-carrier_1f87346a16cf80c372065de3c54c86d9'] = '(tax incl.)';
$_LANG['order-carrier_21034ae6d01a83e702839a72ba8a77b0'] = '(tax excl.)';
$_LANG['order-carrier_66f51e43606e2baebb8e9c3bfe965da4'] = 'Shipping';
$_LANG['order-carrier_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['order-carrier_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['order-carrier_e4045598261988d9988c594243a9434d'] = 'Terms of service';
$_LANG['order-confirmation_fb077ecba55e5552916bde26d8b9e794'] = 'Order confirmation';
$_LANG['order-detail_0e321f3a4007b6404f4d93f7f35b2364'] = 'Shipping and handling';
$_LANG['order-detail_1f87346a16cf80c372065de3c54c86d9'] = '(tax incl.)';
$_LANG['order-detail_38fb6e512f5b9cd141963623ab3b5ddd'] = 'Total cost of gift wrapping';
$_LANG['order-detail_41de6d6cfb8953c021bbe4ba0701c8a1'] = 'Messages';
$_LANG['order-detail_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_LANG['order-detail_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Message';
$_LANG['order-detail_5068c162a60b5859f973f701333f45c5'] = 'Tracking number';
$_LANG['order-detail_552a0d8c17d95d5dbdc0c28217024f5a'] = 'Shipping cost';
$_LANG['order-detail_5da618e8e4b89c66fe86e32cdafde142'] = 'From';
$_LANG['order-detail_601d8c4b9f72fc1862013c19b677a499'] = 'Invoice address';
$_LANG['order-detail_6332e7985befad227455d60812bd1449'] = 'Order Reference %s -- placed on';
$_LANG['order-detail_63d5049791d9d79d86e9a108b0a999ca'] = 'Reference';
$_LANG['order-detail_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_LANG['order-detail_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Unit price';
$_LANG['order-detail_7bc873cba11f035df692c3549366c722'] = '-- Choose --';
$_LANG['order-detail_8c489d0946f66d17d73f26366a4bf620'] = 'Weight';
$_LANG['order-detail_914419aa32f04011357d3b604a86d7eb'] = 'Carrier';
$_LANG['order-detail_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
$_LANG['order-detail_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['order-detail_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total vouchers';
$_LANG['order-detail_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['order-detail_ec53a8c4f07baed5d8825072c89799be'] = 'Status';
$_LANG['order-detail_f0aaaae189e9c7711931a65ffcd22543'] = 'Payment method';
$_LANG['order-detail_fdfac28b5ad628f25649d9c2eb4fc62e'] = 'Returned';
$_LANG['order-follow_01abfc750a0c942167651c40d088531d'] = '#';
$_LANG['order-follow_446faa7da2d42ba4ffeda73cb119dd91'] = 'Date issued';
$_LANG['order-follow_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['order-follow_988fd738de9c6d177440c5dcf69e73ce'] = 'Return';
$_LANG['order-follow_bfc23574a242be4531bcb29877ac1d8a'] = 'Return Merchandise Authorization (RMA)';
$_LANG['order-opc-new-account_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Forgot your password?';
$_LANG['order-opc-new-account_195fbb57ffe7449796d23466085ce6d8'] = 'May';
$_LANG['order-opc-new-account_19f823c6453c2b1ffd09cb715214813d'] = 'Required field';
$_LANG['order-opc-new-account_1b539f6f34e8503c97f6d3421346b63c'] = 'July';
$_LANG['order-opc-new-account_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Company';
$_LANG['order-opc-new-account_20db0bfeecd8fe60533206a2b5e9891a'] = 'First name';
$_LANG['order-opc-new-account_3fcf026bbfffb63fb24b8de9d0446949'] = 'April';
$_LANG['order-opc-new-account_41ba70891fb6f39327d8ccb9b1dafb84'] = 'August';
$_LANG['order-opc-new-account_41c2fff4867cc204120f001e7af20f7a'] = 'Mobile phone';
$_LANG['order-opc-new-account_46a2a41cc6e552044816a2d04634545d'] = 'State';
$_LANG['order-opc-new-account_57d056ed0984166336b7879c2af3657f'] = 'City';
$_LANG['order-opc-new-account_59716c97497eb9694541f7c3d37b1a4d'] = 'Country';
$_LANG['order-opc-new-account_601d8c4b9f72fc1862013c19b677a499'] = 'Invoice address';
$_LANG['order-opc-new-account_659e59f062c75f81259d22786d6c44aa'] = 'February';
$_LANG['order-opc-new-account_688937ccaf2a2b0c45a1c9bbba09698d'] = 'June';
$_LANG['order-opc-new-account_766d4aaf3e045538be23f9a9e17a1593'] = 'Instant checkout';
$_LANG['order-opc-new-account_7cb32e708d6b961d476baced73d362bb'] = 'VAT number';
$_LANG['order-opc-new-account_7e823b37564da492ca1629b4732289a8'] = 'November';
$_LANG['order-opc-new-account_82331503174acbae012b2004f6431fa5'] = 'December';
$_LANG['order-opc-new-account_86f5978d9b80124f509bdb71786e929e'] = 'January';
$_LANG['order-opc-new-account_8d3f5eff9c40ee315d452392bed5309b'] = 'Last name';
$_LANG['order-opc-new-account_936ccdb97115e9f35a11d35e3d5b5cad'] = 'Click here';
$_LANG['order-opc-new-account_b357b524e740bc85b9790a0712d84a30'] = 'Email address';
$_LANG['order-opc-new-account_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_LANG['order-opc-new-account_cc5d90569e1c8313c2b1c2aab1401174'] = 'September';
$_LANG['order-opc-new-account_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_LANG['order-opc-new-account_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_LANG['order-opc-new-account_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['order-opc-new-account_eca60ae8611369fe28a02e2ab8c5d12e'] = 'October';
$_LANG['order-opc-new-account_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'March';
$_LANG['order-opc-new-account_fe66abce284ec8589e7d791185b5c442'] = 'Home phone';
$_LANG['order-opc_1f87346a16cf80c372065de3c54c86d9'] = '(tax incl.)';
$_LANG['order-opc_21034ae6d01a83e702839a72ba8a77b0'] = '(tax excl.)';
$_LANG['order-opc_4ce81305b7edb043d0a7a5c75cab17d0'] = 'There is';
$_LANG['order-opc_601d8c4b9f72fc1862013c19b677a499'] = 'Invoice address';
$_LANG['order-payment_03ab340b3f99e03cff9e84314ead38c0'] = 'Qty';
$_LANG['order-payment_1021f02536dc46ab3b07c269949e4de7'] = 'Text #%s';
$_LANG['order-payment_1ac6ee29e9e68fb71bad91c1d34348cc'] = '%s';
$_LANG['order-payment_66f51e43606e2baebb8e9c3bfe965da4'] = 'Shipping';
$_LANG['order-payment_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Unit price';
$_LANG['order-payment_86024cad1e83101d97359d7351051156'] = 'Products';
$_LANG['order-payment_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['order-payment_a82868319826fb092b73968e661b5b38'] = 'Vouchers';
$_LANG['order-payment_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total vouchers';
$_LANG['order-payment_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['order-payment_db205f01b4fd580fb5daa9072d96849d'] = 'Total products';
$_LANG['order-payment_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['order-payment_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['order-payment_f4e8b53a114e5a17d051ab84d326cae5'] = 'Total shipping';
$_LANG['order-payment_f5bf48aa40cad7891eb709fcf1fde128'] = 'Product';
$_LANG['order-return_1ac6ee29e9e68fb71bad91c1d34348cc'] = '%s';
$_LANG['order-return_63d5049791d9d79d86e9a108b0a999ca'] = 'Reference';
$_LANG['order-return_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_LANG['order-return_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['order-slip_446faa7da2d42ba4ffeda73cb119dd91'] = 'Date issued';
$_LANG['order-slip_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_LANG['order-slip_bcd1b68617759b1dfcff0403a6b5a8d1'] = 'PDF';
$_LANG['order-steps_290612199861c31d1036b185b4e69b75'] = 'Summary';
$_LANG['order-steps_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Payment';
$_LANG['order-steps_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_LANG['order-steps_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Shipping';
$_LANG['pagination_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Next';
$_LANG['pagination_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['password_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Forgot your password?';
$_LANG['password_b357b524e740bc85b9790a0712d84a30'] = 'Email address';
$_LANG['product-list-home_88559a0cfd8250c9d65970cc145c92d4'] = 'OFF';
$_LANG['product-list_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_LANG['product-list_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_LANG['product-list_69d08bd5f8cf4e228930935c3f13e42f'] = 'In stock';
$_LANG['product-sort_33d8042bd735c559cc3206f4bc99aedc'] = 'Sort by';
$_LANG['product-sort_fcebe56087b9373f15514831184fa572'] = 'In stock';
$_LANG['product_0557fa923dcee4d0f86b1409f5c2167f'] = 'Back';
$_LANG['product_104d9898c04874d0fbac36e125fa1369'] = 'Discount';
$_LANG['product_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Next';
$_LANG['product_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_LANG['product_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_LANG['product_801ab24683a4a8c433c6eb40c48bcd9d'] = 'Download';
$_LANG['product_887ee91702c962a70b87cbef07bbcaec'] = 'tax excl.';
$_LANG['product_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_LANG['product_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_LANG['product_e2e79605fc9450ec17957cf0e910f5c6'] = 'tax incl.';
$_LANG['product_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_LANG['product_fe3838c7c11aa406dd956566e17360d5'] = 'per';
$_LANG['products-comparison_1063e38cb53d94d386f21227fcd84717'] = 'Remove';
$_LANG['products-comparison_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_LANG['products-comparison_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
$_LANG['products-comparison_d6295c05503596b3ed3528aee83e3ef7'] = 'Features';
$_LANG['scenes_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_LANG['scenes_d3d2e617335f08df83599665eef8a418'] = 'Close';
$_LANG['search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_LANG['shopping-cart-product-line_69d08bd5f8cf4e228930935c3f13e42f'] = 'In stock';
$_LANG['shopping-cart-product-line_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_LANG['shopping-cart-product-line_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_LANG['shopping-cart_03ab340b3f99e03cff9e84314ead38c0'] = 'Qty';
$_LANG['shopping-cart_28e014bf2ccc53bc1a8042ca57ca6645'] = 'Total vouchers (tax incl.)';
$_LANG['shopping-cart_2fb3b950fd7711136f7f251ae5fbdbdc'] = 'Text #';
$_LANG['shopping-cart_601d8c4b9f72fc1862013c19b677a499'] = 'Invoice address';
$_LANG['shopping-cart_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Unit price';
$_LANG['shopping-cart_86024cad1e83101d97359d7351051156'] = 'Products';
$_LANG['shopping-cart_8faf99e02e4d0ccb4dd933404f87a4ea'] = 'Total (tax excl.)';
$_LANG['shopping-cart_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['shopping-cart_a82868319826fb092b73968e661b5b38'] = 'Vouchers';
$_LANG['shopping-cart_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total vouchers';
$_LANG['shopping-cart_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['shopping-cart_db205f01b4fd580fb5daa9072d96849d'] = 'Total products';
$_LANG['shopping-cart_deb10517653c255364175796ace3553f'] = 'Product';
$_LANG['shopping-cart_e0aa021e21dddbd6d8cecec71e9cf564'] = 'OK';
$_LANG['shopping-cart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Shipping';
$_LANG['shopping-cart_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_LANG['shopping-cart_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_LANG['shopping-cart_f4e8b53a114e5a17d051ab84d326cae5'] = 'Total shipping';
$_LANG['shopping-cart_f5bf48aa40cad7891eb709fcf1fde128'] = 'Product';
$_LANG['sitemap_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Addresses';
$_LANG['sitemap_34c869c542dee932ef8cd96d2f91cae6'] = 'Our store(s)!';
$_LANG['sitemap_453aceb005ceaf54a47da15fee8b2a26'] = 'Pages';
$_LANG['sitemap_9d5bf15117441a1b52eb1f0808e4aad3'] = 'Discounts';
$_LANG['sitemap_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_LANG['sitemap_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_LANG['store_infos_5792315f09a5d54fb7e3d066672b507f'] = 'Tuesday';
$_LANG['store_infos_6f8522e0610541f1ef215a22ffa66ff6'] = 'Monday';
$_LANG['store_infos_78ae6f0cd191d25147e252dc54768238'] = 'Thursday';
$_LANG['store_infos_796c163589f295373e171842f37265d5'] = 'Wednesday';
$_LANG['store_infos_8b7051187b9191cdcdae6ed5a10e5adc'] = 'Saturday';
$_LANG['store_infos_9d1a0949c39e66a0cd65240bc0ac9177'] = 'Sunday';
$_LANG['store_infos_c33b138a163847cdb6caeeb7c9a126b4'] = 'Friday';
$_LANG['stores_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_LANG['stores_34c869c542dee932ef8cd96d2f91cae6'] = 'Our store(s)!';
$_LANG['stores_673ae02fffb72f0fe68a66f096a01347'] = 'Phone';
$_LANG['stores_8c2857a9ad1d8f31659e35e904e20fa6'] = 'Logo';
$_LANG['stores_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_LANG['supplier-list_a00e46e856e637f8fd077b4fd710c9e2'] = 'Suppliers';
$_LANG['supplier-list_df25de42c84837baf5fa15049a8bc764'] = 'View';

?>