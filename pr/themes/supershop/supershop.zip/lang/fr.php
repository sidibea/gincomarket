<?php

global $_LANG;
$_LANG = array();
$_LANG['404_44b1d05764b093cb00c25b8228cb87d3'] = 'Page introuvable';
$_LANG['404_6554aae881e40036cac1f5710a4c52c1'] = 'La page que vous avez demandée n\'existe plus.';
$_LANG['404_7b19b37e7fc3dfe3c3e1ad5b84c7f565'] = 'Page d\'accueil';
$_LANG['404_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['404_9bec38acab82302a8cf6fbb9182da21f'] = 'Pour rechercher un produit, saisissez son nom dans le champ ci-dessous';
$_LANG['404_a60852f204ed8028c1c58808b746d115'] = 'ok';
$_LANG['404_a68ba7d969d1294a35138fa501dfb078'] = 'Cherchez un produit dans notre catalogue :';
$_LANG['404_d0fbda9855d118740f1105334305c126'] = 'Page non trouvée';
$_LANG['address_0f68b904e33d9ac04605aecc958bcf52'] = 'Informations supplémentaires';
$_LANG['address_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_LANG['address_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Société';
$_LANG['address_20db0bfeecd8fe60533206a2b5e9891a'] = 'Prénom';
$_LANG['address_3908e1afa0ff22fbf112aff3c5ba55c1'] = 'Vos adresses';
$_LANG['address_393d8c6bc7a04264bd9523dc8c92b818'] = 'Nouvelle adresse';
$_LANG['address_41c2fff4867cc204120f001e7af20f7a'] = 'Téléphone mobile';
$_LANG['address_455175f3f5be6306247babb349c0515a'] = 'Votre adresse';
$_LANG['address_46a2a41cc6e552044816a2d04634545d'] = 'État';
$_LANG['address_57d056ed0984166336b7879c2af3657f'] = 'Ville ';
$_LANG['address_59716c97497eb9694541f7c3d37b1a4d'] = 'Pays';
$_LANG['address_7cb32e708d6b961d476baced73d362bb'] = 'Numéro de TVA';
$_LANG['address_846a54955f32846032981f8fe48c35ff'] = 'Adresse (2)';
$_LANG['address_89a9a0e5aec9360bc3b0141c8d42e586'] = 'Donnez un titre à cette adresse pour la retrouver plus facilement';
$_LANG['address_8d3f5eff9c40ee315d452392bed5309b'] = 'Nom';
$_LANG['address_ae7bdef7fe2bbbbf02c11e92c5fceb40'] = 'Mon adresse';
$_LANG['address_b60bb13a87fe3ae5463aeb0980a5a8a1'] = 'Numéro d\'identification fiscale';
$_LANG['address_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_LANG['address_d7f172af352aa5232de5295afeaa68e5'] = 'Pour ajouter une nouvelle adresse, merci de remplir ce formulaire.';
$_LANG['address_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_LANG['address_de0c35a9efd08e5ee77a80203ae4221d'] = 'Retour à la liste de vos adresses';
$_LANG['address_e4eb5dadb6ee84c5c55a8edf53f6e554'] = 'Code postal';
$_LANG['address_e9b6b3aa3cab28048d3879710882e1de'] = 'Modifier cette adresse';
$_LANG['address_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['address_eeabead01c6c6f25f22bf0b041df58a9'] = 'Vous devez enregistrer au moins un numéro de téléphone';
$_LANG['address_fe66abce284ec8589e7d791185b5c442'] = 'Téléphone fixe';
$_LANG['addresses_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_LANG['addresses_3c7d34ae915c6664189dab2aebb02307'] = 'Ajouter une adresse';
$_LANG['addresses_56d3db43fb7f323139022a29d57276d8'] = 'Aucune adresse disponible.';
$_LANG['addresses_729a51874fe901b092899e9e8b31c97a'] = 'Êtes-vous sûr ?';
$_LANG['addresses_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['addresses_a6d373cdb986fc009a5a040a4c3d8c1d'] = 'Choisissez vos adresses de facturation et de livraison. Ces dernières seront présélectionnées lors de vos commandes. Vous pouvez également ajouter d\'autres adresses, ce qui est particulièrement intéressant pour envoyer des cadeaux ou recevoir votre commande au bureau.';
$_LANG['addresses_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_LANG['addresses_aa5e970d64eb228f31669d3411171f92'] = 'Vos adresses sont listées ci-dessous.';
$_LANG['addresses_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Ajouter une nouvelle adresse';
$_LANG['addresses_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['addresses_e380ae58f85252c076e131862857de35'] = 'Pensez à les tenir à jour si ces dernières venaient à changer.';
$_LANG['addresses_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Mes adresses';
$_LANG['addresses_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_LANG['authentication_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Mot de passe oublié ?';
$_LANG['authentication_07b66aebbc092434ec2f0558f229ad53'] = 'Saisissez votre adresse e-mail pour créer votre compte.';
$_LANG['authentication_0ba7583639a274c434bbe6ef797115a4'] = 'S\'inscrire';
$_LANG['authentication_0f68b904e33d9ac04605aecc958bcf52'] = 'Informations supplémentaires';
$_LANG['authentication_1011bae349c34405e0c47931fc7ef8ad'] = 'Vos informations société';
$_LANG['authentication_10803b83a68db8f7e7a33e3b41e184d0'] = 'Date de naissance';
$_LANG['authentication_15bbb9d0bbf25e8d2978de1168c749dc'] = 'Site web';
$_LANG['authentication_195fbb57ffe7449796d23466085ce6d8'] = 'Mai';
$_LANG['authentication_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_LANG['authentication_1b539f6f34e8503c97f6d3421346b63c'] = 'Juillet';
$_LANG['authentication_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Société';
$_LANG['authentication_20db0bfeecd8fe60533206a2b5e9891a'] = 'Prénom';
$_LANG['authentication_261ed9f602d575774ae05f2d9f3003da'] = 'Appartement, suite, bloc, bâtiment, étage, etc.';
$_LANG['authentication_2eac22e71eedb5bdb8f94a1354964017'] = 'Mon adresse de facturation';
$_LANG['authentication_2fdfd506efea08144c0794c32ca8250a'] = 'Créez votre compte';
$_LANG['authentication_3fcf026bbfffb63fb24b8de9d0446949'] = 'Avril';
$_LANG['authentication_41ba70891fb6f39327d8ccb9b1dafb84'] = 'Août';
$_LANG['authentication_41c2fff4867cc204120f001e7af20f7a'] = 'Téléphone mobile';
$_LANG['authentication_455175f3f5be6306247babb349c0515a'] = 'Votre adresse';
$_LANG['authentication_46a2a41cc6e552044816a2d04634545d'] = 'État';
$_LANG['authentication_4f68183551e5dbd7c341347ffe308682'] = 'SIRET';
$_LANG['authentication_57478054ae00730105f1bfe535b2225e'] = 'Récupérez votre mot de passe';
$_LANG['authentication_57d056ed0984166336b7879c2af3657f'] = 'Ville ';
$_LANG['authentication_59716c97497eb9694541f7c3d37b1a4d'] = 'Pays';
$_LANG['authentication_59ba30f362294e33f80618c601fd2801'] = 'Il y a %s erreurs';
$_LANG['authentication_5bef23eb7efff2736c5583bda59e5eb7'] = 'Créez votre compte';
$_LANG['authentication_601d8c4b9f72fc1862013c19b677a499'] = 'Adresse de facturation';
$_LANG['authentication_6335a00a08fde0fbb8f6d6630cdadd92'] = 'Vos informations personnelles';
$_LANG['authentication_659e59f062c75f81259d22786d6c44aa'] = 'Février';
$_LANG['authentication_688937ccaf2a2b0c45a1c9bbba09698d'] = 'Juin';
$_LANG['authentication_7cb32e708d6b961d476baced73d362bb'] = 'Numéro de TVA';
$_LANG['authentication_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
$_LANG['authentication_7e823b37564da492ca1629b4732289a8'] = 'Novembre';
$_LANG['authentication_82331503174acbae012b2004f6431fa5'] = 'Décembre';
$_LANG['authentication_846a54955f32846032981f8fe48c35ff'] = 'Adresse (2)';
$_LANG['authentication_85fb93a8ee9440499692da24a1621769'] = 'APE';
$_LANG['authentication_86f5978d9b80124f509bdb71786e929e'] = 'Janvier';
$_LANG['authentication_8d3f5eff9c40ee315d452392bed5309b'] = 'Nom';
$_LANG['authentication_93edfc7af9b6471b30030cf17646e36c'] = 'S\'inscrire à la newsletter';
$_LANG['authentication_ae7bdef7fe2bbbbf02c11e92c5fceb40'] = 'Mon adresse';
$_LANG['authentication_aee0c5ed0554d46465080ed36d1d93ab'] = 'Je souhaite utiliser une autre adresse pour la facturation';
$_LANG['authentication_af0f5bdc5be121b9307687aeeae38c17'] = 'Adresse de livraison';
$_LANG['authentication_b357b524e740bc85b9790a0712d84a30'] = 'Adresse e-mail';
$_LANG['authentication_b60bb13a87fe3ae5463aeb0980a5a8a1'] = 'Numéro d\'identification fiscale';
$_LANG['authentication_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Connexion';
$_LANG['authentication_b78a3223503896721cca1303f776159b'] = 'Titre';
$_LANG['authentication_baca087296e01b5d69799dd53bcd7950'] = 'Recevez les offres spéciales de nos partenaires';
$_LANG['authentication_c75f7811d70d17dbcd88e9d03752cbed'] = 'Identifiez-vous';
$_LANG['authentication_c773457e85b990c10f8823eacb21346c'] = 'Identification fiscale';
$_LANG['authentication_cb430603758e73c64b8e1fef814b0be0'] = 'Il y a une erreur';
$_LANG['authentication_cc5d90569e1c8313c2b1c2aab1401174'] = 'Septembre';
$_LANG['authentication_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_LANG['authentication_d83893e5c6dab1264313e6a0bc77814b'] = 'Numéro dans la rue, boîte postale, nom de la société';
$_LANG['authentication_d87f73e8ff8d933ed2ba5ddf25040827'] = 'Commande instantanée';
$_LANG['authentication_d973a0b6f38ebe7c83094d3dc4e04ae5'] = 'Donnez un titre à cette adresse pour la retrouver plus facilement';
$_LANG['authentication_db879b00e657fc85f7873343f11df21c'] = 'Déjà inscrit?';
$_LANG['authentication_dc647eb65e6711e155375218212b3964'] = 'Mot de passe';
$_LANG['authentication_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_LANG['authentication_e4eb5dadb6ee84c5c55a8edf53f6e554'] = 'Code postal';
$_LANG['authentication_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['authentication_eca60ae8611369fe28a02e2ab8c5d12e'] = 'Octobre';
$_LANG['authentication_eeabead01c6c6f25f22bf0b041df58a9'] = 'Vous devez enregistrer au moins un numéro de téléphone';
$_LANG['authentication_f430bd2f85c4424dabd003de2ddf370c'] = '(5 caractères min.)';
$_LANG['authentication_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'Mars';
$_LANG['authentication_fe66abce284ec8589e7d791185b5c442'] = 'Téléphone fixe';
$_LANG['best-sales_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_LANG['best-sales_73d3cc7826075c127caaadb0e20162ab'] = 'Pas de meilleures ventes pour le moment.';
$_LANG['breadcrumb_56cf8b33ab527ab81b4f6b3ceac090dd'] = 'retour à Accueil';
$_LANG['breadcrumb_641879153fe03137042781f70f56c98d'] = 'Retourner aux résultats de la recherche \"%s\" (encore %d résultats)';
$_LANG['breadcrumb_8cf04a9734132302f96da8e113e80ce5'] = 'Maison';
$_LANG['category-count_79ac892bd1769d83ef1c16dae9f4eddd'] = 'Il y a 1 produit.';
$_LANG['category-count_a9d48596a6537347711527bab8fcd152'] = 'Il y a %d produits.';
$_LANG['category-count_ff32f7dba36bcd6d0a4214cd80253c3a'] = 'Il n\'y a aucun produit dans cette catégorie.';
$_LANG['category_2f4e54ec9bebe1122b5c23217e764828'] = 'Cette catégorie est actuellement indisponible.';
$_LANG['category_c0e5fc951292789815df7dac2d6796a1'] = 'Désolé! Il n\'y a pas de produits dans cette catégorie.';
$_LANG['cms_0557fa923dcee4d0f86b1409f5c2167f'] = 'Précédent';
$_LANG['cms_110a4b01beabd53b661a47d4b44bd7a8'] = 'Publier';
$_LANG['cms_24a26cffdfea04302a5bc20b9bce6626'] = 'Cette page CMS n\'est pas visible par vos clients.';
$_LANG['cms_d3c42ceb9bee8c44815b53f36e496925'] = 'Liste des sous-catégories de %s :';
$_LANG['cms_e02aaa9a02ed0955984af6508675d242'] = 'Liste des pages dans %s :';
$_LANG['cms_eecc2cef7e0fa128ecb0557b66486539'] = 'Cette page n\'existe pas';
$_LANG['contact-form_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_LANG['contact-form_13d6078da2e6592822ede083931d6826'] = 'Joindre un fichier';
$_LANG['contact-form_3f65d6e17a11466983fd177702cf6a71'] = 'Formulaire de contact';
$_LANG['contact-form_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Message';
$_LANG['contact-form_4ec1c39345fe8820d68463eea8803b0f'] = 'Votre message a bien été envoyé à notre équipe.';
$_LANG['contact-form_5d4710f9a8250b13164a82c94d5b00d1'] = 'Référence de commande';
$_LANG['contact-form_6c27c08f40e1b0d9901deb9ff5f722f7'] = 'Objet';
$_LANG['contact-form_7bc873cba11f035df692c3549366c722'] = 'Choisissez';
$_LANG['contact-form_7c9d4636fc5ed97bb78bc2aac486beab'] = 'Votre message a déjà été envoyé.';
$_LANG['contact-form_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['contact-form_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_LANG['contact-form_b357b524e740bc85b9790a0712d84a30'] = 'Adresse e-mail';
$_LANG['contact-form_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_LANG['contact-form_d754a9e8cb640da12849a040f3ca8176'] = 'Votre réponse';
$_LANG['contact-form_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['contact-form_e635032a5f71d809146d3872389f5b0c'] = 'Ajouter';
$_LANG['contact-form_f787618e514c038851726224d7e4421e'] = 'Aucun fichier sélectionné';
$_LANG['discount_29aa46cc3d2677c7e0f216910df600ff'] = 'Frais de port offerts';
$_LANG['discount_689202409e48743b914713f96d93947c'] = 'Valeur';
$_LANG['discount_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_LANG['discount_6adf97f83acf6453d4a6a4b1070f3754'] = 'aucun';
$_LANG['discount_8c1279db4db86553e4b9682f78cf500e'] = 'Date d\'expiration';
$_LANG['discount_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['discount_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_LANG['discount_95d2137c196c7f84df5753ed78f18332'] = 'Mes bons de réduction';
$_LANG['discount_a1d0ec6d56f8833a078b5a7ac4caf2d4'] = 'Minimum';
$_LANG['discount_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_LANG['discount_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['discount_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_LANG['discount_befcac0f9644a7abee43e69f49252ac4'] = 'HT';
$_LANG['discount_ca0dbad92a874b2f69b549293387925e'] = 'Code';
$_LANG['discount_d3f5baf7537ec2a40ade00599a8da8c6'] = 'Vous ne possédez pas de bon de réduction.';
$_LANG['discount_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['discount_eb2527806a7e1ef48009eaaa785368fe'] = 'Cumulable';
$_LANG['discount_f4a0d7cb0cd45214c8ca5912c970de13'] = 'TTC';
$_LANG['errors_0557fa923dcee4d0f86b1409f5c2167f'] = 'Précédent';
$_LANG['errors_5fbddd8d4e0d8c7a868272f2f171df09'] = 'Il y a %d erreur';
$_LANG['errors_9ead913c5b7c87efda39ca9640c46ae4'] = 'Il y a %d erreurs';
$_LANG['footer_105078d294d30c978ca2badf7f376934'] = 'Rouleau';
$_LANG['global_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
$_LANG['global_d3d2e617335f08df83599665eef8a418'] = 'Fermer';
$_LANG['global_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['guest-tracking_109636f722b8fccc95d072b2760a6282'] = 'Transformez votre compte invité en compte client et bénéficiez des avantages suivants :';
$_LANG['guest-tracking_1f1015bbef5f42d858e8486397ad8f3e'] = 'Retours produits plus faciles';
$_LANG['guest-tracking_3aedb5d3a3e36f7bb6baf1fbb9497894'] = 'Suivi de commande';
$_LANG['guest-tracking_3b6bf3c0c07b89dc86f415117a1f0b80'] = 'Définissez votre mot de passe :';
$_LANG['guest-tracking_43b2f3ca9c34b5934ff858549406f556'] = 'Pour plus d\'avantages...';
$_LANG['guest-tracking_57d244b331a3a5eb30dd5384a370e085'] = 'Cliquez ici pour vous connecter à votre compte client.';
$_LANG['guest-tracking_63c193f613dd3d9d6c16da7678efda2a'] = 'Référence du paiement';
$_LANG['guest-tracking_6a1e265f92087bb6dd18194833fe946b'] = 'E-mail :';
$_LANG['guest-tracking_7a8fe8aaa64e691d82f429d39e0df3a5'] = 'Accès au site sécurisé et personnalisé';
$_LANG['guest-tracking_92dbb751eb9457441af82a53f3cfae54'] = 'Par exemple : QIIXJXNUI ou QIIXJXNUI#1';
$_LANG['guest-tracking_93aef17b1541efc1c3f8bd6679972096'] = 'Passage de commande rapide et facile';
$_LANG['guest-tracking_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_LANG['guest-tracking_a16574242b3bbe2fc5ec9dc26fe4deb2'] = 'page';
$_LANG['guest-tracking_a719d9bdf7a895ffc54665300df2ada4'] = 'Votre compte invité a été transformé avec succès en compte client. Vous pouvez maintenant vous connecter et poursuivre la navigation en tant que client identifié. ';
$_LANG['guest-tracking_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_LANG['guest-tracking_d2948a89e47a4ad7eb8412c1c260ea88'] = 'Afin de suivre votre commande, veuillez saisir les informations suivantes :';
$_LANG['header_0fcd4065ff78fceb3083316ddb958bc1'] = 'Vous ne pouvez pas créer de nouvelle commande depuis votre pays :';
$_LANG['header_216adaf4e98dc62ec3abeab51b9fc57f'] = 'Se il vous plaît sélectionner au moins un produit';
$_LANG['header_90723749917a82bf3ff8a73247d32ffb'] = 'Vous ne pouvez pas ajouter plus de% d produit (s) à la comparaison de produits';
$_LANG['history_06b05d09714a236f1e285a6b5c83a209'] = 'Vous trouverez ici vos commandes passées depuis la création de votre compte';
$_LANG['history_0b3db27bc15f682e92ff250ebb167d4b'] = 'Retour à votre compte';
$_LANG['history_0eede552438475bdfe820c13f24c9399'] = 'Prix total';
$_LANG['history_116cb47fe026f7a3679486e086426a64'] = 'Si vous venez de passer une commande, celle-ci peut mettre du temps pour être validée. Veuillez recharger cette page si votre commande ne s\'affiche pas.';
$_LANG['history_1b6324ace95b17a01323052fda855989'] = 'Produit(s) à télécharger';
$_LANG['history_332c80b1838dc515f5031e09da3b7f3f'] = 'Re-commander';
$_LANG['history_3ec365dd533ddb7ef3d1c111186ce872'] = 'Détails';
$_LANG['history_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_LANG['history_466eadd40b3c10580e3ab4e8061161ce'] = 'Facture';
$_LANG['history_5acc2ceeb883ba07cef2d02ea382f242'] = 'Vous n\'avez pas encore passé de commande';
$_LANG['history_5d4710f9a8250b13164a82c94d5b00d1'] = 'Référence de commande';
$_LANG['history_782c8b38bce4f2f6975ca7f33ac8189b'] = 'Historique de vos commandes';
$_LANG['history_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['history_bcd1b68617759b1dfcff0403a6b5a8d1'] = 'PDF';
$_LANG['history_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Paiement';
$_LANG['history_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['history_ec53a8c4f07baed5d8825072c89799be'] = 'État';
$_LANG['identity_1011bae349c34405e0c47931fc7ef8ad'] = 'Vos informations société';
$_LANG['identity_10803b83a68db8f7e7a33e3b41e184d0'] = 'Date de naissance';
$_LANG['identity_15bbb9d0bbf25e8d2978de1168c749dc'] = 'Site web';
$_LANG['identity_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_LANG['identity_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Société';
$_LANG['identity_20db0bfeecd8fe60533206a2b5e9891a'] = 'Prénom';
$_LANG['identity_21102621bd5856b350ae86db3aeed9fc'] = 'N\'hésitez pas à modifier vos informations personnelles si celles-ci ont changé.';
$_LANG['identity_29224ba63cde6e9f1e16691138bdf954'] = 'Votre mot de passe vous a été envoyé par e-mail :';
$_LANG['identity_4bc28f132d571b160ba407e143915de2'] = 'Mot de passe actuel';
$_LANG['identity_4f68183551e5dbd7c341347ffe308682'] = 'SIRET';
$_LANG['identity_5e74f2daf4ae8030571ceee5b4837579'] = 'Titre';
$_LANG['identity_6335a00a08fde0fbb8f6d6630cdadd92'] = 'Vos informations personnelles';
$_LANG['identity_85fb93a8ee9440499692da24a1621769'] = 'APE';
$_LANG['identity_8b5dd64ab8d0b8158906796b53a200e2'] = 'Adresse e-mail';
$_LANG['identity_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['identity_8d3f5eff9c40ee315d452392bed5309b'] = 'Nom';
$_LANG['identity_93edfc7af9b6471b30030cf17646e36c'] = 'S\'inscrire à la newsletter';
$_LANG['identity_94d33283c51fdd4a296157461259aee0'] = 'Vos informations personnelles ont été mises à jour.';
$_LANG['identity_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_LANG['identity_ae3bb2a1ac61750150b606298091d38a'] = 'Nouveau mot de passe';
$_LANG['identity_baca087296e01b5d69799dd53bcd7950'] = 'Recevez les offres spéciales de nos partenaires';
$_LANG['identity_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_LANG['identity_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['identity_ea460dd8c3ac592e8224d8fe3ef774c7'] = 'Conformément aux dispositions de la loi du n°78-17 du 6 janvier 1978, vous disposez d\'un droit d\'accès, de rectification et d\'opposition sur les données nominatives vous concernant.';
$_LANG['identity_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_LANG['live_edit_1b7c6a7f9b72974ede874b8fba9547a0'] = 'Ajouter ce module';
$_LANG['live_edit_282f96c7d1ed98d24606d209dcad9842'] = 'Position des modules sauvée';
$_LANG['live_edit_3c5b87f318f203adbfcc5d6a68959359'] = 'Impossible de charger la liste des modules';
$_LANG['live_edit_49d4a9317844948aa594330102d79026'] = 'Etes-vous sûr ? Si vous fermez cette fenêtre, sa position ne sera pas sauvée';
$_LANG['live_edit_70d9be9b139893aa6c69b5e77e614311'] = 'Confirmer';
$_LANG['live_edit_79030d996976f29a5e986a42d8f026e5'] = 'Impossible d\'enregistrer la position du module';
$_LANG['live_edit_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_LANG['live_edit_d3d2e617335f08df83599665eef8a418'] = 'Fermer';
$_LANG['live_edit_d8dcfab18b3a6eba56d617dd1dcb1ba7'] = 'Fermer le Live Edit';
$_LANG['live_edit_da87eac3848a0d55560bdd129a0e134b'] = 'Impossible de supprimer le module de ce hook';
$_LANG['live_edit_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_LANG['maintenance_38a27c0c7ef7a05e13efa2798ee21533'] = 'Mode maintenance';
$_LANG['maintenance_a022ff58716d4cf34050cb68e7f12fcf'] = 'Nous nous excusons pour la gêne occasionnée. Merci de revenir plus tard.';
$_LANG['maintenance_fef882af64a6b9c88dbc5e6cce2607bc'] = 'Pour cause de maintenance, votre boutique en ligne est temporairement inaccessible.';
$_LANG['manufacturer-list_0397cbccfd02272abd38f8933b865218'] = '%d produit';
$_LANG['manufacturer-list_0e1e874dde345d19583102a9fd63fb7e'] = 'Fabricants :';
$_LANG['manufacturer-list_3426bf3cca12b1f6550fd8bd36171e2f'] = 'afficher les produits';
$_LANG['manufacturer-list_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_LANG['manufacturer-list_5174d1309f275ba6f275db3af9eb3e18'] = 'Grille';
$_LANG['manufacturer-list_84be54bb4bd1b755a27d86388700d097'] = 'Marques';
$_LANG['manufacturer-list_864c665aea5e824772fda0e678c3ac4d'] = '%d produits';
$_LANG['manufacturer-list_ac27bfc960343d2e6222945cc50f2405'] = 'Il y a une marque';
$_LANG['manufacturer-list_ce7bdbaa2a5998973271d85172456ee6'] = 'Il n\'y aucun fabricant.';
$_LANG['manufacturer-list_df25de42c84837baf5fa15049a8bc764'] = 'Afficher :';
$_LANG['manufacturer-list_f84855a18b9b3e1cd70f2b2cde5778b4'] = 'Il y a %d marques';
$_LANG['manufacturer_4c8d12a46c2deb4898979acfd4e23f6a'] = 'Liste de produits par fabricant';
$_LANG['manufacturer_a65ed5e8df4b1c2bb34844f81cc9b451'] = 'Pas de produit pour ce fabricant.';
$_LANG['manufacturer_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Détails';
$_LANG['my-account_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_LANG['my-account_4b0afa9e8d3cdefd4fb21faebe22ef5f'] = 'Votre compte est maintenant créé.';
$_LANG['my-account_4c8a50af0ebcf49be0cf4e0f67f37595'] = 'Mes informations personnelles';
$_LANG['my-account_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_LANG['my-account_89080f0eedbd5491a93157930f1e45fc'] = 'Mes retours de marchandise';
$_LANG['my-account_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['my-account_9132bc7bac91dd4e1c453d4e96edf219'] = 'Mes avoirs';
$_LANG['my-account_95d2137c196c7f84df5753ed78f18332'] = 'Mes bons de réduction';
$_LANG['my-account_999fe77c512638fd1b2ff18646d24781'] = 'Bienvenue sur votre page d\'accueil. Vous pouvez y gérer vos informations personnelles ainsi que vos commandes.';
$_LANG['my-account_a82868319826fb092b73968e661b5b38'] = 'Bons de réduction';
$_LANG['my-account_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_LANG['my-account_cea4dedd9147586b361b90e900944690'] = 'Historique et détails de mes commandes';
$_LANG['my-account_d1a365ea7809ae5831c6d9f86886630c'] = 'Avoirs';
$_LANG['my-account_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['my-account_e06d7593c1cd6dabef450be6c3da7091'] = 'Retours produit';
$_LANG['my-account_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Mes adresses';
$_LANG['my-account_f4c5b2b545efb89fefa11fd6c9da1cb3'] = 'Ajouter ma première adresse';
$_LANG['nbr-product-page_498f79c4c5bbde77f1bceb6c86fd0f6d'] = 'Montrer';
$_LANG['nbr-product-page_4f5d5f295ddc8fd8673e74dd5fbe114a'] = 'par page';
$_LANG['new-products_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_LANG['new-products_d58424783355b6da2dedc302f2bf4065'] = 'Pas de nouveaux produits';
$_LANG['order-address-multishipping-products_03ab340b3f99e03cff9e84314ead38c0'] = 'Quantité';
$_LANG['order-address-multishipping-products_0c458988127eb2150776881e2ef3f0c4'] = 'Adresse de livraison';
$_LANG['order-address-multishipping-products_12d3c7a4296542c62474856ec452c045'] = 'Réf.';
$_LANG['order-address-multishipping-products_713abca3b7abddc0445099b23c0a3697'] = 'Livrer à plusieurs adresses';
$_LANG['order-address-multishipping-products_9ff9c46512c186ebae182519a55dc6a9'] = 'Disp.';
$_LANG['order-address-multishipping-products_a4d3b161ce1309df1c4e25df28694b7b'] = 'ENVOYER';
$_LANG['order-address-multishipping-products_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['order-address-multishipping-products_bb6275503ffe7e64cf768216ee0de066'] = 'Les quantités de certains produits ont été changées, veuillez les vérifier.';
$_LANG['order-address-multishipping-products_d28f8bbb0740354aae5456da9cc56d0e'] = 'Choisissez une adresse de livraison :';
$_LANG['order-address-multishipping-products_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['order-address-multishipping_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_LANG['order-address-multishipping_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_LANG['order-address-multishipping_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
$_LANG['order-address-multishipping_82a7d396bbd6f6fef648578b4ae2ea81'] = 'Choisissez une adresse de facturation :';
$_LANG['order-address-multishipping_86024cad1e83101d97359d7351051156'] = 'produits';
$_LANG['order-address-multishipping_8a8c9edb5531fa2f822295d1830d090f'] = 'Votre adresse de livraison';
$_LANG['order-address-multishipping_a4d3b161ce1309df1c4e25df28694b7b'] = 'ENVOYER';
$_LANG['order-address-multishipping_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Ajouter une nouvelle adresse';
$_LANG['order-address-multishipping_c20905e8fdd34a1bf81984e597436134'] = 'Continuer mes achats';
$_LANG['order-address-multishipping_d93651d012e77dac5581b08db33195b2'] = 'Si vous voulez nous laisser un message à propos de votre commande, merci de bien vouloir le renseigner dans le champ ci-contre';
$_LANG['order-address-multishipping_da9d6ec2998a07c31ec9eb93c9f254ed'] = 'Votre adresse de facturation';
$_LANG['order-address-multishipping_db671b8ceed664eaecb59a4e6075ec9f'] = 'Veuillez d\'abord choisir une adresse';
$_LANG['order-address-multishipping_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['order-address-multishipping_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_LANG['order-address-multishipping_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_LANG['order-address-product-line_07177f134a19f8965265d014b5b81645'] = 'Créer une nouvelle adresse';
$_LANG['order-address-product-line_1d9baf077ee87921f57a8fe42d510b65'] = 'Soustraire';
$_LANG['order-address-product-line_69d08bd5f8cf4e228930935c3f13e42f'] = 'Disponible';
$_LANG['order-address-product-line_713abca3b7abddc0445099b23c0a3697'] = 'Livrer à plusieurs adresses';
$_LANG['order-address-product-line_e716b72edf18038c04664e9b21569177'] = 'Vous devez avoir acheté au moins %d de ce produit.';
$_LANG['order-address-product-line_e990b6285ed2a575c561235378a5e691'] = 'Rupture de stock';
$_LANG['order-address-product-line_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_LANG['order-address_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_LANG['order-address_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_LANG['order-address_390b4c95516a4b7faf97389ca46fc0c7'] = 'Utiliser la même adresse pour la facturation';
$_LANG['order-address_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
$_LANG['order-address_82a7d396bbd6f6fef648578b4ae2ea81'] = 'Choisissez une adresse de facturation :';
$_LANG['order-address_86024cad1e83101d97359d7351051156'] = 'produits';
$_LANG['order-address_8a8c9edb5531fa2f822295d1830d090f'] = 'Votre adresse de livraison';
$_LANG['order-address_a4d3b161ce1309df1c4e25df28694b7b'] = 'ENVOYER';
$_LANG['order-address_b15e1100a6196acba01ef7aaa5b2a9e5'] = 'Ajouter une nouvelle adresse';
$_LANG['order-address_c20905e8fdd34a1bf81984e597436134'] = 'Continuer mes achats';
$_LANG['order-address_d0748d2df4aed77bd7591b3ac6c52c83'] = 'Choisissez une adresse de livraison :';
$_LANG['order-address_d93651d012e77dac5581b08db33195b2'] = 'Si vous voulez nous laisser un message à propos de votre commande, merci de bien vouloir le renseigner dans le champ ci-contre';
$_LANG['order-address_da9d6ec2998a07c31ec9eb93c9f254ed'] = 'Votre adresse de facturation';
$_LANG['order-address_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['order-address_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_LANG['order-address_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_LANG['order-carrier_068f80c7519d0528fb08e82137a72131'] = 'Produits';
$_LANG['order-carrier_0d9175fe89fb80d815e7d03698b6e83a'] = 'Cadeau';
$_LANG['order-carrier_1f87346a16cf80c372065de3c54c86d9'] = 'TTC';
$_LANG['order-carrier_21034ae6d01a83e702839a72ba8a77b0'] = '(HT)';
$_LANG['order-carrier_2d51d96d770cc2244be31a85e608de19'] = 'Aucun transporteur disponible.';
$_LANG['order-carrier_300225ee958b6350abc51805dab83c24'] = 'Continuer mes achats';
$_LANG['order-carrier_32224bd6487699ea66652d3dc502455d'] = 'Je souhaite que ma commande soit emballée dans un papier-cadeau.';
$_LANG['order-carrier_3818429ccff49b9d6ab2b4a9a137a00a'] = 'Aucun transporteur n\'est nécessaire pour cette commande';
$_LANG['order-carrier_5508a53851720a210e50f7b8a6f66f46'] = 'Vous devez accepter les conditions générales de vente pour passer à l\'étape suivante';
$_LANG['order-carrier_5c2dfd55fea1f5c6adef500fcb6403b4'] = 'Supp. de';
$_LANG['order-carrier_66f51e43606e2baebb8e9c3bfe965da4'] = 'Transport :';
$_LANG['order-carrier_6f05787682585c32498e88bcd2ea88fc'] = 'Méthodes de livraison';
$_LANG['order-carrier_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
$_LANG['order-carrier_8fb37535c12fbe2899ab442ec474c157'] = 'Choisissez une option de livraison';
$_LANG['order-carrier_9193b58520051d8b59ca64a5cc5353ff'] = 'J\'accepte de recevoir ma commande dans un emballage recyclé';
$_LANG['order-carrier_9960807cfb66a03002a9b7777c4a96c5'] = 'Produits concernés :';
$_LANG['order-carrier_a6cc8cbe3fa07d0fca172c36a603332c'] = 'Aucun transporteur disponible pour l\'adresse \"%s\".';
$_LANG['order-carrier_ad88a6c9e8c880f23639321d78ec859d'] = 'J\'ai lu les conditions générales de vente et j\'y adhère sans réserve.';
$_LANG['order-carrier_b1992d8f7c58180c1ebd461b7d502423'] = 'Le meilleur prix';
$_LANG['order-carrier_b24ce0cd392a5b0b8dedc66c25213594'] = 'gratuit';
$_LANG['order-carrier_b6dddfff5178ce64364ca3f683930354'] = 'Le meilleur prix et la livraison la plus rapide';
$_LANG['order-carrier_bd5b551d1757a856d9f2d01dc7850080'] = 'Laisser un message';
$_LANG['order-carrier_bf46d59ab4c5096d169c1a5eb39cc0c1'] = 'Vous pouvez ajouter un message d\'accompagnement à votre commande.';
$_LANG['order-carrier_c2a32e7734b79d54eaaddb651707b403'] = 'Le plus rapide';
$_LANG['order-carrier_cc9b9807af9192bed55cb1e92ba28844'] = 'Choisissez une option de livraison pour l\'adresse :';
$_LANG['order-carrier_d53afd7ef9af5405df040482add9b153'] = '(Lire les Conditions générales de vente)';
$_LANG['order-carrier_d93651d012e77dac5581b08db33195b2'] = 'Si vous voulez nous laisser un message à propos de votre commande, merci de bien vouloir le renseigner dans le champ ci-contre';
$_LANG['order-carrier_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['order-carrier_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['order-carrier_e06b4fd44aa19916cbbb34d7ca26efa1'] = 'Produit concerné :';
$_LANG['order-carrier_e4045598261988d9988c594243a9434d'] = 'Conditions générales de vente';
$_LANG['order-confirmation_4082ea29b4f196c4f60533500139725a'] = 'Suivre ma commande';
$_LANG['order-confirmation_9390390581f54c65d6acfc8da4e17362'] = 'Retour aux commandes';
$_LANG['order-confirmation_9be66ab020fd0ffb9dd22756969b8dc7'] = 'Votre numéro de commande a été envoyé par e-mail.';
$_LANG['order-confirmation_e19e31ddb54b493059808ec4f2dab4cb'] = 'Votre numéro de commande est le :';
$_LANG['order-confirmation_fb077ecba55e5552916bde26d8b9e794'] = 'Confirmation de commande';
$_LANG['order-detail_0c478a7069ab13f446e9e765cffd1550'] = 'Message envoyé avec succès';
$_LANG['order-detail_0e321f3a4007b6404f4d93f7f35b2364'] = 'Frais de manutention';
$_LANG['order-detail_0eede552438475bdfe820c13f24c9399'] = 'Prix total';
$_LANG['order-detail_1f87346a16cf80c372065de3c54c86d9'] = 'TTC';
$_LANG['order-detail_25e93b63e91b5555bd458c89b1916678'] = 'Générer un retour';
$_LANG['order-detail_2fb4ff3bfaaa7204156b95847bf5c04e'] = 'Articles (hors taxes)';
$_LANG['order-detail_332c80b1838dc515f5031e09da3b7f3f'] = 'Re-commander';
$_LANG['order-detail_38fb6e512f5b9cd141963623ab3b5ddd'] = 'Total emballage cadeau';
$_LANG['order-detail_3956298bcfc047e15b0e0d218492ce09'] = 'Retour de marchandise';
$_LANG['order-detail_3d056974128aa7405c1941a684b8279d'] = 'Vous ne pouvez pas faire de retour de marchandise avec un compte invité';
$_LANG['order-detail_41de6d6cfb8953c021bbe4ba0701c8a1'] = 'Messages';
$_LANG['order-detail_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_LANG['order-detail_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Message';
$_LANG['order-detail_5068c162a60b5859f973f701333f45c5'] = 'Numéro de suivi';
$_LANG['order-detail_552a0d8c17d95d5dbdc0c28217024f5a'] = 'Frais d\'expédition';
$_LANG['order-detail_58b3d8603dffe8484e90c0ca371921ac'] = 'Ajouter un message :';
$_LANG['order-detail_5da618e8e4b89c66fe86e32cdafde142'] = 'Du';
$_LANG['order-detail_5fbddd8d4e0d8c7a868272f2f171df09'] = 'Il y a %d erreur';
$_LANG['order-detail_601d8c4b9f72fc1862013c19b677a499'] = 'Adresse de facturation';
$_LANG['order-detail_6332e7985befad227455d60812bd1449'] = 'Référence de la commande %s – passée le';
$_LANG['order-detail_63d5049791d9d79d86e9a108b0a999ca'] = 'Référence';
$_LANG['order-detail_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_LANG['order-detail_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Prix unitaire';
$_LANG['order-detail_755bb0834a77079fd1330b555b69e6bf'] = 'Vous avez accepté de recevoir votre commande dans un emballage recyclé.';
$_LANG['order-detail_7bc873cba11f035df692c3549366c722'] = 'Choisissez';
$_LANG['order-detail_8c489d0946f66d17d73f26366a4bf620'] = 'Poids';
$_LANG['order-detail_914419aa32f04011357d3b604a86d7eb'] = 'Transporteur';
$_LANG['order-detail_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_LANG['order-detail_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['order-detail_978c7c1b6214ab576cd8425896b29339'] = 'Suivre votre commande pas à pas';
$_LANG['order-detail_9dea4016dbcc290b773ab2fae678aaa8'] = 'Produits';
$_LANG['order-detail_9ead913c5b7c87efda39ca9640c46ae4'] = 'Il y a %d erreurs';
$_LANG['order-detail_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total bons de réduction';
$_LANG['order-detail_aec9b5b1c2f91ccdef8e25f5f1dac86a'] = 'Télécharger le produit';
$_LANG['order-detail_af0f5bdc5be121b9307687aeeae38c17'] = 'Adresse de livraison';
$_LANG['order-detail_be686376cddb23d0227444ccc3c4b5b7'] = 'Bons de réduction :';
$_LANG['order-detail_bef8403608dc4cb3ade799f63dd4bf59'] = 'Si vous désirez nous retourner un ou plusieurs produits, veuillez cocher chacun d\'entre eux et spécifier un motif de retour, puis valider.';
$_LANG['order-detail_c060ca8505d0aa094635fbf9beac94b0'] = 'télécharger ce produit';
$_LANG['order-detail_ced55d097872ab13bf177e8d31db396f'] = 'Cliquez sur le lien suivant pour suivre la livraison de votre commande';
$_LANG['order-detail_d93651d012e77dac5581b08db33195b2'] = 'Si vous voulez nous laisser un message à propos de votre commande, merci de bien vouloir le renseigner dans le champ ci-contre';
$_LANG['order-detail_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['order-detail_e14bc5cef02df7369b604ea3885adb96'] = 'Vous avez demandé un papier cadeau pour cette commande.';
$_LANG['order-detail_e682495785e844d491378817aa34aa3f'] = 'Téléchargez votre facture au format PDF';
$_LANG['order-detail_ec53a8c4f07baed5d8825072c89799be'] = 'État';
$_LANG['order-detail_f0aaaae189e9c7711931a65ffcd22543'] = 'Méthode de paiement';
$_LANG['order-detail_fdfac28b5ad628f25649d9c2eb4fc62e'] = 'Retourné';
$_LANG['order-follow_01abfc750a0c942167651c40d088531d'] = 'n°';
$_LANG['order-follow_0d3cfc2fe56119651ee7848f3e32d84d'] = 'Etiquette de retour';
$_LANG['order-follow_15ef0f1f63c1e8a9fb8abad024939262'] = 'Vous n\'avez aucun retour de marchandise créé.';
$_LANG['order-follow_1819b587867a9c604a4d21c753756b4a'] = 'Veuillez indiquer la quantité voulue pour chaque produit coché.';
$_LANG['order-follow_229ca46a5d762e19a428f59449c916ad'] = 'Merci de spécifier un motif de retour !';
$_LANG['order-follow_25e93b63e91b5555bd458c89b1916678'] = 'Générer un retour';
$_LANG['order-follow_446faa7da2d42ba4ffeda73cb119dd91'] = 'Date d\'émission';
$_LANG['order-follow_8a6034d3379499b66d730aa17e007683'] = 'Vous n\'avez pas un nombre suffisant de produits pour générer un autre retour !';
$_LANG['order-follow_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['order-follow_988fd738de9c6d177440c5dcf69e73ce'] = 'Retour';
$_LANG['order-follow_9bb4b32641712af2309584a5e97c0f73'] = 'Cette commande ne peut pas être retournée.';
$_LANG['order-follow_9cf9ab35a1b24314913bb739d25a0b36'] = 'Voici la liste des retours produits en cours';
$_LANG['order-follow_a240fa27925a635b08dc28c9e4f9216d'] = 'Commande';
$_LANG['order-follow_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_LANG['order-follow_bfc23574a242be4531bcb29877ac1d8a'] = 'Retour produit';
$_LANG['order-follow_cbd22dcb89c7ff53e1d58959352b278e'] = 'Veuillez donner la raison de votre retour produit';
$_LANG['order-follow_cc894fffb019b528d12951b74d6d2b6e'] = 'Retour de marchandise';
$_LANG['order-follow_d442cb92c3b031eceacbfe87605b9356'] = 'État du retour';
$_LANG['order-follow_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['order-follow_daf51d7d9e10e6a469434ae548d9a173'] = 'Imprimer';
$_LANG['order-follow_e6f6a5e58ee6d010f22e4b3dbd756213'] = 'Merci de cocher au moins un produit à retourner.';
$_LANG['order-opc-new-account_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Mot de passe oublié ?';
$_LANG['order-opc-new-account_08bd40c7543007ad06e4fce31618f6ec'] = 'Compte';
$_LANG['order-opc-new-account_0f68b904e33d9ac04605aecc958bcf52'] = 'Informations supplémentaires';
$_LANG['order-opc-new-account_10803b83a68db8f7e7a33e3b41e184d0'] = 'Date de naissance';
$_LANG['order-opc-new-account_12819315d9cf421dcaac8122a71ececa'] = 'Commander en tant qu\'invité';
$_LANG['order-opc-new-account_195fbb57ffe7449796d23466085ce6d8'] = 'Mai';
$_LANG['order-opc-new-account_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_LANG['order-opc-new-account_1b539f6f34e8503c97f6d3421346b63c'] = 'Juillet';
$_LANG['order-opc-new-account_1c76cbfe21c6f44c1d1e59d54f3e4420'] = 'Société';
$_LANG['order-opc-new-account_20db0bfeecd8fe60533206a2b5e9891a'] = 'Prénom';
$_LANG['order-opc-new-account_2eac22e71eedb5bdb8f94a1354964017'] = 'Mon adresse de facturation';
$_LANG['order-opc-new-account_2fdfd506efea08144c0794c32ca8250a'] = 'Créez votre compte';
$_LANG['order-opc-new-account_3fcf026bbfffb63fb24b8de9d0446949'] = 'Avril';
$_LANG['order-opc-new-account_41ba70891fb6f39327d8ccb9b1dafb84'] = 'Août';
$_LANG['order-opc-new-account_41c2fff4867cc204120f001e7af20f7a'] = 'Téléphone mobile';
$_LANG['order-opc-new-account_46a2a41cc6e552044816a2d04634545d'] = 'État';
$_LANG['order-opc-new-account_4efcd04126e90b74c744bab6c66b6e63'] = 'Adresse de livraison différente de celle de facturation';
$_LANG['order-opc-new-account_57d056ed0984166336b7879c2af3657f'] = 'Ville ';
$_LANG['order-opc-new-account_58357b08947453bff66da9b47b3da168'] = '(min. 5 caractères.)';
$_LANG['order-opc-new-account_59716c97497eb9694541f7c3d37b1a4d'] = 'Pays';
$_LANG['order-opc-new-account_5d9eca48241c03f20f27586c1f24a4b0'] = 'Code postal';
$_LANG['order-opc-new-account_5e74f2daf4ae8030571ceee5b4837579'] = 'Titre';
$_LANG['order-opc-new-account_601d8c4b9f72fc1862013c19b677a499'] = 'Adresse de facturation';
$_LANG['order-opc-new-account_659e59f062c75f81259d22786d6c44aa'] = 'Février';
$_LANG['order-opc-new-account_688937ccaf2a2b0c45a1c9bbba09698d'] = 'Juin';
$_LANG['order-opc-new-account_6a35e1439d14f62e7177f59c175c886f'] = 'Les informations du compte ont été enregistrées avec succès';
$_LANG['order-opc-new-account_766d4aaf3e045538be23f9a9e17a1593'] = 'Commande instantanée';
$_LANG['order-opc-new-account_7a8fe8aaa64e691d82f429d39e0df3a5'] = 'Accès au site sécurisé et personnalisé';
$_LANG['order-opc-new-account_7cb32e708d6b961d476baced73d362bb'] = 'Numéro de TVA';
$_LANG['order-opc-new-account_7e823b37564da492ca1629b4732289a8'] = 'Novembre';
$_LANG['order-opc-new-account_82331503174acbae012b2004f6431fa5'] = 'Décembre';
$_LANG['order-opc-new-account_846a54955f32846032981f8fe48c35ff'] = 'Adresse (2)';
$_LANG['order-opc-new-account_86f5978d9b80124f509bdb71786e929e'] = 'Janvier';
$_LANG['order-opc-new-account_8d3f5eff9c40ee315d452392bed5309b'] = 'Nom';
$_LANG['order-opc-new-account_936ccdb97115e9f35a11d35e3d5b5cad'] = 'Cliquez ici';
$_LANG['order-opc-new-account_93edfc7af9b6471b30030cf17646e36c'] = 'S\'inscrire à la newsletter';
$_LANG['order-opc-new-account_ae7bdef7fe2bbbbf02c11e92c5fceb40'] = 'Mon adresse';
$_LANG['order-opc-new-account_aee0c5ed0554d46465080ed36d1d93ab'] = 'Je souhaite utiliser une autre adresse pour la facturation';
$_LANG['order-opc-new-account_af0f5bdc5be121b9307687aeeae38c17'] = 'Adresse de livraison';
$_LANG['order-opc-new-account_b357b524e740bc85b9790a0712d84a30'] = 'Adresse e-mail';
$_LANG['order-opc-new-account_b60bb13a87fe3ae5463aeb0980a5a8a1'] = 'Numéro d\'identification fiscale';
$_LANG['order-opc-new-account_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Connexion';
$_LANG['order-opc-new-account_baca087296e01b5d69799dd53bcd7950'] = 'Recevez les offres spéciales de nos partenaires';
$_LANG['order-opc-new-account_c28639657b4e3352241f83d8b6021e4e'] = 'Nouveau client';
$_LANG['order-opc-new-account_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_LANG['order-opc-new-account_cc5d90569e1c8313c2b1c2aab1401174'] = 'Septembre';
$_LANG['order-opc-new-account_ce025dc66f590f8c03ad9556bc376d9e'] = 'Une prise de commande facile et rapide';
$_LANG['order-opc-new-account_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_LANG['order-opc-new-account_d50965b89f4bf0dfbc5b1f13052421a4'] = 'Créez votre compte dès aujourd\'hui et profitez :';
$_LANG['order-opc-new-account_db879b00e657fc85f7873343f11df21c'] = 'Déjà inscrit?';
$_LANG['order-opc-new-account_dc647eb65e6711e155375218212b3964'] = 'Mot de passe';
$_LANG['order-opc-new-account_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_LANG['order-opc-new-account_e4eb5dadb6ee84c5c55a8edf53f6e554'] = 'Code postal';
$_LANG['order-opc-new-account_ea318a4ad37f0c2d2c368e6c958ed551'] = 'DNI / NIF / NIE';
$_LANG['order-opc-new-account_eca60ae8611369fe28a02e2ab8c5d12e'] = 'Octobre';
$_LANG['order-opc-new-account_eeabead01c6c6f25f22bf0b041df58a9'] = 'Vous devez enregistrer au moins un numéro de téléphone';
$_LANG['order-opc-new-account_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'Mars';
$_LANG['order-opc-new-account_fe66abce284ec8589e7d791185b5c442'] = 'Téléphone fixe';
$_LANG['order-opc_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_LANG['order-opc_1f87346a16cf80c372065de3c54c86d9'] = 'TTC';
$_LANG['order-opc_21034ae6d01a83e702839a72ba8a77b0'] = '(HT)';
$_LANG['order-opc_238a062a6a2543fd85d6616a8506fbe8'] = 'Pas de transporteur nécessaire pour cette commande';
$_LANG['order-opc_25d8efaba32cb44a922a727f20eaa002'] = 'Les conditions générales de vente n\'ont pas été acceptées';
$_LANG['order-opc_2e75f367f058646a1ba2fd01ceb74423'] = 'Aucune condition générale de vente doit être acceptée';
$_LANG['order-opc_449374f661344e843453c4e189ddeed8'] = 'Modifier mon adresse';
$_LANG['order-opc_4ce81305b7edb043d0a7a5c75cab17d0'] = 'Il y a';
$_LANG['order-opc_601d8c4b9f72fc1862013c19b677a499'] = 'Adresse de facturation';
$_LANG['order-opc_78fa1019f9a9759b45c76e186393756f'] = 'Cette boutique n\'a pas accepté votre nouvelle commande.';
$_LANG['order-opc_879f6b8877752685a966564d072f498f'] = 'Votre panier est vide';
$_LANG['order-opc_8a8c9edb5531fa2f822295d1830d090f'] = 'Votre adresse de livraison';
$_LANG['order-opc_9504d494016e17a6de7e7b51da637bc4'] = 'Aucun transporteur n\'a été sélectionné';
$_LANG['order-opc_a40cab5994f36d4c48103a22ca082e8f'] = 'Votre panier';
$_LANG['order-opc_ad52144224a9fb9e04b8b9ef22ce36f7'] = 'Veuillez d\'abord choisir une adresse';
$_LANG['order-opc_af0f5bdc5be121b9307687aeeae38c17'] = 'Adresse de livraison';
$_LANG['order-opc_b24ce0cd392a5b0b8dedc66c25213594'] = 'gratuit';
$_LANG['order-opc_d236af51d8eac54fe7c366af1f6b358c'] = 'Les conditions générales de vente ont été acceptées';
$_LANG['order-opc_d87f73e8ff8d933ed2ba5ddf25040827'] = 'Commande instantanée';
$_LANG['order-opc_da9d6ec2998a07c31ec9eb93c9f254ed'] = 'Votre adresse de facturation';
$_LANG['order-opc_ea295188b69aa5e04810abcc38b2b2be'] = 'a été sélectionné';
$_LANG['order-opc_fe816ec4b30c11a39edfd8b0a4cfab49'] = 'erreur(s)';
$_LANG['order-payment_03ab340b3f99e03cff9e84314ead38c0'] = 'Quantité';
$_LANG['order-payment_1021f02536dc46ab3b07c269949e4de7'] = 'Texte n°%s :';
$_LANG['order-payment_19809527da8b7308e45e2dc6ac40cca9'] = 'Total bons d\'achats (TTC)';
$_LANG['order-payment_1ac6ee29e9e68fb71bad91c1d34348cc'] = '%s :';
$_LANG['order-payment_2370a4958c4ebe6d6c8045cd49a6b392'] = 'Total produits HT :';
$_LANG['order-payment_300225ee958b6350abc51805dab83c24'] = 'Continuer mes achats';
$_LANG['order-payment_31f52379817244bb67196c880749cfd8'] = 'Total papiers cadeaux :';
$_LANG['order-payment_444bcb3a3fcf8389296c49467f27e1d6'] = 'ok';
$_LANG['order-payment_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Taxes';
$_LANG['order-payment_59319ac504f7ad04ae16126cf49e7f7e'] = 'Votre méthode de paiement';
$_LANG['order-payment_59816dd41a0dab043184d5ab19e2edaf'] = 'Total papiers cadeaux TTC :';
$_LANG['order-payment_5cfa28d1182c6bd5bbd1af0bd459efbe'] = 'Total papiers cadeaux HT :';
$_LANG['order-payment_66f51e43606e2baebb8e9c3bfe965da4'] = 'Transport :';
$_LANG['order-payment_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Prix unitaire';
$_LANG['order-payment_86024cad1e83101d97359d7351051156'] = 'produits';
$_LANG['order-payment_8e1263b23607508e7ba8ff39aec8031d'] = 'Aucun module de paiement n\'a encore été installé.';
$_LANG['order-payment_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['order-payment_9816a5054cd05761b6765fbef0062b29'] = 'Total bons de réduction (HT)';
$_LANG['order-payment_9ff9c46512c186ebae182519a55dc6a9'] = 'Disp.';
$_LANG['order-payment_a82868319826fb092b73968e661b5b38'] = 'Bons de réduction';
$_LANG['order-payment_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total bons de réduction';
$_LANG['order-payment_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['order-payment_db205f01b4fd580fb5daa9072d96849d'] = 'Total produits';
$_LANG['order-payment_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['order-payment_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['order-payment_e747da89afc98485bb90928d397e9821'] = 'Choisissez votre méthode de paiement';
$_LANG['order-payment_e93f43fa527c3534aeca987091d6c049'] = 'Total frais de port (TTC)';
$_LANG['order-payment_ebaee01719541f61281c16ba22ebbfde'] = 'Total produits TTC :';
$_LANG['order-payment_ecba3578d8cd65126d4a47c76b3c9c2d'] = 'Livraison gratuite !';
$_LANG['order-payment_f246a17c095de09e043cc1cb917481da'] = 'Total frais de port (HT)';
$_LANG['order-payment_f4e8b53a114e5a17d051ab84d326cae5'] = 'Frais de port';
$_LANG['order-payment_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_LANG['order-payment_f7b96335c6a33477579e43f3da368507'] = 'Profitez de nos offres :';
$_LANG['order-return_16dafae9102750489087d1d087b72aba'] = 'Dès réception de votre colis, nous procéderons au remboursement du montant de votre commande et vous en informerons par e-mail.';
$_LANG['order-return_1ac6ee29e9e68fb71bad91c1d34348cc'] = '%s :';
$_LANG['order-return_2b79d007c64009edf92d06f7cb280b25'] = 'Tous les produits doivent être retournés dans leur emballage et leur état d\'origine.';
$_LANG['order-return_44a9edeffb86277f007fa90d96689a6d'] = 'Vous devez attendre notre confirmation avant de nous retourner les produits.';
$_LANG['order-return_5347ffe274974d2f2c9dfcb9d8f1b691'] = 'voir le document PDF';
$_LANG['order-return_63d5049791d9d79d86e9a108b0a999ca'] = 'Référence';
$_LANG['order-return_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_LANG['order-return_6f1f2e16c84468614218f62ca6b42ba2'] = 'Situation actuelle de votre retour produit :';
$_LANG['order-return_88be9ea838e21273267409d76af3b284'] = 'Nous avons enregistré votre demande de retour.';
$_LANG['order-return_92a9774c2a5df29ac4bffb46219ea9cd'] = 'Rappel';
$_LANG['order-return_955b51949c0e756934c02c521f7f9405'] = 'document PDF';
$_LANG['order-return_b24be74c768f02b296d4e8f41be486fb'] = 'Liste des articles à retourner :';
$_LANG['order-return_d9d95b7fdffceaaa11c6bbae7b3bfa37'] = 'Le colis doit être livré à l\'adresse correcte';
$_LANG['order-return_dd0b8feb4eb6c389c284518f5683017c'] = 'Nous vous rappelons que votre colis doit nous être retourné dans les';
$_LANG['order-return_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['order-return_dfd57af0760925d5574fda1794d14de5'] = 'Retour n°';
$_LANG['order-return_e81874a861e2b26ea2c4ecce9f378078'] = 'et le glisser dans votre colis.';
$_LANG['order-return_ea62a2e28a800c367509773730120a67'] = 'jours après réception de votre commande.';
$_LANG['order-return_ed2b5c0139cec8ad2873829dc1117d50'] = 'du';
$_LANG['order-return_f393a2fe17dc0cacff53a136479b845d'] = 'Veuillez nous contacter pour toute question.';
$_LANG['order-return_f3ba7c2fb2c65ad6fa1b1efd30573a8d'] = 'Veuillez imprimer ce';
$_LANG['order-return_f637120d9f24c366b382ede6c21cddf0'] = 'Si les conditions de retour listées ci-dessus ne sont pas respectées, nous nous réservons le droit de refuser votre colis ou votre remboursement.';
$_LANG['order-slip_0ba830b7ca1513a4882ce5aac84030b8'] = 'Vous n\'avez reçu aucun avoir';
$_LANG['order-slip_3cb6ea48a427bf3a1687302e3b764c27'] = 'Afficher l\'avoir';
$_LANG['order-slip_446faa7da2d42ba4ffeda73cb119dd91'] = 'Date d\'émission';
$_LANG['order-slip_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_LANG['order-slip_a240fa27925a635b08dc28c9e4f9216d'] = 'Commande';
$_LANG['order-slip_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_LANG['order-slip_bcd1b68617759b1dfcff0403a6b5a8d1'] = 'PDF';
$_LANG['order-slip_cf3bae95c5f6023d5a10fe415b205a45'] = 'Avoir';
$_LANG['order-slip_d1a365ea7809ae5831c6d9f86886630c'] = 'Avoirs';
$_LANG['order-slip_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_LANG['order-slip_e28cc69f9aa3068eddb76dd508b11da2'] = 'n°%s';
$_LANG['order-slip_f97bb49d92cd0fe889f07e290b4792d5'] = 'Liste des avoirs reçus suite à des annulations de commandes';
$_LANG['order-steps_290612199861c31d1036b185b4e69b75'] = 'Récapitulatif';
$_LANG['order-steps_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Connexion';
$_LANG['order-steps_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Paiement';
$_LANG['order-steps_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_LANG['order-steps_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Livraison';
$_LANG['pagination-top_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
$_LANG['pagination-top_dbb5f11eab5c5c375c4c5face47ddf1e'] = 'page';
$_LANG['pagination-top_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['pagination_08d8f2394d17064e1c505e3d6ef7ef12'] = 'Résultats %1$d - %2$d sur %3$d.';
$_LANG['pagination_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
$_LANG['pagination_89762ea29386643afc3fc50e7e50b53c'] = 'Résultats %1$d - %2$d sur 1.';
$_LANG['pagination_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['pagination_eb92025cb8c66f1850c13a9b602a1856'] = 'Afficher tout';
$_LANG['password_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Mot de passe oublié ?';
$_LANG['password_0d0e2934af7d3bc4e7263fcb1f9bc51c'] = 'Récupérer';
$_LANG['password_0fb655f37529ad006eb0d503e23e10f1'] = 'Mot de passe oublié';
$_LANG['password_8859f6ab28ba3d2384b269bcfa36ac33'] = 'Un e-mail de confirmation a été envoyé à votre adresse e-mail :';
$_LANG['password_95e6faaba5e8b016e5f9bcf5ea6c8270'] = 'Retour à la connexion';
$_LANG['password_ad6de86f2f344d447d78a139fc16bd72'] = 'Veuillez renseigner votre adresse e-mail afin de recevoir votre nouveau mot de passe.';
$_LANG['password_b357b524e740bc85b9790a0712d84a30'] = 'Adresse e-mail';
$_LANG['password_c75f7811d70d17dbcd88e9d03752cbed'] = 'Identifiez-vous';
$_LANG['password_f15b7d9b716da1d46ba073df11d4a8d0'] = 'Votre mot de passe a été renouvelé et a été envoyé à votre adresse e-mail.';
$_LANG['prices-drop_701ddcee4495ef7a80e99750caf63941'] = 'Aucune promotion.';
$_LANG['prices-drop_c8f312df214e2295809027c6ca79d232'] = 'Promotions';
$_LANG['product-compare_216adaf4e98dc62ec3abeab51b9fc57f'] = 'Veuillez choisir au moins 1 produit.';
$_LANG['product-compare_7eece51cf3938103677db7a5051ef8f5'] = 'Comparer';
$_LANG['product-compare_90723749917a82bf3ff8a73247d32ffb'] = 'Vous ne pouvez pas ajouter plus de %d produit(s) dans le comparateur.';
$_LANG['product-list-carousel_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_LANG['product-list-carousel_03de921a8ea82897e13d33d66c28b4db'] = 'En ligne seulement';
$_LANG['product-list-carousel_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_LANG['product-list-carousel_69d08bd5f8cf4e228930935c3f13e42f'] = 'En Stock';
$_LANG['product-list-carousel_8c751c4aab0db0b811cdfbddf0b4ea56'] = 'Disponibilité:';
$_LANG['product-list-carousel_aa1411cc44ecfafbca0d71427fe3dc7a'] = 'Ajouter à comparer';
$_LANG['product-list-carousel_b55197a49e8c4cd8c314bc2aa39d6feb'] = 'Rupture de stock';
$_LANG['product-list-carousel_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Vente!';
$_LANG['product-list-carousel_c91e4ee170226d66e90f99ba917e4c20'] = 'Aperçu';
$_LANG['product-list-carousel_ca2bf12169883f4982d8fe34b7e3c618'] = 'Prix réduit!';
$_LANG['product-list-carousel_cb3c718c905f00adbb6735f55bfb38ef'] = 'Produit disponible avec différentes options';
$_LANG['product-list-carousel_fd24b639c2ae3236e67880ce4b6b8af3'] = ' Stock out';
$_LANG['product-list-home_88559a0cfd8250c9d65970cc145c92d4'] = 'OFF';
$_LANG['product-list_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_LANG['product-list_03de921a8ea82897e13d33d66c28b4db'] = 'Exclusivité web !';
$_LANG['product-list_216adaf4e98dc62ec3abeab51b9fc57f'] = 'Veuillez choisir au moins 1 produit.';
$_LANG['product-list_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_LANG['product-list_69d08bd5f8cf4e228930935c3f13e42f'] = 'Disponible';
$_LANG['product-list_8c751c4aab0db0b811cdfbddf0b4ea56'] = 'Disponibilité:';
$_LANG['product-list_90723749917a82bf3ff8a73247d32ffb'] = 'Vous ne pouvez pas ajouter plus de %d produit(s) dans le comparateur.';
$_LANG['product-list_a7f5fa1be0194c2016999ee52784924f'] = ' Code de l\'article:';
$_LANG['product-list_aa1411cc44ecfafbca0d71427fe3dc7a'] = 'Ajouter à comparer';
$_LANG['product-list_b55197a49e8c4cd8c314bc2aa39d6feb'] = 'Rupture de stock';
$_LANG['product-list_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Promo!';
$_LANG['product-list_ca2bf12169883f4982d8fe34b7e3c618'] = 'Prix réduit !';
$_LANG['product-list_cb3c718c905f00adbb6735f55bfb38ef'] = 'Produit disponible avec d\'autres options';
$_LANG['product-list_fd24b639c2ae3236e67880ce4b6b8af3'] = 'Stock out';
$_LANG['product-sort-view_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_LANG['product-sort-view_5174d1309f275ba6f275db3af9eb3e18'] = 'Grille';
$_LANG['product-sort-view_aca1ce8d0afe11d3a3c89714118cfce1'] = 'Afficher en:';
$_LANG['product-sort_03590cca8220917788b5a6c25fa39a15'] = 'Le plus cher';
$_LANG['product-sort_33d8042bd735c559cc3206f4bc99aedc'] = 'Tri';
$_LANG['product-sort_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_LANG['product-sort_4f4f552919d5a7ad3435b5fdb7fcae61'] = 'De Z à A';
$_LANG['product-sort_5174d1309f275ba6f275db3af9eb3e18'] = 'Grille';
$_LANG['product-sort_526e1c4e51dca91d2aeea20808766e74'] = 'Référence : décroissante';
$_LANG['product-sort_5820b5a5298779a25d98c41173b931bd'] = 'De A à Z';
$_LANG['product-sort_7f284e119af971a952e4b29f0875fc60'] = 'Le moins cher';
$_LANG['product-sort_aca1ce8d0afe11d3a3c89714118cfce1'] = 'Afficher en:';
$_LANG['product-sort_c9e06afd258999a1c59d9fce7d9c86c0'] = 'Référence : croissante';
$_LANG['product-sort_fcebe56087b9373f15514831184fa572'] = 'En Stock';
$_LANG['product_019d1ca7d50cc54b995f60d456435e87'] = 'Utilisé';
$_LANG['product_02ea084dc2ef3e9965dbba4ec87d2f9b'] = 'Afficher toutes les images';
$_LANG['product_03ab340b3f99e03cff9e84314ead38c0'] = 'Quantité';
$_LANG['product_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_LANG['product_03de921a8ea82897e13d33d66c28b4db'] = 'Exclusivité web !';
$_LANG['product_0557fa923dcee4d0f86b1409f5c2167f'] = 'Précédent';
$_LANG['product_0d83f0026f6d2923b2aa3a208156918c'] = 'Attention : dernières pièces disponibles !';
$_LANG['product_104d9898c04874d0fbac36e125fa1369'] = 'Remise';
$_LANG['product_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
$_LANG['product_110a4b01beabd53b661a47d4b44bd7a8'] = 'Publier';
$_LANG['product_13dba24862cf9128167a59100e154c8d'] = 'Imprimer';
$_LANG['product_244b3e3668625b8d118cd8fbfbda4325'] = 'Code produit:';
$_LANG['product_26f5a22330a8d5d32c87e6a4c7f3de95'] = 'Jusqu\'à';
$_LANG['product_28a623fd7e9d81936b562dc5241a16a7'] = 'Ce produit n\'existe pas dans cette déclinaison. Vous pouvez néanmoins en sélectionner une autre.';
$_LANG['product_2b56b60f878922093facd42284848a0c'] = 'Plus de détails';
$_LANG['product_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_LANG['product_3601146c4e948c32b6424d2c0a7f0118'] = 'Prix';
$_LANG['product_3b6d056ac93fc7b1947c3bc2ce720aaf'] = 'Veuillez remplir tous les champs, puis enregistrer votre personnalisation';
$_LANG['product_476efcbaed950dd513ffc08e4e9a632f'] = 'Envoi en cours, veuillez patienter...';
$_LANG['product_54c02ba7929b1fda4847991a45b58a48'] = 'Personnalisation';
$_LANG['product_54d3b260d7e0e3377ff04b75bf564982'] = 'Dont';
$_LANG['product_638f592f71fc3fac3351534e69f9d29f'] = 'Ajouter au panier';
$_LANG['product_63a78ed4647f7c63c2929e35ec1c95e3'] = 'Personnaliser';
$_LANG['product_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_LANG['product_6da03a74721a0554b7143254225cc08a'] = 'Reconditionné';
$_LANG['product_71948aa4f6e12cdaa5e2e63a5eb8f142'] = 'En savoir plus';
$_LANG['product_7d74f3b92b19da5e606d737d339a9679'] = 'Article';
$_LANG['product_7dcd185f890fd28f69d1ed210292d77f'] = 'Fiche technique';
$_LANG['product_7f8c1eb3bfb1d0f94b20515f3cc5a211'] = 'champs requis';
$_LANG['product_801ab24683a4a8c433c6eb40c48bcd9d'] = 'Téléchargement';
$_LANG['product_861c0c6ef832cd96c5fe152f9d610973'] = 'Vous économisez';
$_LANG['product_887ee91702c962a70b87cbef07bbcaec'] = 'HT';
$_LANG['product_8c751c4aab0db0b811cdfbddf0b4ea56'] = 'Disponibilité :';
$_LANG['product_98edb85b00d9527ad5acebe451b3fae6'] = 'Accessoires';
$_LANG['product_9981d2af851e4b4a4ea612d59f08ab9c'] = 'Autres vues';
$_LANG['product_9a9a97ca85af73f90515e72745f730f0'] = 'au lieu de';
$_LANG['product_9d5bf15117441a1b52eb1f0808e4aad3'] = 'Réductions';
$_LANG['product_9dea4016dbcc290b773ab2fae678aaa8'] = 'Produits';
$_LANG['product_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_LANG['product_a134618182b99ff9151d7e0b6b92410a'] = '(ne sera pas compris dans la réduction)';
$_LANG['product_a82be0f551b8708bc08eb33cd9ded0cf'] = ' informations';
$_LANG['product_aa1411cc44ecfafbca0d71427fe3dc7a'] = 'Ajouter à comparer';
$_LANG['product_ac230c36810502ea7e2a0e0ea427c586'] = 'd\'éco-participation';
$_LANG['product_b11ddc7e1671c0bd22dc89dd757508d4'] = 'Images';
$_LANG['product_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Promo!';
$_LANG['product_bc0f7082192ef02e934a036cf4991789'] = 'Ce produit n\'est plus en stock';
$_LANG['product_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_LANG['product_ca2bf12169883f4982d8fe34b7e3c618'] = 'Prix réduit !';
$_LANG['product_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Détails';
$_LANG['product_d3f098af54fd27484e1b6168dfe6ae10'] = 'quantité pour ce produit. ';
$_LANG['product_d5a90effea572da2df11559161c0930b'] = 'Après avoir enregistré votre personnalisation, n\'oubliez pas d\'ajouter le produit au panier.';
$_LANG['product_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_LANG['product_e2e79605fc9450ec17957cf0e910f5c6'] = 'TTC';
$_LANG['product_e376237cca06a37330137147d20b0848'] = 'Ce produit n\'est pas vendu à l\'unité. Vous devez sélectionner au moins';
$_LANG['product_e54a973d0c3342dac6ee7d9e145c6f83'] = 'Contenu du pack';
$_LANG['product_e5a75e83f9fd2f5fdff337a46227b3c3'] = 'Formats acceptés : GIF, JPG, PNG';
$_LANG['product_e635032a5f71d809146d3872389f5b0c'] = 'Ajouter';
$_LANG['product_ea254ced8be4adb6c4a2750e84087da6'] = 'Date de disponibilité:';
$_LANG['product_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_LANG['product_f787618e514c038851726224d7e4421e'] = 'Aucun fichier sélectionné';
$_LANG['product_f9ddd507fdf437437efdcb333a0f4ff0'] = 'Ce produit n\'est pas visible par vos clients.';
$_LANG['product_fa3638ce880fddddb872f53943933487'] = 'avec ces options mais reste disponible avec d\'autres options';
$_LANG['product_fc21aa6a8b0bceb8570c8c81b6b38307'] = 'Remise sur la quantité';
$_LANG['product_fd26de1a9f14da358bed04e29b04a89d'] = 'Sélectionnez une image sur votre ordinateur';
$_LANG['product_fe3838c7c11aa406dd956566e17360d5'] = 'par';
$_LANG['products-comparison_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_LANG['products-comparison_1063e38cb53d94d386f21227fcd84717'] = 'Retirer';
$_LANG['products-comparison_234a9674e80b9c04a685075ad3ea6950'] = 'Aucun produit dans le comparateur';
$_LANG['products-comparison_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_LANG['products-comparison_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
$_LANG['products-comparison_4dbce7d8fae730e09fce9e83433c77ff'] = 'Comparaison de produits';
$_LANG['products-comparison_8c751c4aab0db0b811cdfbddf0b4ea56'] = 'Disponibilité :';
$_LANG['products-comparison_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Promo!';
$_LANG['products-comparison_c1f0d3df31869ee3093120a670be37dd'] = 'Ce produit n\'est plus en stock';
$_LANG['products-comparison_c20905e8fdd34a1bf81984e597436134'] = 'Continuer mes achats';
$_LANG['products-comparison_ca2bf12169883f4982d8fe34b7e3c618'] = 'Prix réduit !';
$_LANG['products-comparison_d6295c05503596b3ed3528aee83e3ef7'] = 'Caractéristiques :';
$_LANG['products-comparison_db0404dd6d32e0926c9adecd9ba193f3'] = 'par %s';
$_LANG['products-comparison_f5e15309ff0396474b8421ef48871d0b'] = 'Aucune caractéristique à comparer';
$_LANG['restricted-country_cf8092a0be7b972d6cee3db90bfaf923'] = 'Vous ne pouvez pas accéder à notre boutique depuis votre pays. Veuillez nous excuser de la gêne occasionnée.';
$_LANG['scenes_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_LANG['scenes_ca2bf12169883f4982d8fe34b7e3c618'] = 'Prix réduit !';
$_LANG['scenes_d3d2e617335f08df83599665eef8a418'] = 'Fermer';
$_LANG['scenes_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Promotion';
$_LANG['search_05cf990f79d935b0ea6105855adef686'] = 'Retour à la page précédente';
$_LANG['search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_LANG['search_3a93aed43691aed28d2ce3a53d3c63f8'] = '%d résultat a été trouvé.';
$_LANG['search_a09e4037d02313230a191007246e1694'] = '%d résultats ont été trouvés.';
$_LANG['search_a4bb6bf91165c149d73930f43ad4ef69'] = 'Veuillez saisir un mot-clé pour effectuer une recherche';
$_LANG['search_b2c56c8b57680e576c61c1b5df0d0c2d'] = 'Aucun résultat trouvé';
$_LANG['shopping-cart-product-line_1d9baf077ee87921f57a8fe42d510b65'] = 'Soustraire';
$_LANG['shopping-cart-product-line_6665e3761028c84e1d228de3432229ed'] = 'Référence';
$_LANG['shopping-cart-product-line_69d08bd5f8cf4e228930935c3f13e42f'] = 'Disponible';
$_LANG['shopping-cart-product-line_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Prix unitaire';
$_LANG['shopping-cart-product-line_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['shopping-cart-product-line_a59ba454f256953d318ac200a50d67d1'] = 'Offert !';
$_LANG['shopping-cart-product-line_b55197a49e8c4cd8c314bc2aa39d6feb'] = 'Rupture de stock';
$_LANG['shopping-cart-product-line_e716b72edf18038c04664e9b21569177'] = 'Vous devez avoir acheté au moins %d de ce produit.';
$_LANG['shopping-cart-product-line_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_LANG['shopping-cart-product-line_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_LANG['shopping-cart_03ab340b3f99e03cff9e84314ead38c0'] = 'Quantité';
$_LANG['shopping-cart_0559e7888ca7513e71dad1c954a4b44d'] = 'Total emballage cadeau :';
$_LANG['shopping-cart_12a7a93d72ded50311b52c7d0a853e3c'] = 'Profitez de nos offres exclusives :';
$_LANG['shopping-cart_1d9baf077ee87921f57a8fe42d510b65'] = 'Soustraire';
$_LANG['shopping-cart_2370a4958c4ebe6d6c8045cd49a6b392'] = 'Total produits HT :';
$_LANG['shopping-cart_28e014bf2ccc53bc1a8042ca57ca6645'] = 'Total bons d\'achats TTC :';
$_LANG['shopping-cart_2fb3b950fd7711136f7f251ae5fbdbdc'] = 'Texte #';
$_LANG['shopping-cart_300225ee958b6350abc51805dab83c24'] = 'Continuer mes achats';
$_LANG['shopping-cart_30efeba472c0bc4d0747d0109948a714'] = 'Envoyer les produits disponibles en premier.';
$_LANG['shopping-cart_4b0afa9e8d3cdefd4fb21faebe22ef5f'] = 'Votre compte est maintenant créé.';
$_LANG['shopping-cart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Taxes';
$_LANG['shopping-cart_5af5f631f774a71445e3028253874394'] = 'Cette boutique n\'a pas accepté votre nouvelle commande';
$_LANG['shopping-cart_601d8c4b9f72fc1862013c19b677a499'] = 'Adresse de facturation';
$_LANG['shopping-cart_68c1f7726dbf6e8c073350b2fb3a1604'] = 'Total emballage cadeau TTC :';
$_LANG['shopping-cart_6c957f72dc8cdacc75762f2cbdcdfaf2'] = 'Prix unitaire';
$_LANG['shopping-cart_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
$_LANG['shopping-cart_86024cad1e83101d97359d7351051156'] = 'produits';
$_LANG['shopping-cart_879f6b8877752685a966564d072f498f'] = 'Votre panier est vide';
$_LANG['shopping-cart_8faf99e02e4d0ccb4dd933404f87a4ea'] = 'Total HT :';
$_LANG['shopping-cart_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_LANG['shopping-cart_9816a5054cd05761b6765fbef0062b29'] = 'Total bons de réduction (HT)';
$_LANG['shopping-cart_9ff9c46512c186ebae182519a55dc6a9'] = 'Disp.';
$_LANG['shopping-cart_a40cab5994f36d4c48103a22ca082e8f'] = 'Votre panier';
$_LANG['shopping-cart_a82868319826fb092b73968e661b5b38'] = 'Bons de réduction';
$_LANG['shopping-cart_ada0f55ef37f4928c5cd970f378c15e8'] = 'Total bons de réduction';
$_LANG['shopping-cart_af0f5bdc5be121b9307687aeeae38c17'] = 'Adresse de livraison';
$_LANG['shopping-cart_b4f90d226d5212c67236540da6b5c2da'] = 'Dernier produit ajouté';
$_LANG['shopping-cart_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_LANG['shopping-cart_d6bf6fa1b9ec58788836df2f1019cdb0'] = 'Votre panier contient';
$_LANG['shopping-cart_db205f01b4fd580fb5daa9072d96849d'] = 'Total produits';
$_LANG['shopping-cart_deb10517653c255364175796ace3553f'] = 'Produit';
$_LANG['shopping-cart_e0aa021e21dddbd6d8cecec71e9cf564'] = 'ok';
$_LANG['shopping-cart_e93f43fa527c3534aeca987091d6c049'] = 'Total frais de port (TTC)';
$_LANG['shopping-cart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Livraison';
$_LANG['shopping-cart_ebaee01719541f61281c16ba22ebbfde'] = 'Total produits TTC :';
$_LANG['shopping-cart_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_LANG['shopping-cart_ecba3578d8cd65126d4a47c76b3c9c2d'] = 'Livraison gratuite !';
$_LANG['shopping-cart_f246a17c095de09e043cc1cb917481da'] = 'Total frais de port (HT)';
$_LANG['shopping-cart_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_LANG['shopping-cart_f4e8b53a114e5a17d051ab84d326cae5'] = 'Frais de port';
$_LANG['shopping-cart_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_LANG['shopping-cart_ff578eb1d07934124f4b9339ecfd2bf6'] = 'Récapitulatif de la commande';
$_LANG['sitemap_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Meilleures ventes';
$_LANG['sitemap_042fe826ace5f92b2477da18b0e7d0b7'] = 'Voir mes réductions';
$_LANG['sitemap_0dff7dbe97fdc822935db4663162b9b9'] = 'Gérer mes informations personnelles';
$_LANG['sitemap_1814d65a76028fdfbadab64a5a8076df'] = 'Fournisseurs';
$_LANG['sitemap_1aa668d559a3a32a44796aeee6978a59'] = 'Créer un nouveau compte';
$_LANG['sitemap_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricants';
$_LANG['sitemap_2433db5a329ea473271a3cd8c013362e'] = 'Informations personnelles';
$_LANG['sitemap_24cc85476cb8ec1a03192f09231e742b'] = 'Nos offres';
$_LANG['sitemap_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_LANG['sitemap_2a75c8350e354ef6e2a842dfdf299214'] = 'Voir la liste des fournisseurs';
$_LANG['sitemap_2e62a20e0e24a34b6da16e369b755dde'] = 'Voir un nouveau produit';
$_LANG['sitemap_34305c555e765cb6b4fbb20d4f4d6121'] = 'Voir la liste des fabricants';
$_LANG['sitemap_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_LANG['sitemap_453aceb005ceaf54a47da15fee8b2a26'] = 'Pages vues';
$_LANG['sitemap_48da3f6e6609ef3fce034fd48414e11f'] = 'Gérer mon compte client';
$_LANG['sitemap_5813ce0ec7196c492c97596718f71969'] = 'sitemap';
$_LANG['sitemap_59107b284bf28196b69063b109b644ef'] = 'Nos magasins';
$_LANG['sitemap_60df547fe45851a472b9680811b3689d'] = 'Voir mon historique de commande';
$_LANG['sitemap_775dc7a055a18907b183037a80c6eed9'] = 'Voir mon carnet d\'adresses';
$_LANG['sitemap_782c8b38bce4f2f6975ca7f33ac8189b'] = 'Historique de vos commandes';
$_LANG['sitemap_9d5bf15117441a1b52eb1f0808e4aad3'] = 'Réductions';
$_LANG['sitemap_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_LANG['sitemap_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Votre compte';
$_LANG['sitemap_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_LANG['sitemap_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_LANG['sitemap_c70dd243e00d616ac8d4fa6949e46b26'] = 'Voir une des meilleures ventes';
$_LANG['sitemap_c75f7811d70d17dbcd88e9d03752cbed'] = 'Identifiez-vous';
$_LANG['sitemap_c87aacf5673fada1108c9f809d354311'] = 'Déconnexion';
$_LANG['sitemap_c8f312df214e2295809027c6ca79d232'] = 'Promotions';
$_LANG['sitemap_d5ccde648010f8198e3506b1e4e1d318'] = 'Voir un produit en promotion';
$_LANG['store_infos_5792315f09a5d54fb7e3d066672b507f'] = 'Mardi';
$_LANG['store_infos_6f8522e0610541f1ef215a22ffa66ff6'] = 'Lundi';
$_LANG['store_infos_78ae6f0cd191d25147e252dc54768238'] = 'Jeudi';
$_LANG['store_infos_796c163589f295373e171842f37265d5'] = 'Mercredi';
$_LANG['store_infos_8b7051187b9191cdcdae6ed5a10e5adc'] = 'Samedi';
$_LANG['store_infos_9d1a0949c39e66a0cd65240bc0ac9177'] = 'Dimanche';
$_LANG['store_infos_c33b138a163847cdb6caeeb7c9a126b4'] = 'Vendredi';
$_LANG['stores_0aa6f4210bf373c95eda00232e93cd98'] = 'Distance';
$_LANG['stores_0e2fb5b02182fd28b9b96e86ed27838f'] = 'Fax :';
$_LANG['stores_12e8c7785484eb1547a9793a6b8603f9'] = 'Votre adresse :';
$_LANG['stores_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_LANG['stores_23a5151445e0c061a51e74989d74ce44'] = 'Horaires';
$_LANG['stores_326684a8cb097db086be681022d9ae46'] = 'Rayon :';
$_LANG['stores_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_LANG['stores_673ae02fffb72f0fe68a66f096a01347'] = 'Tél. :';
$_LANG['stores_6a1e265f92087bb6dd18194833fe946b'] = 'E-mail :';
$_LANG['stores_7ab6c2300ac1d74d35cadcfb39254827'] = 'Aucun magasin trouvé, essayez de sélectionner un rayon plus large';
$_LANG['stores_8519118a6eee0dcbb6118528f3f7febb'] = 'Adresse, code postal, ville, état ou pays';
$_LANG['stores_8c2857a9ad1d8f31659e35e904e20fa6'] = 'Logo';
$_LANG['stores_9e076f5885f5cc16a4b5aeb8de4adff5'] = 'Introuvable';
$_LANG['stores_a9407a9201ef1b64f0c567ed291574ba'] = 'Itinéraire';
$_LANG['stores_af9cbba00fbb4f354bab26d24fa44183'] = 'Adresse du magasin';
$_LANG['stores_c3d0689b0ded3217c1b4fef6e9513930'] = 'boutiques trouvées - voir les résultats :';
$_LANG['stores_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_LANG['stores_dd8e04bdafcdc0ff0a6be34cd74394c0'] = 'Saisissez un lieu (ex. : un code postal, une adresse, une ville ou un pays) afin de trouver les boutiques les plus proches.';
$_LANG['stores_e72dca5d5a8a4706a206f3225324bf44'] = 'Nom du magasin';
$_LANG['stores_e80ba8cf66845d479eb275578353e358'] = 'boutique trouvée - voir les détails :';
$_LANG['stores_f8be99e56d4207f6df76e12bd32e0fea'] = 'Voici la liste détaillée de nos magasins, n\'hésitez pas à nous contacter :';
$_LANG['stores_fdb0c388de01d545017cdf9ccf00eb72'] = 'Magasin';
$_LANG['supplier-list_0397cbccfd02272abd38f8933b865218'] = '%d produit';
$_LANG['supplier-list_44cc6cf69e752cd267e29e71ac4175ff'] = 'Il n\'y a aucun fournisseur.';
$_LANG['supplier-list_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_LANG['supplier-list_5174d1309f275ba6f275db3af9eb3e18'] = 'Grille';
$_LANG['supplier-list_70e0158b4815b0ad6be5f86a11e3a3b4'] = 'Il y a %d fournisseurs.';
$_LANG['supplier-list_864c665aea5e824772fda0e678c3ac4d'] = '%d produits';
$_LANG['supplier-list_a00e46e856e637f8fd077b4fd710c9e2'] = 'Fournisseurs :';
$_LANG['supplier-list_bf1f33501d576cce01509b67e2260242'] = 'Il y a %d fournisseur.';
$_LANG['supplier-list_c61ab4204f572e9b3aa84a040e0dab31'] = 'voir les produits';
$_LANG['supplier-list_df25de42c84837baf5fa15049a8bc764'] = 'Afficher :';
$_LANG['supplier_4bbacadd33aff22ab7468fa4f9efd717'] = 'Liste des produits du fournisseur';
$_LANG['supplier_71a863ca23a2b5d1dc82e60b908576b5'] = 'Pas de produit pour ce fournisseur.';

?>