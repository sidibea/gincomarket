<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Theme configurator';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_cf8fdaf6e745133c90516eb9b74e31c3'] = 'Configure the main elements of your theme.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_dd2eaa9871e00e3c9242934ce942c27c'] = 'Over 800 PrestaShop premium templates! Browse now!';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_ec870aa68b135c4f3adc9a3a2731ddbc'] = 'Can\'t delete the slide.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_3ee0c881516fce384747e3107dbfc538'] = 'Invalid content';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_dd2681ec1593dd537587be3389ee24d3'] = 'An error occurred while saving data.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_b9099a0a16c40efc8b73f548144d472f'] = 'Successfully updated.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'An error occurred during the image upload.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_dccadfc1bf4714d72add6b2332505009'] = 'New item successfully added.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_058e1168dd26085fe8d317effdf70dc3'] = 'Only you can see this on your Front-Office - your visitors will not see this tool.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_6e3670bb5e3826106c5243b242cc52d9'] = 'Display links to your store\'s social accounts (Twitter, Facebook, etc.)';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_1334ff714a38e8004e9cdc755baa5afb'] = 'Display your contact information';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_2f4fe84a25dc0024c9e80b4efd1d68f6'] = 'Display social sharing buttons on the product\'s page';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_6080ab31226b39af728c2d40fd57f0d0'] = 'Display the Facebook block on the home page';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_2debd734d0a150ccfd48e8d1e8e914b0'] = 'Display the custom CMS information block';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_bfebda351190d4dbbd3499558175c7b9'] = 'Display quick view window on homepage and category pages';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_5e8fbd010bca773512f58a4dcd89ed13'] = 'Display categories as a list of products instead of the default grid-based display';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_419e2c499b79ae49a7d50b510cddc28e'] = 'Display top banner';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_2393b3a8e21e442273b6ad9219f4786c'] = 'Display logos of available payment methods';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_905791e2e93ced2cb9b092985604cc55'] = 'Display Live Configurator';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_2e4a0101b1ea2b15782a07dd34067447'] = 'This customization tool allows you to make color and font changes in your theme.';
$_MODULE['<{themeconfigurator}blanktheme>themeconfigurator_638c5a51a25a56ae4b8d6fa975be0d59'] = 'Display subcategories';
$_MODULE['<{themeconfigurator}blanktheme>items_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{themeconfigurator}blanktheme>items_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{themeconfigurator}blanktheme>items_d3d2e617335f08df83599665eef8a418'] = 'Close';
$_MODULE['<{themeconfigurator}blanktheme>items_e8cf85cec621489ec026f7e06c67eb4e'] = 'Delete item';
$_MODULE['<{themeconfigurator}blanktheme>items_2faec1f9f8cc7f8f40d521c4dd574f49'] = 'Enable';
$_MODULE['<{themeconfigurator}blanktheme>items_cf82fa946fab5855cd8c6479b0eb95d1'] = 'Image title';
$_MODULE['<{themeconfigurator}blanktheme>items_2c92d496fa8efe3d5b2b38c185f9b7f7'] = 'Use title in front';
$_MODULE['<{themeconfigurator}blanktheme>items_91081fbf39583a57fdde5efa138d0564'] = 'Hook to which the image should be attached';
$_MODULE['<{themeconfigurator}blanktheme>items_100eb3bd7b79830fe86288a63e13d485'] = 'Load your image';
$_MODULE['<{themeconfigurator}blanktheme>items_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Image width';
$_MODULE['<{themeconfigurator}blanktheme>items_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Image height';
$_MODULE['<{themeconfigurator}blanktheme>items_0eff773cf33456a033e913f6ed18045c'] = 'Target link';
$_MODULE['<{themeconfigurator}blanktheme>items_78698b9b0fa4eaac0876da3a900d5024'] = 'Open link in a new tab/page';
$_MODULE['<{themeconfigurator}blanktheme>items_9e728651dbd9d313504d86294e193249'] = 'Optional HTML code';
$_MODULE['<{themeconfigurator}blanktheme>items_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{themeconfigurator}blanktheme>items_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{themeconfigurator}blanktheme>items_f453e0c33edd79653febd0b9bc8f09b3'] = 'No items available';
$_MODULE['<{themeconfigurator}blanktheme>new_ff19c966036b4a0c7350b2fc7e2861c2'] = 'Add item';
$_MODULE['<{themeconfigurator}blanktheme>new_4994a8ffeba4ac3140beb89e8d41f174'] = 'Language';
$_MODULE['<{themeconfigurator}blanktheme>new_cf82fa946fab5855cd8c6479b0eb95d1'] = 'Image title';
$_MODULE['<{themeconfigurator}blanktheme>new_2c92d496fa8efe3d5b2b38c185f9b7f7'] = 'Use title in front';
$_MODULE['<{themeconfigurator}blanktheme>new_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{themeconfigurator}blanktheme>new_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{themeconfigurator}blanktheme>new_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Image width';
$_MODULE['<{themeconfigurator}blanktheme>new_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Image height';
$_MODULE['<{themeconfigurator}blanktheme>new_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{themeconfigurator}blanktheme>new_4c87eb073eb09f42281d7e67aeacb223'] = 'Target blank';
$_MODULE['<{themeconfigurator}blanktheme>new_4c4ad5fca2e7a3f74dbb1ced00381aa4'] = 'HTML';
$_MODULE['<{themeconfigurator}blanktheme>new_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{themeconfigurator}blanktheme>new_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'The customization tool allows you to make color and font changes in your theme.';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_c71534403c6e05ffbb8684ae96aac550'] = 'Only you can see this tool, because as you are currently connected to your back-office as an admin; your visitors will not see it.';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_45e035baf33a8e403766a606457f8b10'] = 'Theme color';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Font';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_9a2c00f5f6df185a8d7d421ee70ccddf'] = 'Title font';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_ea3aba27f515989b46d990e95a097818'] = 'Choose a font';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_526d688f37a86d3c3f27d0c5016eb71d'] = 'Reset';
$_MODULE['<{themeconfigurator}blanktheme>live_configurator_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
