<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{bankwire}prestashop>bankwire_85ee0d0492a4e37e6c183520f5d59c40'] = 'Bonifico Bancario';
$_MODULE['<{bankwire}prestashop>bankwire_65104b0722c068ec3e8ac48153af597b'] = 'Accetta pagamenti tramite bonifico bancario.';
$_MODULE['<{bankwire}prestashop>bankwire_cbe0a99684b145e77f3e14174ac212e3'] = 'Sei sicuro di voler cancellare questi dati?';
$_MODULE['<{bankwire}prestashop>bankwire_0ea0227283d959415eda0cfa31d9f718'] = 'Il proprietario dell\'account e i dati devono essere configurati per usare questo modulo correttamente.';
$_MODULE['<{bankwire}prestashop>bankwire_a02758d758e8bec77a33d7f392eb3f8a'] = 'Nessuna valuta impostata per questo modulo.';
$_MODULE['<{bankwire}prestashop>bankwire_bfa43217dfe8261ee7cb040339085677'] = 'I dati dell\'account sono obbligatori.';
$_MODULE['<{bankwire}prestashop>bankwire_ccab155f173ac76f79eb192703f86b18'] = 'Il proprietario dell\'account è obbligatorio.';
$_MODULE['<{bankwire}prestashop>bankwire_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{bankwire}prestashop>bankwire_c1be305030739396775edaca9813f77d'] = 'Questo modulo ti permette di accettare pagamenti tramite bonifico bancario.';
$_MODULE['<{bankwire}prestashop>bankwire_c2886e6bed60f357b08b6e99ac390c25'] = 'Se il cliente sceglie questa modalità di pagamento, l\'ordine cambierà il proprio status in \'attesa di pagamento\'.';
$_MODULE['<{bankwire}prestashop>bankwire_f001fc4497defe598043407d06be06e5'] = 'Pertanto, dovrai confermare l\'ordine non appena ricevi il bonifico';
$_MODULE['<{bankwire}prestashop>bankwire_5dd532f0a63d89c5af0243b74732f63c'] = 'Informazioni di contatto';
$_MODULE['<{bankwire}prestashop>bankwire_51634daae434ad5789f89024b20e4dac'] = 'Specifica i dati del bonifico bancario per i clienti.';
$_MODULE['<{bankwire}prestashop>bankwire_857216dd1b374de9bf54068fcd78a8f3'] = 'Intestatario del conto';
$_MODULE['<{bankwire}prestashop>bankwire_3ec365dd533ddb7ef3d1c111186ce872'] = 'Dati';
$_MODULE['<{bankwire}prestashop>bankwire_5fe24fbb39b58daacb7c7905ba6e3534'] = 'Come filiale della banca, codice IBAN, BIC, ecc...';
$_MODULE['<{bankwire}prestashop>bankwire_f9a1a1bb716cbae0503d351ea2af4b34'] = 'Indirizzo della banca';
$_MODULE['<{bankwire}prestashop>bankwire_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna le impostazioni';
$_MODULE['<{bankwire}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'Questo metodo di pagamento non è disponibile.';
$_MODULE['<{bankwire}prestashop>payment_execution_99227bacb2b4dfa29ce1701ac265a923'] = 'Pagamento bonifico bancario.';
$_MODULE['<{bankwire}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = 'Sintesi dell\'ordine';
$_MODULE['<{bankwire}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = 'Il carrello è vuoto.';
$_MODULE['<{bankwire}prestashop>payment_execution_05adcee99142c1a60fb38bb1330bbbc1'] = 'Bonifico bancario';
$_MODULE['<{bankwire}prestashop>payment_execution_afda466128ee0594745d9f8152699b74'] = 'Hai scelto di pagare con bonifico bancario.';
$_MODULE['<{bankwire}prestashop>payment_execution_c884ed19483d45970c5bf23a681e2dd2'] = 'Ecco un breve riepilogo del tuo ordine:';
$_MODULE['<{bankwire}prestashop>payment_execution_e2867a925cba382f1436d1834bb52a1c'] = 'L\'importo totale del tuo ordine è';
$_MODULE['<{bankwire}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = '(tasse incl.)';
$_MODULE['<{bankwire}prestashop>payment_execution_b28be4c423d93e02081f4e79fe2434e8'] = 'Si accettano diverse valute da inviare tramite bonifico bancario.';
$_MODULE['<{bankwire}prestashop>payment_execution_a7a08622ee5c8019b57354b99b7693b2'] = 'Scegli una delle seguenti:';
$_MODULE['<{bankwire}prestashop>payment_execution_a854d894458d66d92cabf0411c499ef4'] = 'Accettiamo le seguente valute da inviare tramite bonifico bancario:';
$_MODULE['<{bankwire}prestashop>payment_execution_3dd021316505c0204989f984246c6ff1'] = 'Le informazioni sul conto corrente saranno visualizzate nella pagina successiva.';
$_MODULE['<{bankwire}prestashop>payment_execution_93c1f9dffc8c38b2c108d449a9181d92'] = 'Conferma l\'ordine cliccando su \'confermo il mio ordine\'';
$_MODULE['<{bankwire}prestashop>payment_execution_baa62374832554652160fe5a827b2741'] = 'Confermo il mio ordine';
$_MODULE['<{bankwire}prestashop>payment_execution_569fd05bdafa1712c4f6be5b153b8418'] = 'Altri metodi di pagamento';
$_MODULE['<{bankwire}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Il tuo ordine su %s è completo.';
$_MODULE['<{bankwire}prestashop>payment_return_1f8cdc30326f1f930b0c87b25fdac965'] = 'Inviaci un bonifico bancario con';
$_MODULE['<{bankwire}prestashop>payment_return_b2f40690858b404ed10e62bdf422c704'] = 'Importo';
$_MODULE['<{bankwire}prestashop>payment_return_5ca0b1b910f393ed1f9f6fa99e414255'] = 'Beneficiario';
$_MODULE['<{bankwire}prestashop>payment_return_d717aa33e18263b8405ba00e94353cdc'] = 'Con questi dati';
$_MODULE['<{bankwire}prestashop>payment_return_984482eb9ff11e6310fef641d2268a2a'] = 'Istituto bancario';
$_MODULE['<{bankwire}prestashop>payment_return_63fb3f7c94ee5d8027bf599885de279d'] = 'Non dimenticarti di inserire il tuo numero d\'ordine n.%d nel campo oggetto del tuo bonifico';
$_MODULE['<{bankwire}prestashop>payment_return_1faa25b80a8d31e5ef25a78d3336606d'] = 'Non dimenticarti di inserire il riferimento d\'ordine %s nel campo oggetto del tuo bonifico.';
$_MODULE['<{bankwire}prestashop>payment_return_19c419a8a4f1cd621853376a930a2e24'] = 'Ti è stata inviata una email con queste informazioni.';
$_MODULE['<{bankwire}prestashop>payment_return_b9a1cae09e5754424e33764777cfcaa0'] = 'Il tuo ordine verrà inviato non appena avremo ricevuto la tua transazione.';
$_MODULE['<{bankwire}prestashop>payment_return_ca7e41a658753c87973936d7ce2429a8'] = 'Per eventuali domande o per ulteriori informazioni, contatta la nostra';
$_MODULE['<{bankwire}prestashop>payment_return_dfe239de8c0b2453a8e8f7657a191d5d'] = 'assistenza clienti';
$_MODULE['<{bankwire}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'Abbiamo notato un problema con il tuo ordine. Se pensi che sia un errore, puoi contattare il nostro';
$_MODULE['<{bankwire}prestashop>payment_5e1695822fc5af98f6b749ea3cbc9b4c'] = 'Paga con bonifico bancario';
$_MODULE['<{bankwire}prestashop>payment_eb1d50032721fa4c9d3518c417f91b9d'] = 'Paga con bonifico bancario (l\'elaborazione dell\'ordine sarà più lunga)';
