<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}blanktheme>statsequipment_247270d410e2b9de01814b82111becda'] = 'Navigateurs web et systèmes d\'exploitation';
$_MODULE['<{statsequipment}blanktheme>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Ajoute un onglet contenant un graphique des navigateurs web et systèmes d\'exploitation utilisé, dans le tableau de bord des statistiques.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}blanktheme>statsequipment_854c8e126f839cc861cde822b641230e'] = 'S\'assurer que votre site web est accessible au plus grand nombre de personnes possible';
$_MODULE['<{statsequipment}blanktheme>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Indique la popularité de chaque navigateur, en pourcentage d\'utilisation sur la base de vos clients.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsequipment}blanktheme>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Indique le pourcentage de chaque système d\'exploitation utilisé par les clients.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Extensions';
$_MODULE['<{statsequipment}blanktheme>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Navigateurs utilisés';
$_MODULE['<{statsequipment}blanktheme>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Systèmes d\'exploitation utilisés';
