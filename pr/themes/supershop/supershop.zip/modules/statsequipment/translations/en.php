<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}blanktheme>statsequipment_247270d410e2b9de01814b82111becda'] = 'Browsers and operating systems';
$_MODULE['<{statsequipment}blanktheme>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Adds a tab containing graphs about web browser and operating system usage to the Stats dashboard.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}blanktheme>statsequipment_854c8e126f839cc861cde822b641230e'] = 'Making sure that your website is accessible to as many people as possible';
$_MODULE['<{statsequipment}blanktheme>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Indicates the percentage of each web browser used by customers.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
$_MODULE['<{statsequipment}blanktheme>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Indicates the percentage of each operating system used by customers.';
$_MODULE['<{statsequipment}blanktheme>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Plugins';
$_MODULE['<{statsequipment}blanktheme>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Web browser used';
$_MODULE['<{statsequipment}blanktheme>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Operating system used';
