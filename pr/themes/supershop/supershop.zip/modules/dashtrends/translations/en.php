<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dashtrends}blanktheme>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashtrends}blanktheme>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_MODULE['<{dashtrends}blanktheme>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Average Cart Value';
$_MODULE['<{dashtrends}blanktheme>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Visits';
$_MODULE['<{dashtrends}blanktheme>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Conversion Rate';
$_MODULE['<{dashtrends}blanktheme>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Net Profit';
$_MODULE['<{dashtrends}blanktheme>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (previous period)';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Dashboard';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Cart Value';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Visits';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Conversion Rate';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Net Profit';
