<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dashtrends}blanktheme>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{dashtrends}blanktheme>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{dashtrends}blanktheme>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Panier moyen';
$_MODULE['<{dashtrends}blanktheme>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{dashtrends}blanktheme>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Taux de transformation';
$_MODULE['<{dashtrends}blanktheme>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Bénéfice net';
$_MODULE['<{dashtrends}blanktheme>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (période précédente)';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Tableau de bord';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Panier Moyen';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Taux de transformation';
$_MODULE['<{dashtrends}blanktheme>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Bénéfice net';
