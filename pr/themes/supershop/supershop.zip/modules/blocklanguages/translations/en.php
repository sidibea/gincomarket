<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}blanktheme>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Adds a block allowing customers to select a language for your store\'s content.';
