<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{groupcategory}blanktheme>default.option1.layout_88559a0cfd8250c9d65970cc145c92d4'] = 'OFF';
$_MODULE['<{groupcategory}blanktheme>default.option3.layout_88559a0cfd8250c9d65970cc145c92d4'] = 'OFF';
$_MODULE['<{groupcategory}blanktheme>default.option4.layout_88559a0cfd8250c9d65970cc145c92d4'] = 'OFF';
