<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pages not found';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Adds a tab to the Stats dashboard, showing the pages requested by your visitors that have not been found.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'The \"pages not found\" cache has been emptied.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'The \"pages not found\" cache has been deleted.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = '404 errors';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'How to catch these errors?';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'If your webhost supports .htaccess files, you can create one in the root directory of PrestaShop and insert the following line inside: \"%s\".';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'A user requesting a page which doesn\'t exist will be redirected to the following page: %s. This module logs access to this page.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'You must use a .htaccess file to redirect 404 errors to the \"404.php\" page.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Page';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referrer';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Counter';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'No \"page not found\" issue registered for now.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Empty database';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Empty ALL \"pages not found\" notices for this period';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Empty ALL \"pages not found\" notices';
