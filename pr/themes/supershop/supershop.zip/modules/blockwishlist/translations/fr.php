<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_4a84e5921e203aede886d04fc41a414b'] = 'Enlever ce produit de ma liste';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Détails de l\'article';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_d037160cfb1fa5520563302d3a32630a'] = 'Vous devez créer une liste avant d\'ajouter un produit';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_09dc02ecbb078868a3a86dded030076d'] = 'Aucun produit';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_2d96bb66d8541a89620d3c158ceef42b'] = 'Ajouter à ma liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_15b94c64c4d5a4f7172e5347a36b94fd'] = 'Ajouter à ma liste';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_2715a65604e1af3d6933b61704865daf'] = 'Bloc liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_7244141a5de030c4c882556f4fd70a8b'] = 'Ajoute un bloc gérant les listes de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_9ae79c1fccd231ac7fbbf3235dbf6326'] = 'Ma liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_5ef2d617096ae7b47a83f3d4de9c84bd'] = 'Choix invalide pour l\'activation du module';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour réussie';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priorité';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_655d20c1ca69519ca647684edbb2db35'] = 'Haute';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Moyenne';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Basse';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_e0fd9b310aba555f96e76738ff192ac3'] = 'Listes de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_862af8838fba380d3b30e63546a394e5'] = 'n\'a pas de liste cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_641254d77e7a473aa5910574f3f9453c'] = 'Liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_88b589bbf6282a2e02f50ebe90aae6f1'] = 'Vous devez être identifié pour gérer vos liste voeux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_56ee3495a32081ccb6d2376eab391bfa'] = 'Liste';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_6bee4060e5e05246d4bcbb720736417c'] = 'Clients :';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c515b215b9c6be251c924cc6d1324c41'] = 'Choisissez un client';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c440899c1d6f8c8271b9b1d171c7e665'] = 'Liste de souhaits';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_12246cb491c807e85279b8aed74ea3cf'] = 'Choisissez la liste de souhaits';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_47ac923d219501859fb68fed8c8db77b'] = 'Déclinaison';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_81355310011c137fdd21cf9a1394ed6a'] = 'Liste des produits';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_7ec9cceb94985909c6994e95c31c1aa8'] = 'Mes listes';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_4a84e5921e203aede886d04fc41a414b'] = 'Enlever ce produit de ma liste';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_09dc02ecbb078868a3a86dded030076d'] = 'Aucun produit';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_top_16a23698e7cf5188ce1c07df74298076'] = 'Vous devez être connecté pour gérer votre liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_top_ab086554d10bb35f820e7a704105abbf'] = 'Ajouté à votre liste de cadeaux.';
$_MODULE['<{blockwishlist}blanktheme>buywishlistproduct_607e1d854783c8229998ac2b5b6923d3'] = 'Jeton non valable';
$_MODULE['<{blockwishlist}blanktheme>buywishlistproduct_b0ffc4925401f6f4edb038f5ca954937'] = 'Vous devez vous connecter';
$_MODULE['<{blockwishlist}blanktheme>cart_607e1d854783c8229998ac2b5b6923d3'] = 'Jeton non valable';
$_MODULE['<{blockwishlist}blanktheme>cart_a9839ad48cf107667f73bad1d651f2ca'] = 'Aucun template trouvé';
$_MODULE['<{blockwishlist}blanktheme>cart_16a23698e7cf5188ce1c07df74298076'] = 'Vous devez être connecté pour gérer votre liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_a9839ad48cf107667f73bad1d651f2ca'] = 'Aucun template trouvé';
$_MODULE['<{blockwishlist}blanktheme>my-account_7ec9cceb94985909c6994e95c31c1aa8'] = 'Mes listes';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_8f4be21ec3cfbba15a349e9c5e888579'] = 'Jeton non valable';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_90d8a44a1fba13198035d86caeeb2d4d'] = 'Liste de cadeaux invalide';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_072df51ea0cb142b770d6209dab5a85b'] = 'Erreur d\'envoi de liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_607e1d854783c8229998ac2b5b6923d3'] = 'Jeton non valable';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_b30545c7b2d429352b9afdd85be810c7'] = 'Vous devez spécifier un nom.';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_b74c118d823d908d653cfbf1c877ae55'] = 'Ce nom est déjà utilisé pour une autre liste.';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7098d49878bbd102b13038a748125e27'] = 'Impossible de supprimer cette liste de cadeaux.';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_19820cd537251a176ab012ac1b484fff'] = 'Erreur lors du déplacement du produit vers une autre liste';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_3540aa14bffcdfbbfc3aafbbcb028a1f'] = 'Le produit a bien été changé de liste';
$_MODULE['<{blockwishlist}blanktheme>view_655d20c1ca69519ca647684edbb2db35'] = 'Haute';
$_MODULE['<{blockwishlist}blanktheme>view_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Moyenne';
$_MODULE['<{blockwishlist}blanktheme>view_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Basse';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_f78674b9c6b19504756230c57f6aec38'] = 'Fermer cette liste';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0ac1aeb2429db494dd42ad2dc219ca7e'] = 'Cacher les produits';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0de9d09a36e820f9da7e87ab3678dd12'] = 'Afficher les produits';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_e0977812a2d99e320fcaac92ff096b43'] = 'Masquer les produits achetés';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_b1cf536563bc3b97ee404dab65db3a27'] = 'Afficher les produits achetés';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_8725214cdd9f9af24e914b5da135793d'] = 'Lien permanent';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_30820a1bf6a285e45cda2beda3d7738d'] = 'Envoyer cette liste';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Détails de l\'article';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priorité';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_655d20c1ca69519ca647684edbb2db35'] = 'Haute';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Moyenne';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Basse';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_e68ee0c6758ab5b0eea4e105d694f5c4'] = 'Déplacer vers %s';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_3384622e86410fd01fa318fedc6a98ce'] = 'Offert par';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_09dc02ecbb078868a3a86dded030076d'] = 'Aucun produit';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7ec9cceb94985909c6994e95c31c1aa8'] = 'Mes listes';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_06c335f27f292a096a9bf39e3a58e97b'] = 'Nouvelle liste';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_03ab340b3f99e03cff9e84314ead38c0'] = 'Quantité';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_5e729042e30967c9d6f65c6eab73e2fe'] = 'Vues';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_0eceeb45861f9585dd7a97a3e36f85c6'] = 'Créé le';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_45284ef16392f85ff424b2ef36ab5948'] = 'Lien direct';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7a1920d61156abc05a60135aefe8bc67'] = 'Par défaut';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_d025259319054206be54336a00defe89'] = 'Souhaitez-vous réellement supprimer cette liste ?';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_0b3db27bc15f682e92ff250ebb167d4b'] = 'Retour à votre compte';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_MODULE['<{blockwishlist}blanktheme>view_641254d77e7a473aa5910574f3f9453c'] = 'Liste de cadeaux';
$_MODULE['<{blockwishlist}blanktheme>view_315356f4c2ed70df345ffc01021f7f56'] = 'Autres listes de %1s %2s';
$_MODULE['<{blockwishlist}blanktheme>view_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Détails de l\'article';
$_MODULE['<{blockwishlist}blanktheme>view_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_MODULE['<{blockwishlist}blanktheme>view_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priorité';
$_MODULE['<{blockwishlist}blanktheme>view_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
$_MODULE['<{blockwishlist}blanktheme>view_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0bb3e067c0514f5ff2d5a8e45fc0f4be'] = 'Cacher les informations des produits achetés';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_6fe88f5681da397d46fefe19b3020a6a'] = 'Afficher les informations des produits achetés';
$_MODULE['<{blockwishlist}blanktheme>view_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_MODULE['<{blockwishlist}blanktheme>view_7ec9cceb94985909c6994e95c31c1aa8'] = 'Mes listes';
