<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_4a84e5921e203aede886d04fc41a414b'] = 'remove this product from my wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Product detail';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_d037160cfb1fa5520563302d3a32630a'] = 'You must create a wishlist before adding products';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-ajax_09dc02ecbb078868a3a86dded030076d'] = 'No products';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_2d96bb66d8541a89620d3c158ceef42b'] = 'Add to wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_ec211f7c20af43e742bf2570c3cb84f9'] = 'Add';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist-extra_15b94c64c4d5a4f7172e5347a36b94fd'] = 'Add to my wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_2715a65604e1af3d6933b61704865daf'] = 'Wishlist block';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_7244141a5de030c4c882556f4fd70a8b'] = 'Adds a block containing the customer\'s wishlists.';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_9ae79c1fccd231ac7fbbf3235dbf6326'] = 'My wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_5ef2d617096ae7b47a83f3d4de9c84bd'] = 'Activate module : Invalid choice.';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_deb10517653c255364175796ace3553f'] = 'Product';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priority';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_655d20c1ca69519ca647684edbb2db35'] = 'High';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Medium';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Low';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_e0fd9b310aba555f96e76738ff192ac3'] = 'Wishlists';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_862af8838fba380d3b30e63546a394e5'] = 'No wishlist.';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_641254d77e7a473aa5910574f3f9453c'] = 'Wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_88b589bbf6282a2e02f50ebe90aae6f1'] = 'You must be logged in to manage your wishlists.';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_56ee3495a32081ccb6d2376eab391bfa'] = 'Listing';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_6bee4060e5e05246d4bcbb720736417c'] = 'Customers :';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c515b215b9c6be251c924cc6d1324c41'] = 'Choose customer';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_c440899c1d6f8c8271b9b1d171c7e665'] = 'Wishlist :';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_12246cb491c807e85279b8aed74ea3cf'] = 'Choose wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_47ac923d219501859fb68fed8c8db77b'] = 'Combination';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_81355310011c137fdd21cf9a1394ed6a'] = 'Product list';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_7ec9cceb94985909c6994e95c31c1aa8'] = 'My wishlists';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_4a84e5921e203aede886d04fc41a414b'] = 'remove this product from my wishlist';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_09dc02ecbb078868a3a86dded030076d'] = 'No products';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_top_16a23698e7cf5188ce1c07df74298076'] = 'You must be logged in to manage your wishlist.';
$_MODULE['<{blockwishlist}blanktheme>blockwishlist_top_ab086554d10bb35f820e7a704105abbf'] = 'Added to your wishlist.';
$_MODULE['<{blockwishlist}blanktheme>buywishlistproduct_607e1d854783c8229998ac2b5b6923d3'] = 'Invalid token';
$_MODULE['<{blockwishlist}blanktheme>buywishlistproduct_b0ffc4925401f6f4edb038f5ca954937'] = 'You must log in';
$_MODULE['<{blockwishlist}blanktheme>cart_607e1d854783c8229998ac2b5b6923d3'] = 'Invalid token';
$_MODULE['<{blockwishlist}blanktheme>cart_a9839ad48cf107667f73bad1d651f2ca'] = 'No template found';
$_MODULE['<{blockwishlist}blanktheme>cart_16a23698e7cf5188ce1c07df74298076'] = 'You must be logged in to manage your wishlist.';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_a9839ad48cf107667f73bad1d651f2ca'] = 'No template found';
$_MODULE['<{blockwishlist}blanktheme>my-account_7ec9cceb94985909c6994e95c31c1aa8'] = 'My wishlists';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_8f4be21ec3cfbba15a349e9c5e888579'] = 'invalid token';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_90d8a44a1fba13198035d86caeeb2d4d'] = 'Invalid wishlist';
$_MODULE['<{blockwishlist}blanktheme>sendwishlist_072df51ea0cb142b770d6209dab5a85b'] = 'Wishlist send error';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_607e1d854783c8229998ac2b5b6923d3'] = 'Invalid token';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_b30545c7b2d429352b9afdd85be810c7'] = 'You must specify a name.';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_b74c118d823d908d653cfbf1c877ae55'] = 'This name is already used by another list.';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7098d49878bbd102b13038a748125e27'] = 'Cannot delete this wishlist';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_19820cd537251a176ab012ac1b484fff'] = 'Error while moving product to another list';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_3540aa14bffcdfbbfc3aafbbcb028a1f'] = 'The product has been correctly moved';
$_MODULE['<{blockwishlist}blanktheme>view_655d20c1ca69519ca647684edbb2db35'] = 'High';
$_MODULE['<{blockwishlist}blanktheme>view_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Medium';
$_MODULE['<{blockwishlist}blanktheme>view_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Low';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_f78674b9c6b19504756230c57f6aec38'] = 'Close this wishlist';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0ac1aeb2429db494dd42ad2dc219ca7e'] = 'Hide products';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0de9d09a36e820f9da7e87ab3678dd12'] = 'Show products';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_e0977812a2d99e320fcaac92ff096b43'] = 'Hide bought products\' info';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_b1cf536563bc3b97ee404dab65db3a27'] = 'Show bought products\' info';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_8725214cdd9f9af24e914b5da135793d'] = 'Permalink';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_30820a1bf6a285e45cda2beda3d7738d'] = 'Send this wishlist';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Product detail';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priority';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_655d20c1ca69519ca647684edbb2db35'] = 'High';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Medium';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Low';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_e68ee0c6758ab5b0eea4e105d694f5c4'] = 'Move to %s';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_19f823c6453c2b1ffd09cb715214813d'] = 'Required field';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_deb10517653c255364175796ace3553f'] = 'Product';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_3384622e86410fd01fa318fedc6a98ce'] = 'Offered by';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_09dc02ecbb078868a3a86dded030076d'] = 'No products';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'My account';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7ec9cceb94985909c6994e95c31c1aa8'] = 'My wishlists';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_06c335f27f292a096a9bf39e3a58e97b'] = 'New wishlist';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_03ab340b3f99e03cff9e84314ead38c0'] = 'Qty';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_5e729042e30967c9d6f65c6eab73e2fe'] = 'Viewed';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_0eceeb45861f9585dd7a97a3e36f85c6'] = 'Created';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_45284ef16392f85ff424b2ef36ab5948'] = 'Direct Link';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_7a1920d61156abc05a60135aefe8bc67'] = 'Default';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_d025259319054206be54336a00defe89'] = 'Do you really want to delete this wishlist ?';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_0b3db27bc15f682e92ff250ebb167d4b'] = 'Back to Your Account';
$_MODULE['<{blockwishlist}blanktheme>mywishlist_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
$_MODULE['<{blockwishlist}blanktheme>view_641254d77e7a473aa5910574f3f9453c'] = 'Wishlist';
$_MODULE['<{blockwishlist}blanktheme>view_315356f4c2ed70df345ffc01021f7f56'] = 'Other wishlists of %1s %2s:';
$_MODULE['<{blockwishlist}blanktheme>view_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Product detail';
$_MODULE['<{blockwishlist}blanktheme>view_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantity';
$_MODULE['<{blockwishlist}blanktheme>view_502996d9790340c5fd7b86a5b93b1c9f'] = 'Priority';
$_MODULE['<{blockwishlist}blanktheme>view_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
$_MODULE['<{blockwishlist}blanktheme>view_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_0bb3e067c0514f5ff2d5a8e45fc0f4be'] = 'Hide bought product\'s info';
$_MODULE['<{blockwishlist}blanktheme>managewishlist_6fe88f5681da397d46fefe19b3020a6a'] = 'Show bought product\'s info';
$_MODULE['<{blockwishlist}blanktheme>view_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'My account';
$_MODULE['<{blockwishlist}blanktheme>view_7ec9cceb94985909c6994e95c31c1aa8'] = 'My wishlists';
