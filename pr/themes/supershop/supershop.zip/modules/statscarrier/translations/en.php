<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscarrier}blanktheme>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Carrier distribution';
$_MODULE['<{statscarrier}blanktheme>statscarrier_b56f2e8e5f8694e8d09cbd8ec27c4e57'] = 'Adds a graph displaying each carriers\' distribution to the Stats dashboard.';
$_MODULE['<{statscarrier}blanktheme>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{statscarrier}blanktheme>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filter';
$_MODULE['<{statscarrier}blanktheme>statscarrier_ff61af405aa570a9000e6ba2da39857a'] = 'This graph represents the carrier distribution for your orders. You can also narrow the focus of the graph to display distribution for a particular order status.';
$_MODULE['<{statscarrier}blanktheme>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
$_MODULE['<{statscarrier}blanktheme>statscarrier_ae916988f1944283efa2968808a71287'] = 'No valid orders have been received for this period.';
$_MODULE['<{statscarrier}blanktheme>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Percentage of orders listed by carrier.';
