<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}blanktheme>productscategory_8a4f5a66d0fcc9d13614516db6e3d47a'] = 'Produits dans la même catégorie';
$_MODULE['<{productscategory}blanktheme>productscategory_1d269d7f013c3d9d891a146f4379eb02'] = 'Ajoute un bloc sur la fiche produit pour afficher des produits de la même catégorie.';
$_MODULE['<{productscategory}blanktheme>productscategory_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Paramètres mis à jour avec succès';
$_MODULE['<{productscategory}blanktheme>productscategory_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{productscategory}blanktheme>productscategory_e06ba84b50810a88438ae0537405f65a'] = 'Afficher les prix des produits';
$_MODULE['<{productscategory}blanktheme>productscategory_1d986024f548d57b1d743ec7ea9b09d9'] = 'Afficher les prix des produits affichés dans le bloc.';
$_MODULE['<{productscategory}blanktheme>productscategory_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{productscategory}blanktheme>productscategory_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{productscategory}blanktheme>productscategory_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{productscategory}blanktheme>productscategory_1f910bcf84a92cb7c71fa3d926c8a525'] = 'Autres produits dans la même catégorie :';
$_MODULE['<{productscategory}blanktheme>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_MODULE['<{productscategory}blanktheme>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
