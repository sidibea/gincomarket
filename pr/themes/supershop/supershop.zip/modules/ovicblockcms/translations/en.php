<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_cdca12007979fc49008fd125cdb775fc'] = 'Adds a block with several CMS links.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ef61fb324d729c341ea8ab9901e23566'] = 'Add new';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_97390dd0b5ba7867120aee2ff22bfa38'] = 'CMS block configuration';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_6f0091f0c2b3ef334a8f5359f462b63f'] = 'CMS Blocks';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0a41f7ebbcf8a28362f8635ca8341d28'] = 'New block';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_528c17398f985a94f4cc7c5b2d32c8c0'] = 'Configuration of the various links in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_c93efb366650d08e5827974c0ddec8d8'] = 'Display various links and information in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_6f3ebe2ce8a7c3b873c1003b6ead60df'] = 'Footer links';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_e363df19c685465bca24d0c06d9394c7'] = 'Please mark every page that you want to display in the footer CMS block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_b0f8cd6eb22f287563dad544796b4118'] = 'Footer information';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_75cb29c17cf91bef81cc289b0dd1b1fa'] = 'Display \"Our stores\" link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0e5da791148c92be6eca8c537a47569e'] = 'Display \"Price drop\" link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_e995cfe1489190cf28799a16d23be91a'] = 'Display \"New products\" link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_edeab890c4f02138691d67eefcbfe7e8'] = 'Display \"Best sales\" link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_45bc5fe3bf5717315e42a831ba7da748'] = 'Display \"Contact us\" link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_68b7b9e603633d155941fb1d665c3997'] = 'Display sitemap link in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_573a06e2ae339eeb4fb19e7f689bd3d8'] = 'Display \"Powered by PrestaShop\" in the footer';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_be58fccb15fb119b8c3d485e3a8561c4'] = 'CMS Block configuration';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0eb46571f3ff926d8b2408cafcfc17e3'] = 'Edit the CMS block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_5aa1602194579edb6f91d7dd53eadb32'] = 'New CMS block';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_dd57f561a17388f38ac26a2f0321776b'] = 'Name of the CMS block';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_51b274d417210e74d2cfe9e0713602f2'] = 'If you leave this field empty, the block name will use the category name by default.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ac37b115bc4e914c9ab63bd4a1c1746a'] = 'CMS category';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ce5bf551379459c1c61d2a204061c455'] = 'Location';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_f9e4884c7654daa6581b42ed90aeaba4'] = 'Left column';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_feb6cc332459769fe15570bf332a6b50'] = 'Right column';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ef0e9df97eac6e978e72eeaf5abb8b0e'] = 'Add link to Store Locator';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_9a8d463045dc8c2ad89bcd455fd937e8'] = 'Adds the \"Our stores\" link at the end of the block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_bbfdbbf61a22c160c5498b6ae08cb356'] = 'CMS content';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_04313a11bf4a501b7cf2273ea7b32862'] = 'Please mark every page that you want to display in this block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0d6d7a7c758cd16507d4aebf18305691'] = 'Invalid store display value.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_4eb9b68883615faa427da721fad14422'] = 'Invalid block location.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_795c54de995b69fe05142dad6f99ef92'] = 'You must choose at least one page -- or subcategory -- in order to create a CMS block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0788bfffae213b06afb540bf06926652'] = 'Invalid CMS page and/or category.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_7125483712689cd7a6f85b466a8a7632'] = 'The block name is too long.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_ede67d50014846cb8bb1b00d5fde77be'] = 'Invalid id_cms_block';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_2d81a9da91ff3f073e6aecbe42c33e69'] = 'Please provide footer text for the default language.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_af979c5a556c7a2c5340a06273046b0d'] = 'Invalid footer activation.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_dc08eb6c896a19dd0f0585ab7205ed17'] = 'Cannot create a block!';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_f3d25e325923cd522fd610bd869d736c'] = 'Error: You are trying to delete a non-existing CMS block.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_0c579767f53365887ac199a96e26c591'] = 'Update your footer\'s information.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_c28716416d2fd75a37b4496586755853'] = 'CMS block added.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_a94db349ae0c662fd55c9d402481165b'] = 'CMS block edited.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_64e1a7a1be29d5937f2eaa90a3d32ad0'] = 'Deletion successful.';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Our stores';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Specials';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'New products';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Top sellers';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contact us';
$_MODULE['<{ovicblockcms}blanktheme>ovicblockcms_5813ce0ec7196c492c97596718f71969'] = 'Sitemap';
$_MODULE['<{ovicblockcms}blanktheme>form_4dabfa54822012dfc78d6ef40f224173'] = 'Left blocks';
$_MODULE['<{ovicblockcms}blanktheme>form_d9ca3009e18447d91cd2e324e8e680ce'] = 'Right blocks';
$_MODULE['<{ovicblockcms}blanktheme>form_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{ovicblockcms}blanktheme>form_83ef1503b3bd9858cc923a74e5f9e917'] = 'Name of the block';
$_MODULE['<{ovicblockcms}blanktheme>form_bb34a159a88035cce7ef1607e7907f8f'] = 'Category name';
$_MODULE['<{ovicblockcms}blanktheme>form_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Position';
$_MODULE['<{ovicblockcms}blanktheme>form_08a38277b0309070706f6652eeae9a53'] = 'Down';
$_MODULE['<{ovicblockcms}blanktheme>form_258f49887ef8d14ac268c92b02503aaa'] = 'Up';
$_MODULE['<{ovicblockcms}blanktheme>form_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{ovicblockcms}blanktheme>form_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{ovicblockcms}blanktheme>form_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{ovicblockcms}blanktheme>form_f7c68d40f8727c658e821c6e6d56af07'] = 'No pages have been created.';
