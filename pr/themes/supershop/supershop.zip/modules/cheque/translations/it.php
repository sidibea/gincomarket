<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{cheque}prestashop>cheque_7b4cc4f79be9aae43efd53b4ae5cba4d'] = 'Assegno';
$_MODULE['<{cheque}prestashop>cheque_14e41f4cfd99b10766cc15676d8cda66'] = 'Questo modulo permette di accettare pagamenti tramite assegno.';
$_MODULE['<{cheque}prestashop>cheque_e09484ba6c16bc20236b63cc0d87ee95'] = 'Sei sicuro di voler cancellare i tuoi dati?';
$_MODULE['<{cheque}prestashop>cheque_10afbbb4dcb65d825785d196ffb294dd'] = '\'All\'ordine di\' e l\'indirizzo devono essere configurati per poter utilizzare questo modulo correttamente';
$_MODULE['<{cheque}prestashop>cheque_e2d93539acef2afbbadf8542351fb2b4'] = 'Nessuna valuta impostata per questo modulo';
$_MODULE['<{cheque}prestashop>cheque_94ce8bec7334b16916823f53ebe936d7'] = 'Il campo \"all\'ordine di\" è obbligatorio.';
$_MODULE['<{cheque}prestashop>cheque_4b5e20a521d31cc44b9690bd35eaacfc'] = 'Indirizzo obbligatorio.';
$_MODULE['<{cheque}prestashop>cheque_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{cheque}prestashop>cheque_aa646de3f8d345490b22b72d4a505dcd'] = 'Se il cliente sceglie questa modalità di pagamento, l\'ordine cambierà il proprio status in \"attesa di pagamento\".';
$_MODULE['<{cheque}prestashop>cheque_8c88bbf5712292b26e2a6bbeb0a7b5c4'] = 'Pertanto, sarà necessario confermare l\'ordine non appena si riceve un assegno.';
$_MODULE['<{cheque}prestashop>cheque_5dd532f0a63d89c5af0243b74732f63c'] = 'Dettagli di contatto';
$_MODULE['<{cheque}prestashop>cheque_119100c9e7b17d9cfe7b1d6c64259a04'] = 'Si prega di specificare il nome e l\'indirizzo a cui i clienti dovranno inviare il loro assegno';
$_MODULE['<{cheque}prestashop>cheque_75475839e69bef6ed57a8200a5a71d37'] = 'All\'ordine di';
$_MODULE['<{cheque}prestashop>cheque_dd7bf230fde8d4836917806aff6a6b27'] = 'Indirizzo';
$_MODULE['<{cheque}prestashop>cheque_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna le impostazioni';
$_MODULE['<{cheque}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'Questo metodo di pagamento non è disponibile.';
$_MODULE['<{cheque}prestashop>payment_execution_8520b283b0884394b13b80d5689628b3'] = 'Pagamento con assegno';
$_MODULE['<{cheque}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = 'Riepilogo dell\'ordine';
$_MODULE['<{cheque}prestashop>payment_execution_060bf2d587991d8f090a1309b285291c'] = 'Assegno';
$_MODULE['<{cheque}prestashop>payment_execution_76ca011e4772bfcce26aecd42c598510'] = 'Hai scelto di pagare con assegno.';
$_MODULE['<{cheque}prestashop>payment_execution_c884ed19483d45970c5bf23a681e2dd2'] = 'Ecco un breve riepilogo del tuo ordine:';
$_MODULE['<{cheque}prestashop>payment_execution_3b3b41f131194e747489ef93e778ed0d'] = 'L\'importo totale del tuo ordine è:';
$_MODULE['<{cheque}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = '(tasse incl.)';
$_MODULE['<{cheque}prestashop>payment_execution_7b1c6e78d93817f61f2b1bbc2108a803'] = 'Si accettano più valute per gli assegni.';
$_MODULE['<{cheque}prestashop>payment_execution_a7a08622ee5c8019b57354b99b7693b2'] = 'Scegli una delle seguenti:';
$_MODULE['<{cheque}prestashop>payment_execution_f73ad0f08052884ff465749bf48b55ce'] = 'Accettiamo le seguente valuta da inviare tramite assegno:';
$_MODULE['<{cheque}prestashop>payment_execution_7135ff14c7931e1c8e9d33aff3dfc7f7'] = 'Le informazioni sul titolare dell\'assegno e l\'indirizzo verranno visualizzate nella pagina successiva.';
$_MODULE['<{cheque}prestashop>payment_execution_0881a11f7af33bc1b43e437391129d66'] = 'Conferma l\'ordine cliccando su \'confermo il mio ordine\'';
$_MODULE['<{cheque}prestashop>payment_execution_46b9e3665f187c739c55983f757ccda0'] = 'Confermo il mio ordine';
$_MODULE['<{cheque}prestashop>payment_execution_569fd05bdafa1712c4f6be5b153b8418'] = 'Altri metodi di pagamento';
$_MODULE['<{cheque}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Il tuo ordine su %s è completo.';
$_MODULE['<{cheque}prestashop>payment_return_61da27a5dd1f8ced46c77b0feaa9e159'] = 'Vi preghiamo di inviarci un assegno con:';
$_MODULE['<{cheque}prestashop>payment_return_543baa3e0ca83589be12aff8036b5fe6'] = 'Importo pagamento.';
$_MODULE['<{cheque}prestashop>payment_return_9b8f932b1412d130ece5045ecafd1b42'] = 'Pagabile all\'ordine di';
$_MODULE['<{cheque}prestashop>payment_return_9a94f1d749a3de5d299674d6c685e416'] = 'Spedire a';
$_MODULE['<{cheque}prestashop>payment_return_e1c54fdba2544646684f41ace03b5fda'] = 'Non dimenticare di inserire il tuo numero d\'ordine n.%d.';
$_MODULE['<{cheque}prestashop>payment_return_4761b03b53bc2b3bd948bb7443a26f31'] = 'Non dimenticare di inserire il riferimento ordine %s.';
$_MODULE['<{cheque}prestashop>payment_return_610abe74e72f00210e3dcb91a0a3f717'] = 'Ti è stata inviata una email con queste informazioni.';
$_MODULE['<{cheque}prestashop>payment_return_ffd2478830ca2f519f7fe7ee259d4b96'] = 'Il tuo ordine verrà inviato non appena avremo ricevuto il pagamento.';
$_MODULE['<{cheque}prestashop>payment_return_0db71da7150c27142eef9d22b843b4a9'] = 'Per eventuali domande o per ulteriori informazioni, contatta la nostra';
$_MODULE['<{cheque}prestashop>payment_return_decce112a9e64363c997b04aa71b7cb8'] = 'assistenza clienti.';
$_MODULE['<{cheque}prestashop>payment_return_9bdf695c5a30784327137011da6ef568'] = 'Abbiamo notato un problema con il tuo ordine. Se pensi che questo sia un errore, contatta la nostra';
$_MODULE['<{cheque}prestashop>payment_f05fd8637f8a6281466a507fcb56baec'] = 'Paga con assegno.';
$_MODULE['<{cheque}prestashop>payment_841728ede901f5134574c4656aba5464'] = 'Paga con assegno (l\'elaborazione dell\'ordine sarà più lenta).';
