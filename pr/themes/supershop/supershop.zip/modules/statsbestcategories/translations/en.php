<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_4f29d8c727dcf2022ac241cb96c31083'] = 'Empty recordset returned';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_f5c493141bb4b2508c5938fd9353291a'] = 'Displaying %1$s of %2$s';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_eebfd2d9a7ea25b9e61e8260bcd4849c'] = 'Total Quantity Sold';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_f3547ae5e06426d87312eff7dda775aa'] = 'Total Price';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_c13329e42ec01a10f84c0f950274b404'] = 'Total Viewed';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_6e3b3150807da868ebd33ad2c991b8d7'] = 'Best categories';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_e5510869e31bbf721ca15dff21cf1169'] = 'Adds a list of the best categories to the Stats dashboard.';
$_MODULE['<{statsbestcategories}blanktheme>statsbestcategories_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
