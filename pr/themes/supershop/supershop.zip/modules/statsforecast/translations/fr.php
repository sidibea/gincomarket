<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsforecast}blanktheme>statsforecast_240c994d8b61c7bd68ac1c5182bbdb2e'] = 'Tableau de bord statistiques';
$_MODULE['<{statsforecast}blanktheme>statsforecast_b17fbc0dacaf9964df883d8065118b98'] = 'Module principal du tableau de bord de statistiques. Affiche un résumé de toutes vos statistiques.';
$_MODULE['<{statsforecast}blanktheme>statsforecast_7a27f506c0104592dcb95c31e650cfed'] = 'Les montants indiqués ne prennent pas la taxe en compte.';
$_MODULE['<{statsforecast}blanktheme>statsforecast_0f65535c189c29b4a5326a319baa4a8d'] = 'Délai';
$_MODULE['<{statsforecast}blanktheme>statsforecast_c512b685438f41daa7386329a3b8f8d3'] = 'Tous les jours';
$_MODULE['<{statsforecast}blanktheme>statsforecast_6c25e6a6da95b3d583c6ec4c3f82ed4d'] = 'Toutes les semaines';
$_MODULE['<{statsforecast}blanktheme>statsforecast_9030e39f00132d583da4122532e509e9'] = 'Tous les mois';
$_MODULE['<{statsforecast}blanktheme>statsforecast_cf5ea7953dc47105e0eb179dbefaaf46'] = 'Tous les ans';
$_MODULE['<{statsforecast}blanktheme>statsforecast_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{statsforecast}blanktheme>statsforecast_a28735af01fbb1e35371cb120985ac47'] = 'Inscriptions';
$_MODULE['<{statsforecast}blanktheme>statsforecast_fc6e0920b914b164802d44220e6163f3'] = 'Commandes effectuées';
$_MODULE['<{statsforecast}blanktheme>statsforecast_95deefb44d887f65b77407b87684b593'] = 'Produits achetés';
$_MODULE['<{statsforecast}blanktheme>statsforecast_51f2b17f5537de83c8b52dc52867fb1c'] = 'Pourcentage d\'inscriptions';
$_MODULE['<{statsforecast}blanktheme>statsforecast_688cb5b32405309351ee01da0ff3c3ac'] = 'Pourcentage de commandes';
$_MODULE['<{statsforecast}blanktheme>statsforecast_54358a914f51e1af19df8520159fe607'] = 'Recette';
$_MODULE['<{statsforecast}blanktheme>statsforecast_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{statsforecast}blanktheme>statsforecast_b1897515d548a960afe49ecf66a29021'] = 'Moyenne';
$_MODULE['<{statsforecast}blanktheme>statsforecast_89c1265be62d3ba835a3d963db5956b0'] = 'Prévisions';
$_MODULE['<{statsforecast}blanktheme>statsforecast_3bb1503332637805beddb73a2dd1fe1b'] = 'Transformation';
$_MODULE['<{statsforecast}blanktheme>statsforecast_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visiteurs';
$_MODULE['<{statsforecast}blanktheme>statsforecast_9b945efebb006547a94415eadaa12921'] = 'Comptes';
$_MODULE['<{statsforecast}blanktheme>statsforecast_87cac5a0b60008003ccf46dc1d49e0c3'] = 'Paniers complets';
$_MODULE['<{statsforecast}blanktheme>statsforecast_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{statsforecast}blanktheme>statsforecast_5a9e532b24379dca2ab0e973172a78e1'] = 'Visiteurs inscrits';
$_MODULE['<{statsforecast}blanktheme>statsforecast_fc26e55e0993a75e892175deb02aae15'] = 'Paniers';
$_MODULE['<{statsforecast}blanktheme>statsforecast_a34f9feb654595d53807df17b041d804'] = 'Un simple calcul statistique vous permet de connaître la valeur monétaire de vos visiteurs :';
$_MODULE['<{statsforecast}blanktheme>statsforecast_42de3b7ec2450ded7d6c600b359def52'] = 'En moyenne, chaque visiteur fait une commande de ce montant :';
$_MODULE['<{statsforecast}blanktheme>statsforecast_c06cbe5e69067225dbcab04fb85200fa'] = 'En moyenne, chaque visiteur enregistré fait une commande de ce montant :';
$_MODULE['<{statsforecast}blanktheme>statsforecast_3fa6443ce3f838b6901b70cd812abf0d'] = 'Répartition par modes de paiement';
$_MODULE['<{statsforecast}blanktheme>statsforecast_cbb3a9a8d0b10c0618904ce4ecb08716'] = 'Les montants sont TTC de sorte à ce que vous puissiez avoir une estimation de la commission due au service de paiement utilisé.';
$_MODULE['<{statsforecast}blanktheme>statsforecast_e6e42855066e7a3ae050b2c698021b14'] = 'Zone :';
$_MODULE['<{statsforecast}blanktheme>statsforecast_5ed26836c96d7dcae8a40307e8e250c3'] = 'Aucun filtre';
$_MODULE['<{statsforecast}blanktheme>statsforecast_e55f75a29310d7b60f7ac1d390c8ae42'] = 'Module';
$_MODULE['<{statsforecast}blanktheme>statsforecast_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{statsforecast}blanktheme>statsforecast_71241798130f714cbd2786df3da2cf0b'] = 'Valeur du panier moyen';
$_MODULE['<{statsforecast}blanktheme>statsforecast_f13877f6ad53ce91fcb20fb8b7969698'] = 'Répartition par catégories';
$_MODULE['<{statsforecast}blanktheme>statsforecast_b3ff996fe5c77610359114835baf9b38'] = 'Zone';
$_MODULE['<{statsforecast}blanktheme>statsforecast_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Catégorie';
$_MODULE['<{statsforecast}blanktheme>statsforecast_d1873a71f318c4e4733240f0b5911af3'] = 'Produits vendus';
$_MODULE['<{statsforecast}blanktheme>statsforecast_954b04c203e651728d12622da369cd80'] = 'Pourcentage de produits vendus';
$_MODULE['<{statsforecast}blanktheme>statsforecast_a613e7309e4cb7fdaf416fa4f8bfd360'] = 'Pourcentage de ventes';
$_MODULE['<{statsforecast}blanktheme>statsforecast_844c29394eea07066bb2efefc35784ec'] = 'Prix moyen';
$_MODULE['<{statsforecast}blanktheme>statsforecast_88183b946cc5f0e8c96b2e66e1c74a7e'] = 'Inconnu';
$_MODULE['<{statsforecast}blanktheme>statsforecast_f1dd68fb6a00d3e4d7f751deacde995d'] = 'Répartition par langue';
$_MODULE['<{statsforecast}blanktheme>statsforecast_4994a8ffeba4ac3140beb89e8d41f174'] = 'Langue';
$_MODULE['<{statsforecast}blanktheme>statsforecast_37be07209f53a5d636d5c904ca9ae64c'] = 'Pourcentage';
$_MODULE['<{statsforecast}blanktheme>statsforecast_699aed86dada6ca01ef74013a4464066'] = 'Evolution';
$_MODULE['<{statsforecast}blanktheme>statsforecast_07aa83862ec591697b4325b66d36a78b'] = 'Répartition par zones';
$_MODULE['<{statsforecast}blanktheme>statsforecast_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Indéfini';
$_MODULE['<{statsforecast}blanktheme>statsforecast_28e81c8343702f6c813cc31a7f90616a'] = 'Répartition par devise';
$_MODULE['<{statsforecast}blanktheme>statsforecast_386c339d37e737a436499d423a77df0c'] = 'Devise';
$_MODULE['<{statsforecast}blanktheme>statsforecast_61569923d8075889a162c4e603258e6e'] = 'CA (converti)';
$_MODULE['<{statsforecast}blanktheme>statsforecast_8471eed257db7258f935588a664ba4f3'] = 'Répartition des ventes par attributs';
$_MODULE['<{statsforecast}blanktheme>statsforecast_03937134cedab9078be39a77ee3a48a0'] = 'Groupe';
$_MODULE['<{statsforecast}blanktheme>statsforecast_f2bbdf9f72c085adc4d0404e370f0f4c'] = 'Attribut';
$_MODULE['<{statsforecast}blanktheme>statsforecast_9b95278ceb25bd5ddfcd7b22be6e4000'] = 'Quantité de produits vendus';
