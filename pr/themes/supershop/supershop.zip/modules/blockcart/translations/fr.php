<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcart}blanktheme>blockcart_c2e1362a9710a3dd86f937c2ea1f336d'] = 'Bloc panier';
$_MODULE['<{blockcart}blanktheme>blockcart_e03093a5753b436ee1de63b6e3e1bd02'] = 'Ajoute un bloc avec le contenu du panier du client';
$_MODULE['<{blockcart}blanktheme>blockcart_a21e5718d2a196280b729438933501c7'] = 'Ajax : choix non valable.';
$_MODULE['<{blockcart}blanktheme>blockcart_02c793e3df4632db20e4d6e146095d62'] = 'Vous devez remplir le champ \"Produits Affichés\".';
$_MODULE['<{blockcart}blanktheme>blockcart_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour réussie';
$_MODULE['<{blockcart}blanktheme>blockcart_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcart}blanktheme>blockcart_614a8820aa4ac08ce2ee398a41b10778'] = 'Panier Ajax';
$_MODULE['<{blockcart}blanktheme>blockcart_eefd19ecf1f6d94a308dcfc95981bbf9'] = 'Activer le mode Ajax du panier (compatible avec le thème par défaut).';
$_MODULE['<{blockcart}blanktheme>blockcart_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockcart}blanktheme>blockcart_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockcart}blanktheme>blockcart_ce8bd2479bb85218eb304a9a2903a157'] = 'Produits à afficher dans les ventes croisées';
$_MODULE['<{blockcart}blanktheme>blockcart_5f2effb52d25d197793288dfa94c27ce'] = 'Détermine le nombre de produits affichés dans le bloc ventes croisées.';
$_MODULE['<{blockcart}blanktheme>blockcart_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcart}blanktheme>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Personnalisation';
$_MODULE['<{blockcart}blanktheme>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'supprimer cet article du panier';
$_MODULE['<{blockcart}blanktheme>blockcart_c6995d6cc084c192bc2e742f052a5c74'] = 'Livraison gratuite !';
$_MODULE['<{blockcart}blanktheme>blockcart_e7a6ca4e744870d455a57b644f696457'] = 'Offert !';
$_MODULE['<{blockcart}blanktheme>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockcart}blanktheme>blockcart_0c3bf3014aafb90201805e45b5e62881'] = 'Voir mon panier';
$_MODULE['<{blockcart}blanktheme>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Panier';
$_MODULE['<{blockcart}blanktheme>blockcart_068f80c7519d0528fb08e82137a72131'] = 'Produits';
$_MODULE['<{blockcart}blanktheme>blockcart_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{blockcart}blanktheme>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vide)';
$_MODULE['<{blockcart}blanktheme>blockcart_0da4d96cad73748e2f608d31cfb3247c'] = 'supprimer cet article du panier';
$_MODULE['<{blockcart}blanktheme>blockcart_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Détails de l\'article';
$_MODULE['<{blockcart}blanktheme>blockcart_3d9e3bae9905a12dae384918ed117a26'] = 'Personnalisation n°%d :';
$_MODULE['<{blockcart}blanktheme>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Aucun produit';
$_MODULE['<{blockcart}blanktheme>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Livraison';
$_MODULE['<{blockcart}blanktheme>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Emballage';
$_MODULE['<{blockcart}blanktheme>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Taxes';
$_MODULE['<{blockcart}blanktheme>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{blockcart}blanktheme>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'Les prix sont TTC';
$_MODULE['<{blockcart}blanktheme>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'Les prix sont HT';
$_MODULE['<{blockcart}blanktheme>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Commander';
$_MODULE['<{blockcart}blanktheme>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Les clients qui ont acheté ce produit ont également acheté...';
$_MODULE['<{blockcart}blanktheme>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_MODULE['<{blockcart}blanktheme>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
$_MODULE['<{blockcart}blanktheme>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
$_MODULE['<{blockcart}blanktheme>blockcart_98b3009e61879600839e1ee486bb3282'] = 'Fermer la fenêtre';
$_MODULE['<{blockcart}blanktheme>blockcart_544c3bd0eac526113a9c66542be1e5bc'] = 'Produit ajouté au panier avec succès';
$_MODULE['<{blockcart}blanktheme>blockcart_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_MODULE['<{blockcart}blanktheme>blockcart_e5694b7726ceaf2f057e5f06cf86209e'] = 'Il y a [1]%d[/1] produits dans votre panier.';
$_MODULE['<{blockcart}blanktheme>blockcart_fc86c43dbffcadc193832a310f7a444a'] = 'Il y a 1 produit dans votre panier.';
$_MODULE['<{blockcart}blanktheme>blockcart_db205f01b4fd580fb5daa9072d96849d'] = 'Total produits';
$_MODULE['<{blockcart}blanktheme>blockcart_21034ae6d01a83e702839a72ba8a77b0'] = '(HT)';
$_MODULE['<{blockcart}blanktheme>blockcart_1f87346a16cf80c372065de3c54c86d9'] = 'TTC';
$_MODULE['<{blockcart}blanktheme>blockcart_f4e8b53a114e5a17d051ab84d326cae5'] = 'Frais de port';
$_MODULE['<{blockcart}blanktheme>blockcart_300225ee958b6350abc51805dab83c24'] = 'Continuer mes achats';
$_MODULE['<{blockcart}blanktheme>blockcart_7e0bf6d67701868aac3116ade8fea957'] = 'Commander';
