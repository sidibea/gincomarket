<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssales}blanktheme>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Commandes et CA';
$_MODULE['<{statssales}blanktheme>statssales_d2fb07753354576172a2b144c373a610'] = 'Ajoute des graphiques présentant l\'évolution des ventes et des commandes sur le tableau de bord des statistiques.';
$_MODULE['<{statssales}blanktheme>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statssales}blanktheme>statssales_bdaa0cab56c2880f8f60e6a2cef40e63'] = 'À propos des états de commandes';
$_MODULE['<{statssales}blanktheme>statssales_5cc6f5194e3ef633bcab4869d79eeefa'] = 'Seules les commandes valides sont représentées sur le graphique.';
$_MODULE['<{statssales}blanktheme>statssales_c3987e4cac14a8456515f0d200da04ee'] = 'Tous les pays';
$_MODULE['<{statssales}blanktheme>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrer';
$_MODULE['<{statssales}blanktheme>statssales_9ccb8353e945f1389a9585e7f21b5a0d'] = 'Commandes passées :';
$_MODULE['<{statssales}blanktheme>statssales_156e5c5872c9af24a5c982da07a883c2'] = 'Produits commandés :';
$_MODULE['<{statssales}blanktheme>statssales_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statssales}blanktheme>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Ventes :';
$_MODULE['<{statssales}blanktheme>statssales_f6825178a5fef0a97dacf963409829f0'] = 'Vous pouvez voir la distribution des états de commandes ci-dessous.';
$_MODULE['<{statssales}blanktheme>statssales_da80af4de99df74dd59e665adf1fac8f'] = 'Aucune commande pour cette période';
$_MODULE['<{statssales}blanktheme>statssales_b52b44c9d23e141b067d7e83b44bb556'] = 'Produits :';
$_MODULE['<{statssales}blanktheme>statssales_497a2a4cf0a780ff5b60a7a6e43ea533'] = 'Devises des ventes : %s';
$_MODULE['<{statssales}blanktheme>statssales_17833fb3783b26e0a9bc8b21ee85302a'] = 'Pourcentage de commandes par état.';
