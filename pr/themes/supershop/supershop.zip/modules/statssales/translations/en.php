<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssales}blanktheme>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Sales and orders';
$_MODULE['<{statssales}blanktheme>statssales_d2fb07753354576172a2b144c373a610'] = 'Adds graphics presenting the evolution of sales and orders to the Stats dashboard.';
$_MODULE['<{statssales}blanktheme>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statssales}blanktheme>statssales_bdaa0cab56c2880f8f60e6a2cef40e63'] = 'About order statuses';
$_MODULE['<{statssales}blanktheme>statssales_5cc6f5194e3ef633bcab4869d79eeefa'] = 'Only valid orders are graphically represented.';
$_MODULE['<{statssales}blanktheme>statssales_c3987e4cac14a8456515f0d200da04ee'] = 'All countries';
$_MODULE['<{statssales}blanktheme>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filter';
$_MODULE['<{statssales}blanktheme>statssales_9ccb8353e945f1389a9585e7f21b5a0d'] = 'Orders placed:';
$_MODULE['<{statssales}blanktheme>statssales_156e5c5872c9af24a5c982da07a883c2'] = 'Products bought:';
$_MODULE['<{statssales}blanktheme>statssales_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
$_MODULE['<{statssales}blanktheme>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Sales:';
$_MODULE['<{statssales}blanktheme>statssales_f6825178a5fef0a97dacf963409829f0'] = 'You can view the distribution of order statuses below.';
$_MODULE['<{statssales}blanktheme>statssales_da80af4de99df74dd59e665adf1fac8f'] = 'No orders for this period.';
$_MODULE['<{statssales}blanktheme>statssales_b52b44c9d23e141b067d7e83b44bb556'] = 'Products:';
$_MODULE['<{statssales}blanktheme>statssales_497a2a4cf0a780ff5b60a7a6e43ea533'] = 'Sales currency: %s';
$_MODULE['<{statssales}blanktheme>statssales_17833fb3783b26e0a9bc8b21ee85302a'] = 'Percentage of orders per status.';
