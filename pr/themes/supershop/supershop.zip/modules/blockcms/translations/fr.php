<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}blanktheme>blockcms_ca3e06233b736d289df9f4580a4ab19a'] = 'Bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_cdca12007979fc49008fd125cdb775fc'] = 'Ajoute un bloc contenant plusieurs lien vers vos pages CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_MODULE['<{blockcms}blanktheme>blockcms_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{blockcms}blanktheme>blockcms_ef61fb324d729c341ea8ab9901e23566'] = 'Ajouter';
$_MODULE['<{blockcms}blanktheme>blockcms_97390dd0b5ba7867120aee2ff22bfa38'] = 'Configuration du bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_6f0091f0c2b3ef334a8f5359f462b63f'] = 'Blocs CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_0a41f7ebbcf8a28362f8635ca8341d28'] = 'Nouveau bloc';
$_MODULE['<{blockcms}blanktheme>blockcms_528c17398f985a94f4cc7c5b2d32c8c0'] = 'Configuration des divers liens du pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_c93efb366650d08e5827974c0ddec8d8'] = 'Afficher divers liens et informations dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_6f3ebe2ce8a7c3b873c1003b6ead60df'] = 'Liens de pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_e363df19c685465bca24d0c06d9394c7'] = 'Sélectionnez les pages que vous souhaitez afficher dans le bloc CMS de pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_b0f8cd6eb22f287563dad544796b4118'] = 'Informations de pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_75cb29c17cf91bef81cc289b0dd1b1fa'] = 'Ajouter le lien \"Nos magasins\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_0e5da791148c92be6eca8c537a47569e'] = 'Ajouter le lien \"Promotions\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_e995cfe1489190cf28799a16d23be91a'] = 'Ajouter le lien \"Nouveaux produits\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_edeab890c4f02138691d67eefcbfe7e8'] = 'Ajouter le lien \"Meilleures ventes\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_45bc5fe3bf5717315e42a831ba7da748'] = 'Ajouter le lien \"Nous contacter\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_68b7b9e603633d155941fb1d665c3997'] = 'Ajouter le lien du plan du site dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_573a06e2ae339eeb4fb19e7f689bd3d8'] = 'Ajouter le lien \"Propulsé par PrestaShop\" dans le pied de page';
$_MODULE['<{blockcms}blanktheme>blockcms_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcms}blanktheme>blockcms_be58fccb15fb119b8c3d485e3a8561c4'] = 'Configuration du bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_0eb46571f3ff926d8b2408cafcfc17e3'] = 'Modification du bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_5aa1602194579edb6f91d7dd53eadb32'] = 'Nouveau bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_dd57f561a17388f38ac26a2f0321776b'] = 'Nom du bloc CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_51b274d417210e74d2cfe9e0713602f2'] = 'Si vous laissez ce champ vide, le nom du bloc sera le nom de la catégorie';
$_MODULE['<{blockcms}blanktheme>blockcms_ac37b115bc4e914c9ab63bd4a1c1746a'] = 'Catégorie CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_ce5bf551379459c1c61d2a204061c455'] = 'Emplacement';
$_MODULE['<{blockcms}blanktheme>blockcms_f9e4884c7654daa6581b42ed90aeaba4'] = 'Colonne de gauche';
$_MODULE['<{blockcms}blanktheme>blockcms_feb6cc332459769fe15570bf332a6b50'] = 'Colonne de droite';
$_MODULE['<{blockcms}blanktheme>blockcms_ef0e9df97eac6e978e72eeaf5abb8b0e'] = 'Ajouter un lien vers le localisateur de magasins';
$_MODULE['<{blockcms}blanktheme>blockcms_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{blockcms}blanktheme>blockcms_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{blockcms}blanktheme>blockcms_9a8d463045dc8c2ad89bcd455fd937e8'] = 'Ajoute le lien \"Nos magasins\" à la fin du bloc.';
$_MODULE['<{blockcms}blanktheme>blockcms_bbfdbbf61a22c160c5498b6ae08cb356'] = 'Contenu CMS';
$_MODULE['<{blockcms}blanktheme>blockcms_04313a11bf4a501b7cf2273ea7b32862'] = 'Sélectionnez les pages que vous souhaitez afficher dans ce bloc';
$_MODULE['<{blockcms}blanktheme>blockcms_0d6d7a7c758cd16507d4aebf18305691'] = 'Valeur d\'affichage non valable pour le magasin';
$_MODULE['<{blockcms}blanktheme>blockcms_4eb9b68883615faa427da721fad14422'] = 'Emplacement non valable pour le bloc';
$_MODULE['<{blockcms}blanktheme>blockcms_795c54de995b69fe05142dad6f99ef92'] = 'Vous devez choisir au moins une page ou sous-catégorie pour créer un bloc CMS.';
$_MODULE['<{blockcms}blanktheme>blockcms_0788bfffae213b06afb540bf06926652'] = 'Page ou catégorie CMS non valable';
$_MODULE['<{blockcms}blanktheme>blockcms_7125483712689cd7a6f85b466a8a7632'] = 'Le nom du bloc est trop long';
$_MODULE['<{blockcms}blanktheme>blockcms_ede67d50014846cb8bb1b00d5fde77be'] = 'id_cms_block invalide';
$_MODULE['<{blockcms}blanktheme>blockcms_2d81a9da91ff3f073e6aecbe42c33e69'] = 'Veuillez fournir un text de pied de page pour la langue par défaut';
$_MODULE['<{blockcms}blanktheme>blockcms_af979c5a556c7a2c5340a06273046b0d'] = 'Activation du pied de page non valide.';
$_MODULE['<{blockcms}blanktheme>blockcms_dc08eb6c896a19dd0f0585ab7205ed17'] = 'Impossible de créer un bloc !';
$_MODULE['<{blockcms}blanktheme>blockcms_f3d25e325923cd522fd610bd869d736c'] = 'Erreur : vous essayez de supprimer un bloc CMS inexistant.';
$_MODULE['<{blockcms}blanktheme>blockcms_0c579767f53365887ac199a96e26c591'] = 'Informations du pied de page mises à jour';
$_MODULE['<{blockcms}blanktheme>blockcms_c28716416d2fd75a37b4496586755853'] = 'Le bloc CMS a bien été ajouté';
$_MODULE['<{blockcms}blanktheme>blockcms_a94db349ae0c662fd55c9d402481165b'] = 'Le bloc CMS a bien été modifié';
$_MODULE['<{blockcms}blanktheme>blockcms_64e1a7a1be29d5937f2eaa90a3d32ad0'] = 'Suppression réussie.';
$_MODULE['<{blockcms}blanktheme>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_MODULE['<{blockcms}blanktheme>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Promotions';
$_MODULE['<{blockcms}blanktheme>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_MODULE['<{blockcms}blanktheme>blockcms_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Meilleures ventes';
$_MODULE['<{blockcms}blanktheme>blockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_MODULE['<{blockcms}blanktheme>blockcms_5813ce0ec7196c492c97596718f71969'] = 'sitemap';
$_MODULE['<{blockcms}blanktheme>blockcms_650f3a4b9d4a9f149c69327fb8239121'] = '[1]Logiciel e-commerce par %s[/1]';
$_MODULE['<{blockcms}blanktheme>form_4dabfa54822012dfc78d6ef40f224173'] = 'Blocs à gauche';
$_MODULE['<{blockcms}blanktheme>form_d9ca3009e18447d91cd2e324e8e680ce'] = 'Blocs à droite';
$_MODULE['<{blockcms}blanktheme>form_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blockcms}blanktheme>form_83ef1503b3bd9858cc923a74e5f9e917'] = 'Nom du bloc';
$_MODULE['<{blockcms}blanktheme>form_bb34a159a88035cce7ef1607e7907f8f'] = 'Nom de la catégorie';
$_MODULE['<{blockcms}blanktheme>form_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Position';
$_MODULE['<{blockcms}blanktheme>form_08a38277b0309070706f6652eeae9a53'] = 'Descendre';
$_MODULE['<{blockcms}blanktheme>form_258f49887ef8d14ac268c92b02503aaa'] = 'Monter';
$_MODULE['<{blockcms}blanktheme>form_7dce122004969d56ae2e0245cb754d35'] = 'Modifier';
$_MODULE['<{blockcms}blanktheme>form_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{blockcms}blanktheme>form_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{blockcms}blanktheme>form_f7c68d40f8727c658e821c6e6d56af07'] = 'Aucune page créée';
$_MODULE['<{blockcms}blanktheme>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
