<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gridhtml}blanktheme>gridhtml_cf6b972204ee563b4e5691b293e931b6'] = 'Simple HTML table display';
$_MODULE['<{gridhtml}blanktheme>gridhtml_05ce5a49b49dd6245f71e384c4b43564'] = 'Allows the statistics system to display data in a grid.';
