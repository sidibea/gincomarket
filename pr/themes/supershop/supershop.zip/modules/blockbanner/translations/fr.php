<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}blanktheme>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloc bannière';
$_MODULE['<{blockbanner}blanktheme>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'une erreur s\'est produite lors de l\'envoi';
$_MODULE['<{blockbanner}blanktheme>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockbanner}blanktheme>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockbanner}blanktheme>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Veuillez saisir une description courte mais précise pour votre bannière.';
$_MODULE['<{blockbanner}blanktheme>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
