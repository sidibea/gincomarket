<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscatalog}blanktheme>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Catalog statistics';
$_MODULE['<{statscatalog}blanktheme>statscatalog_08a7c3cf820979d2c8d4de4f47abb5e6'] = 'Adds a tab containing general statistics about your catalog to the Stats dashboard.';
$_MODULE['<{statscatalog}blanktheme>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 purchase / %d visits)';
$_MODULE['<{statscatalog}blanktheme>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Choose a category';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{statscatalog}blanktheme>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Products available:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Average price (base price):';
$_MODULE['<{statscatalog}blanktheme>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Product pages viewed:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'Products bought:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Average number of page visits:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Average number of purchases:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Images available:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Average number of images:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'Products never viewed:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Products never purchased:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Conversion rate*:';
$_MODULE['<{statscatalog}blanktheme>statscatalog_082d537edb8c61539b9f266eb331c88e'] = 'Defines the average conversion rate for the product page. It is possible to purchase a product without viewing the product page, so this rate can be greater than 1.';
$_MODULE['<{statscatalog}blanktheme>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Products never purchased';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}blanktheme>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statscatalog}blanktheme>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Edit / View';
$_MODULE['<{statscatalog}blanktheme>statscatalog_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{statscatalog}blanktheme>statscatalog_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
