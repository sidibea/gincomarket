<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gamification}blanktheme>gamification_3d4aafb2eedeba2fbf92e852f0af745a'] = 'Merchant Expertise';
$_MODULE['<{gamification}blanktheme>gamification_bacc1bf300527bad9c6ac2d3b875a8d8'] = 'Become an e-commerce expert within the blink of an eye!';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_ca96b4f8d13722aac99da25f94ea1711'] = 'Your Merchant Expertise';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_7258e7251413465e0a3eb58094430bde'] = 'Administration';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_3d4aafb2eedeba2fbf92e852f0af745a'] = 'Merchant Expertise';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_98f770b0af18ca763421bac22b4b6805'] = 'Features';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_f5c7922da355fd289ec1d6469e0583a7'] = 'Achievements';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_8189ecf686157db0c0274c1f49373318'] = 'International';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_851f12a0c936baace7f0e734d5c624e7'] = '1. Beginner';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_583981a16ea761fe852b64094d8a887e'] = '2. Pro';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_38f7af7416ffcd1524d8a4acda756cbf'] = '3. Expert';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_e7613fe56cdbeddfc9bb6276fd0f0d12'] = '4. Wizard';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_8d03eaad7ff7babdd33c2c74fe479ed0'] = '5. Guru';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_e4be4f3e3ae4ee9dda6b60815bf774c1'] = '6. Legend';
$_MODULE['<{gamification}blanktheme>filters_e659b52eba1f0299b2d8ca3483919e72'] = 'Type:';
$_MODULE['<{gamification}blanktheme>filters_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{gamification}blanktheme>filters_18325105de95083e4a1d10b78f29c2bc'] = 'State:';
$_MODULE['<{gamification}blanktheme>filters_5364259abab90e94890f2ed2481b9824'] = 'Validated';
$_MODULE['<{gamification}blanktheme>filters_dc450ba947e6adecbdbe68c25de03a1b'] = 'Not Validated';
$_MODULE['<{gamification}blanktheme>filters_07ad815187b53dc2ceaf5ad6e0a12bb1'] = 'Level:';
$_MODULE['<{gamification}blanktheme>filters_bt_e659b52eba1f0299b2d8ca3483919e72'] = 'Type:';
$_MODULE['<{gamification}blanktheme>filters_bt_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{gamification}blanktheme>filters_bt_18325105de95083e4a1d10b78f29c2bc'] = 'State:';
$_MODULE['<{gamification}blanktheme>filters_bt_5364259abab90e94890f2ed2481b9824'] = 'Validated';
$_MODULE['<{gamification}blanktheme>filters_bt_dc450ba947e6adecbdbe68c25de03a1b'] = 'Not Validated';
$_MODULE['<{gamification}blanktheme>filters_bt_07ad815187b53dc2ceaf5ad6e0a12bb1'] = 'Level:';
$_MODULE['<{gamification}blanktheme>view_a0db49ba470c1c9ae2128c3470339153'] = 'Level';
$_MODULE['<{gamification}blanktheme>view_2a0ab6a9172272d54f0d601b0ac157f3'] = 'Become an e-commerce expert in leaps and bounds!';
$_MODULE['<{gamification}blanktheme>view_5cf06184f524aad72c14d3ec5d325c56'] = 'With all of the great features and benefits that PrestaShop offers, it\'s important to keep up!';
$_MODULE['<{gamification}blanktheme>view_2c3193c85bb2555c333adfcfb824804a'] = 'The main goal of all of the features we offer is to make you succeed in the e-commerce world. In order to accomplish this, we have created a system of badges and points that make it easy to monitor your progress as a merchant. We have broken down the system into three levels, all of which are integral to success in the e-commerce world: (i) Your use of key e-commerce features on your store; (ii) Your sales performance; (iii) Your presence in international markets.';
$_MODULE['<{gamification}blanktheme>view_6b766dc388ad21053bde0f8fd95d1e04'] = 'The more progress your store makes, the more badges and points you earn. No need to submit any information or fill out any forms; we know how busy you are, everything is automatic!';
$_MODULE['<{gamification}blanktheme>view_21dc1cfc9ef1cdfbb665cab323d5e1a9'] = 'Now, with the click of a button, you will be able to see sales-enhancing features that you may be missing out on. Take advantage and check it out below!';
$_MODULE['<{gamification}blanktheme>view_bcc5a331e758a60ad298b4b18a26d0e0'] = 'Our team is available to help. Contact us today!';
$_MODULE['<{gamification}blanktheme>view_bcc254b55c4a1babdf1dcb82c207506b'] = 'Phone';
$_MODULE['<{gamification}blanktheme>view_4b566d4e657c8c4f133057c73d1c6860'] = 'Call us: +1 (888) 947-6543';
$_MODULE['<{gamification}blanktheme>view_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{gamification}blanktheme>view_7d6d8e6610fd23b684be7e95a6cc5c39'] = 'Fill out a contact form';
$_MODULE['<{gamification}blanktheme>view_6b6ac7834d96afefbca5677814769109'] = 'Completion level';
$_MODULE['<{gamification}blanktheme>view_82338dd23ce2fd2f6d3606c20f4ee96e'] = 'No badge in this section';
$_MODULE['<{gamification}blanktheme>view_bt_a0db49ba470c1c9ae2128c3470339153'] = 'Level';
$_MODULE['<{gamification}blanktheme>view_bt_2a0ab6a9172272d54f0d601b0ac157f3'] = 'Become an e-commerce expert in leaps and bounds!';
$_MODULE['<{gamification}blanktheme>view_bt_5cf06184f524aad72c14d3ec5d325c56'] = 'With all of the great features and benefits that PrestaShop offers, it\'s important to keep up!';
$_MODULE['<{gamification}blanktheme>view_bt_2c3193c85bb2555c333adfcfb824804a'] = 'The main goal of all of the features we offer is to make you succeed in the e-commerce world. In order to accomplish this, we have created a system of badges and points that make it easy to monitor your progress as a merchant. We have broken down the system into three levels, all of which are integral to success in the e-commerce world: (i) Your use of key e-commerce features on your store; (ii) Your sales performance; (iii) Your presence in international markets.';
$_MODULE['<{gamification}blanktheme>view_bt_6b766dc388ad21053bde0f8fd95d1e04'] = 'The more progress your store makes, the more badges and points you earn. No need to submit any information or fill out any forms; we know how busy you are, everything is automatic!';
$_MODULE['<{gamification}blanktheme>view_bt_21dc1cfc9ef1cdfbb665cab323d5e1a9'] = 'Now, with the click of a button, you will be able to see sales-enhancing features that you may be missing out on. Take advantage and check it out below!';
$_MODULE['<{gamification}blanktheme>view_bt_bcc5a331e758a60ad298b4b18a26d0e0'] = 'Our team is available to help. Contact us today!';
$_MODULE['<{gamification}blanktheme>view_bt_bcc254b55c4a1babdf1dcb82c207506b'] = 'Phone';
$_MODULE['<{gamification}blanktheme>view_bt_4b566d4e657c8c4f133057c73d1c6860'] = 'Call us: +1 (888) 947-6543';
$_MODULE['<{gamification}blanktheme>view_bt_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{gamification}blanktheme>view_bt_7d6d8e6610fd23b684be7e95a6cc5c39'] = 'Fill out a contact form';
$_MODULE['<{gamification}blanktheme>view_bt_6b6ac7834d96afefbca5677814769109'] = 'Completion level';
$_MODULE['<{gamification}blanktheme>view_bt_82338dd23ce2fd2f6d3606c20f4ee96e'] = 'No badge in this section';
$_MODULE['<{gamification}blanktheme>notification_ca96b4f8d13722aac99da25f94ea1711'] = 'Your Merchant Expertise';
$_MODULE['<{gamification}blanktheme>notification_a0db49ba470c1c9ae2128c3470339153'] = 'Level';
$_MODULE['<{gamification}blanktheme>notification_16a1daea9e8873542aec1e820798aa44'] = 'Last badge :';
$_MODULE['<{gamification}blanktheme>notification_15377177c0259c6f79341cc57da13f19'] = 'Next badge :';
$_MODULE['<{gamification}blanktheme>notification_f8978f781f97e6f851e9c8f7059c37b2'] = 'View my complete profile';
$_MODULE['<{gamification}blanktheme>notification_bt_ca96b4f8d13722aac99da25f94ea1711'] = 'Your Merchant Expertise';
$_MODULE['<{gamification}blanktheme>notification_bt_a0db49ba470c1c9ae2128c3470339153'] = 'Level';
$_MODULE['<{gamification}blanktheme>notification_bt_16a1daea9e8873542aec1e820798aa44'] = 'Last badge :';
$_MODULE['<{gamification}blanktheme>notification_bt_15377177c0259c6f79341cc57da13f19'] = 'Next badge :';
$_MODULE['<{gamification}blanktheme>notification_bt_f8978f781f97e6f851e9c8f7059c37b2'] = 'View my complete profile';
