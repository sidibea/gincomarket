<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gamification}blanktheme>gamification_3d4aafb2eedeba2fbf92e852f0af745a'] = 'Expertise PrestaShop';
$_MODULE['<{gamification}blanktheme>gamification_bacc1bf300527bad9c6ac2d3b875a8d8'] = 'Devenez un marchand accompli à pas de géant !';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_ca96b4f8d13722aac99da25f94ea1711'] = 'Votre Expertise PrestaShop';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_7258e7251413465e0a3eb58094430bde'] = 'Administration';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_3d4aafb2eedeba2fbf92e852f0af745a'] = 'Expertise PrestaShop';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_98f770b0af18ca763421bac22b4b6805'] = 'Caractéristiques';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_f5c7922da355fd289ec1d6469e0583a7'] = 'Succès';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_8189ecf686157db0c0274c1f49373318'] = 'International';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_851f12a0c936baace7f0e734d5c624e7'] = '1. Débutant';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_583981a16ea761fe852b64094d8a887e'] = '2. Pro';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_38f7af7416ffcd1524d8a4acda756cbf'] = '3. Expert';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_e7613fe56cdbeddfc9bb6276fd0f0d12'] = '4. Maître';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_8d03eaad7ff7babdd33c2c74fe479ed0'] = '5. Gourou';
$_MODULE['<{gamification}blanktheme>admingamificationcontroller_e4be4f3e3ae4ee9dda6b60815bf774c1'] = '6. Légende';
$_MODULE['<{gamification}blanktheme>filters_e659b52eba1f0299b2d8ca3483919e72'] = 'Type :';
$_MODULE['<{gamification}blanktheme>filters_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{gamification}blanktheme>filters_18325105de95083e4a1d10b78f29c2bc'] = 'État :';
$_MODULE['<{gamification}blanktheme>filters_5364259abab90e94890f2ed2481b9824'] = 'Validé';
$_MODULE['<{gamification}blanktheme>filters_dc450ba947e6adecbdbe68c25de03a1b'] = 'Non validé';
$_MODULE['<{gamification}blanktheme>filters_07ad815187b53dc2ceaf5ad6e0a12bb1'] = 'Niveau :';
$_MODULE['<{gamification}blanktheme>filters_bt_e659b52eba1f0299b2d8ca3483919e72'] = 'Type :';
$_MODULE['<{gamification}blanktheme>filters_bt_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{gamification}blanktheme>filters_bt_18325105de95083e4a1d10b78f29c2bc'] = 'État :';
$_MODULE['<{gamification}blanktheme>filters_bt_5364259abab90e94890f2ed2481b9824'] = 'Validé';
$_MODULE['<{gamification}blanktheme>filters_bt_dc450ba947e6adecbdbe68c25de03a1b'] = 'Non validé';
$_MODULE['<{gamification}blanktheme>filters_bt_07ad815187b53dc2ceaf5ad6e0a12bb1'] = 'Niveau :';
$_MODULE['<{gamification}blanktheme>view_a0db49ba470c1c9ae2128c3470339153'] = 'Niveau';
$_MODULE['<{gamification}blanktheme>view_2a0ab6a9172272d54f0d601b0ac157f3'] = 'Devenez un marchand accompli à pas de géant !';
$_MODULE['<{gamification}blanktheme>view_5cf06184f524aad72c14d3ec5d325c56'] = 'Avec toutes les fonctionnalités et avantages proposés par PrestaShop, il est important de rester à jour !';
$_MODULE['<{gamification}blanktheme>view_2c3193c85bb2555c333adfcfb824804a'] = 'A chaque badge décerné, vous gagnez des points et nous vous présentons la prochaine action à réaliser selon votre activité. Vous êtes ainsi guidé(e) vers une boutique parfaitement configurée et optimisée pour votre succès !';
$_MODULE['<{gamification}blanktheme>view_6b766dc388ad21053bde0f8fd95d1e04'] = 'Nous avons défini 3 thèmes essentiels pour évaluer le niveau de développement de votre boutique : les fonctionnalités clés à configurer, vos performances commerciales et votre visibilité à l\'international.';
$_MODULE['<{gamification}blanktheme>view_21dc1cfc9ef1cdfbb665cab323d5e1a9'] = 'Désormais, en cliquant sur un bouton, vous pourrez voir les fonctionnalités d\'amélioration des ventes dont vous ne disposez pas encore. Profitez-en dès maintenant !';
$_MODULE['<{gamification}blanktheme>view_bcc5a331e758a60ad298b4b18a26d0e0'] = 'Notre équipe est là pour vous aider. Contactez-nous dès maintenant !';
$_MODULE['<{gamification}blanktheme>view_bcc254b55c4a1babdf1dcb82c207506b'] = 'Téléphone';
$_MODULE['<{gamification}blanktheme>view_4b566d4e657c8c4f133057c73d1c6860'] = 'Téléphone : +33 (0)1 40 18 30 04';
$_MODULE['<{gamification}blanktheme>view_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{gamification}blanktheme>view_7d6d8e6610fd23b684be7e95a6cc5c39'] = 'Remplir le formulaire de contact';
$_MODULE['<{gamification}blanktheme>view_6b6ac7834d96afefbca5677814769109'] = 'Progrès';
$_MODULE['<{gamification}blanktheme>view_82338dd23ce2fd2f6d3606c20f4ee96e'] = 'Pas de badge dans cette section';
$_MODULE['<{gamification}blanktheme>view_bt_a0db49ba470c1c9ae2128c3470339153'] = 'Niveau';
$_MODULE['<{gamification}blanktheme>view_bt_2a0ab6a9172272d54f0d601b0ac157f3'] = 'Devenez un marchand accompli à pas de géant !';
$_MODULE['<{gamification}blanktheme>view_bt_5cf06184f524aad72c14d3ec5d325c56'] = 'Avec toutes les fonctionnalités et avantages proposés par PrestaShop, il est important de rester à jour !';
$_MODULE['<{gamification}blanktheme>view_bt_2c3193c85bb2555c333adfcfb824804a'] = 'A chaque badge décerné, vous gagnez des points et nous vous présentons la prochaine action à réaliser selon votre activité. Vous êtes ainsi guidé(e) vers une boutique parfaitement configurée et optimisée pour votre succès !';
$_MODULE['<{gamification}blanktheme>view_bt_6b766dc388ad21053bde0f8fd95d1e04'] = 'Nous avons défini 3 thèmes essentiels pour évaluer le niveau de développement de votre boutique : les fonctionnalités clés à configurer, vos performances commerciales et votre visibilité à l\'international.';
$_MODULE['<{gamification}blanktheme>view_bt_21dc1cfc9ef1cdfbb665cab323d5e1a9'] = 'Désormais, en cliquant sur un bouton, vous pourrez voir les fonctionnalités d\'amélioration des ventes dont vous ne disposez pas encore. Profitez-en dès maintenant !';
$_MODULE['<{gamification}blanktheme>view_bt_bcc5a331e758a60ad298b4b18a26d0e0'] = 'Notre équipe est là pour vous aider. Contactez-nous dès maintenant !';
$_MODULE['<{gamification}blanktheme>view_bt_bcc254b55c4a1babdf1dcb82c207506b'] = 'Téléphone';
$_MODULE['<{gamification}blanktheme>view_bt_4b566d4e657c8c4f133057c73d1c6860'] = 'Téléphone : +33 (0)1 40 18 30 04';
$_MODULE['<{gamification}blanktheme>view_bt_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{gamification}blanktheme>view_bt_7d6d8e6610fd23b684be7e95a6cc5c39'] = 'Remplir le formulaire de contact';
$_MODULE['<{gamification}blanktheme>view_bt_6b6ac7834d96afefbca5677814769109'] = 'Progrès';
$_MODULE['<{gamification}blanktheme>view_bt_82338dd23ce2fd2f6d3606c20f4ee96e'] = 'Pas de badge dans cette section';
$_MODULE['<{gamification}blanktheme>notification_ca96b4f8d13722aac99da25f94ea1711'] = 'Votre Expertise PrestaShop';
$_MODULE['<{gamification}blanktheme>notification_a0db49ba470c1c9ae2128c3470339153'] = 'Niveau';
$_MODULE['<{gamification}blanktheme>notification_16a1daea9e8873542aec1e820798aa44'] = 'Dernier badge gagné :';
$_MODULE['<{gamification}blanktheme>notification_15377177c0259c6f79341cc57da13f19'] = 'Prochain badge :';
$_MODULE['<{gamification}blanktheme>notification_f8978f781f97e6f851e9c8f7059c37b2'] = 'Voir mon profil complet';
$_MODULE['<{gamification}blanktheme>notification_bt_ca96b4f8d13722aac99da25f94ea1711'] = 'Votre Expertise PrestaShop';
$_MODULE['<{gamification}blanktheme>notification_bt_a0db49ba470c1c9ae2128c3470339153'] = 'Niveau';
$_MODULE['<{gamification}blanktheme>notification_bt_16a1daea9e8873542aec1e820798aa44'] = 'Dernier badge gagné :';
$_MODULE['<{gamification}blanktheme>notification_bt_15377177c0259c6f79341cc57da13f19'] = 'Prochain badge :';
$_MODULE['<{gamification}blanktheme>notification_bt_f8978f781f97e6f851e9c8f7059c37b2'] = 'Voir mon profil complet';
