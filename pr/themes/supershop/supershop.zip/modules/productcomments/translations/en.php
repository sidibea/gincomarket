<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}blanktheme>productcommentcriterion_a09ed6c60eb3213939cecb4c580813cd'] = 'Valid for the entire catalog';
$_MODULE['<{productcomments}blanktheme>productcommentcriterion_467366059d7d7c743a4d0971363a8d66'] = 'Restricted to some categories';
$_MODULE['<{productcomments}blanktheme>productcommentcriterion_772911becd336c843ab09a1d4b4f66c0'] = 'Restricted to some products';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_fd4b5401d4d3c7d32d158bfc1e552f3b'] = 'Please fill your name';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_f88dc17737f7fdd4464b2eb922a8f133'] = 'An error occurred while saving your comment.';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_7fa4a3510dafd0eac6435c19861b2bb7'] = 'Comment posted.';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_f8694a9aae2eb045920f613cfa7f1235'] = 'Awaiting moderator validation.';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_6bf852d9850445291f5e9d4740ac7b50'] = 'Comment text is required.';
$_MODULE['<{productcomments}blanktheme>productcomments-ajax_8aafe254c3e8dceb6425591b322044f2'] = 'You should wait %d seconds before posting a new comment.';
$_MODULE['<{productcomments}blanktheme>productcomments-extra_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Average grade';
$_MODULE['<{productcomments}blanktheme>productcomments-extra_a71a0229e164fecdcde3c4e0f40473fa'] = 'Read user reviews';
$_MODULE['<{productcomments}blanktheme>productcomments-extra_7966126831926ad29c528b239d69f855'] = 'Write your review';
$_MODULE['<{productcomments}blanktheme>productcomments_b91c4e8b229a399a3bc911d352524a9b'] = 'Product Comments';
$_MODULE['<{productcomments}blanktheme>productcomments_a8cd99c74a32936a90127454a02d7500'] = 'Allows users to post reviews and rate products on specific criteria.';
$_MODULE['<{productcomments}blanktheme>productcomments_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{productcomments}blanktheme>productcomments_8a4c4c1ccc2b1c3b89e828e24ef591a8'] = 'The criterion could not be saved';
$_MODULE['<{productcomments}blanktheme>productcomments_1bb54e382f7dbdb260f0aa6b42bb624b'] = 'Criterion deleted';
$_MODULE['<{productcomments}blanktheme>productcomments_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{productcomments}blanktheme>productcomments_cf2fcb22e6342dea54b0cc34bb521752'] = 'All reviews must be validated by an employee';
$_MODULE['<{productcomments}blanktheme>productcomments_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{productcomments}blanktheme>productcomments_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{productcomments}blanktheme>productcomments_4e26bb46aa3f40913ee95cfb1d6c82f9'] = 'Allow guest reviews';
$_MODULE['<{productcomments}blanktheme>productcomments_9dc1140983196141368ceda7565128a8'] = 'Minimum time between 2 reviews from the same user';
$_MODULE['<{productcomments}blanktheme>productcomments_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{productcomments}blanktheme>productcomments_2ec265696a51530949d345239069f0d4'] = 'Reviews waiting for approval';
$_MODULE['<{productcomments}blanktheme>productcomments_655d20c1ca69519ca647684edbb2db35'] = 'High';
$_MODULE['<{productcomments}blanktheme>productcomments_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Medium';
$_MODULE['<{productcomments}blanktheme>productcomments_28d0edd045e05cf5af64e35ae0c4c6ef'] = 'Low';
$_MODULE['<{productcomments}blanktheme>productcomments_eb7d6baeb8bbf339547da7e0d6c5e416'] = 'Reported Reviews';
$_MODULE['<{productcomments}blanktheme>productcomments_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{productcomments}blanktheme>productcomments_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{productcomments}blanktheme>productcomments_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Type';
$_MODULE['<{productcomments}blanktheme>productcomments_ec53a8c4f07baed5d8825072c89799be'] = 'Status';
$_MODULE['<{productcomments}blanktheme>productcomments_8726894930330c61dd2c24ba8265364b'] = 'Add New Criterion';
$_MODULE['<{productcomments}blanktheme>productcomments_7e4bfd4a7edc975e301bb508a8f218f7'] = 'Review Criterions';
$_MODULE['<{productcomments}blanktheme>productcomments_2608831883bb20ab520b70b4350aa23a'] = 'Approved Reviews';
$_MODULE['<{productcomments}blanktheme>productcomments_f8a0aa69f5ce41287f02c2d182306f52'] = 'Review title';
$_MODULE['<{productcomments}blanktheme>productcomments_457dd55184faedb7885afd4009d70163'] = 'Review';
$_MODULE['<{productcomments}blanktheme>productcomments_dda9c06f33071c9b6fc237ee164109d8'] = 'Rating';
$_MODULE['<{productcomments}blanktheme>productcomments_a517747c3d12f99244ae598910d979c5'] = 'Author';
$_MODULE['<{productcomments}blanktheme>productcomments_deb10517653c255364175796ace3553f'] = 'Product';
$_MODULE['<{productcomments}blanktheme>productcomments_0f46dacf1a6ecab8ce1cb97250bb8113'] = 'Time of publication';
$_MODULE['<{productcomments}blanktheme>productcomments_f3d8e91894baa7ee67e0649abcc092ff'] = 'Criterion will be restricted to the following categories';
$_MODULE['<{productcomments}blanktheme>productcomments_d3dc571a8be516766c8124a636290fd9'] = 'Mark the boxes of categories to which this criterion applies.';
$_MODULE['<{productcomments}blanktheme>productcomments_91b442d385b54e1418d81adc34871053'] = 'Selected';
$_MODULE['<{productcomments}blanktheme>productcomments_b56c3bda503a8dc4be356edb0cc31793'] = 'Collapse All';
$_MODULE['<{productcomments}blanktheme>productcomments_5ffd7a335dd836b3373f5ec570a58bdc'] = 'Expand All';
$_MODULE['<{productcomments}blanktheme>productcomments_5e9df908eafa83cb51c0a3720e8348c7'] = 'Check All';
$_MODULE['<{productcomments}blanktheme>productcomments_9747d23c8cc358c5ef78c51e59cd6817'] = 'Uncheck All';
$_MODULE['<{productcomments}blanktheme>productcomments_38fc05fb7f02497ea56b77fe085ffc78'] = 'Add new criterion';
$_MODULE['<{productcomments}blanktheme>productcomments_92a497b6a43b59cce82c604a4c834bb0'] = 'Criterion name';
$_MODULE['<{productcomments}blanktheme>productcomments_bbda28827cde1064b0320cbf6b1890a2'] = 'Application scope of the criterion';
$_MODULE['<{productcomments}blanktheme>productcomments_20089c27bf83463fe32e7d30ed9d8f81'] = 'The criterion will be restricted to the following products';
$_MODULE['<{productcomments}blanktheme>productcomments_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{productcomments}blanktheme>productcomments_6f7351657f795bc1357a53142b1184cc'] = 'Approve';
$_MODULE['<{productcomments}blanktheme>productcomments_ecf74aa77715220b378ec668e75655a8'] = 'Not abusive';
$_MODULE['<{productcomments}blanktheme>productcomments_ab51a81c76d95ddc762194d58ec5db63'] = 'Are you sure that you want to report this comment?';
$_MODULE['<{productcomments}blanktheme>productcomments_9a2ccd41653469a8bd94fbb84b271a14'] = 'Your comment has been added!';
$_MODULE['<{productcomments}blanktheme>productcomments_b20968d9aecd2d075519992e9e2f1ffe'] = 'Your comment has been submitted and will be available once approved by a moderator.';
$_MODULE['<{productcomments}blanktheme>productcomments_186c30cab59f6b64a453778330d4bbf0'] = 'New comment';
$_MODULE['<{productcomments}blanktheme>productcomments_e0aa021e21dddbd6d8cecec71e9cf564'] = 'OK';
$_MODULE['<{productcomments}blanktheme>productcomments_4b3b9db8c9784468094acde0f8bf7071'] = 'Grade';
$_MODULE['<{productcomments}blanktheme>productcomments_b5c82723bd85856358f9a376bc613998'] = '%1$d out of %2$d people found this review useful.';
$_MODULE['<{productcomments}blanktheme>productcomments_39630ad6ee79b8653ea89194cdb45bec'] = 'Was this comment useful to you?';
$_MODULE['<{productcomments}blanktheme>productcomments_a6105c0a611b41b08f1209506350279e'] = 'yes';
$_MODULE['<{productcomments}blanktheme>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'no';
$_MODULE['<{productcomments}blanktheme>productcomments_28b3b1e564a00f572c5d4e21da986d49'] = 'Report abuse';
$_MODULE['<{productcomments}blanktheme>productcomments_7966126831926ad29c528b239d69f855'] = 'Write your review';
$_MODULE['<{productcomments}blanktheme>productcomments_fbe2625bf3673be380d043a4bf873f28'] = 'Be the first to write your review';
$_MODULE['<{productcomments}blanktheme>productcomments_08c7d6f84301ee7d0aab0a5f67edc419'] = 'No customer reviews for the moment.';
$_MODULE['<{productcomments}blanktheme>productcomments_45dacce3e2bc0f7bebde95098b9326a8'] = 'Title for your review';
$_MODULE['<{productcomments}blanktheme>productcomments_3421ad00975533fbbd5f17d2cb568125'] = 'Your review';
$_MODULE['<{productcomments}blanktheme>productcomments_221e705c06e231636fdbccfdd14f4d5c'] = 'Your name';
$_MODULE['<{productcomments}blanktheme>productcomments_70397c4b252a5168c5ec003931cea215'] = 'Required fields';
$_MODULE['<{productcomments}blanktheme>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
$_MODULE['<{productcomments}blanktheme>productcomments_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'or';
$_MODULE['<{productcomments}blanktheme>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{productcomments}blanktheme>productcomments_reviews_e32b7983d3bf98a65e3e96c393867dfa'] = '%s Review(s)';
$_MODULE['<{productcomments}blanktheme>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comments';
$_MODULE['<{productcomments}blanktheme>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'Average';
$_MODULE['<{productcomments}blanktheme>products-comparison_bc976f6c3405523cde61f63a7cbe224b'] = 'view comments';
$_MODULE['<{productcomments}blanktheme>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comments';
$_MODULE['<{productcomments}blanktheme>default_da3e413ae5dde1a6b986203857fb1a59'] = 'Product ID is incorrect';
$_MODULE['<{productcomments}blanktheme>default_7b0bf23ae4079e07a3a4cb4d07e2caef'] = 'Title is incorrect';
$_MODULE['<{productcomments}blanktheme>default_ddbd56de5feb78ef1aaf60401f8c472b'] = 'Comment is incorrect';
$_MODULE['<{productcomments}blanktheme>default_1b1030b6294e9096a7d7c40d83d61872'] = 'Customer name is incorrect';
$_MODULE['<{productcomments}blanktheme>default_26510b8eb6e6053f5e91d51171967ca9'] = 'You must be connected in order to send a comment';
$_MODULE['<{productcomments}blanktheme>default_a201fbadca94d310a1b62407cdc775d5'] = 'You must give a rating';
$_MODULE['<{productcomments}blanktheme>default_dfbe69c6d9568ecb0e65e7b32ed92a3a'] = 'Product not found';
$_MODULE['<{productcomments}blanktheme>default_6d10b2f471e8894d59ae18e01537ece5'] = 'Please wait before posting another comment';
$_MODULE['<{productcomments}blanktheme>default_ba8d7ae5dcadfba739f28a777378f208'] = 'seconds before posting a new comment';
$_MODULE['<{productcomments}blanktheme>productcomments-extra_c31732fda0c6f01c446db7163b214de4'] = 'Write a review';
$_MODULE['<{productcomments}blanktheme>productcomments_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{productcomments}blanktheme>productcomments_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{productcomments}blanktheme>productcomments_c31732fda0c6f01c446db7163b214de4'] = 'Write a review';
$_MODULE['<{productcomments}blanktheme>productcomments_b78a3223503896721cca1303f776159b'] = 'Title';
$_MODULE['<{productcomments}blanktheme>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Comment';
$_MODULE['<{productcomments}blanktheme>products-comparison_5d9acecbb0b55a71dea7403896356001'] = 'View comments';
$_MODULE['<{productcomments}blanktheme>tab_34e80a799d144cfe4af46815e103f017'] = 'Reviews';
