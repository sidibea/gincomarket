<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}blanktheme>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Categories block';
$_MODULE['<{blockcategories}blanktheme>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Adds a block featuring product categories.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blockcategories}blanktheme>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maximum depth: Invalid number.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamic HTML: Invalid choice.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockcategories}blanktheme>blockcategories_1379a6b19242372c1f23cc9adedfcdd6'] = 'Category root';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c6d333d07d30f7b4c31a94bbd510bf88'] = 'Select which category is displayed in the block. The current category is the one the visitor is currently browsing.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_89b278a71f2be5f620307502326587a0'] = 'Home category';
$_MODULE['<{blockcategories}blanktheme>blockcategories_62381fc27e62649a16182a616de3f7ea'] = 'Current category';
$_MODULE['<{blockcategories}blanktheme>blockcategories_52b68aaa602d202c340d9e4e9157f276'] = 'Parent category';
$_MODULE['<{blockcategories}blanktheme>blockcategories_199f6ead1ce5a19131b6b6c568306d81'] = 'Current category, unless it has no subcategories, then parent one';
$_MODULE['<{blockcategories}blanktheme>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Maximum depth';
$_MODULE['<{blockcategories}blanktheme>blockcategories_584d4e251b6f778eda9cfc2fc756b0b0'] = 'Set the maximum depth of category sublevels displayed in this block (0 = infinite).';
$_MODULE['<{blockcategories}blanktheme>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamic';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c10efcaa2a8ff4eedaa3538fff78eb53'] = 'Activate dynamic (animated) mode for category sublevels.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{blockcategories}blanktheme>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{blockcategories}blanktheme>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Sort';
$_MODULE['<{blockcategories}blanktheme>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'By name';
$_MODULE['<{blockcategories}blanktheme>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'By position';
$_MODULE['<{blockcategories}blanktheme>blockcategories_06f1ac65b0a6a548339a38b348e64d79'] = 'Sort order';
$_MODULE['<{blockcategories}blanktheme>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Descending';
$_MODULE['<{blockcategories}blanktheme>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Ascending';
$_MODULE['<{blockcategories}blanktheme>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'How many footer columns would you like?';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockcategories}blanktheme>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{blockcategories}blanktheme>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{blockcategories}blanktheme>blockcategories_admin_c69d9eead832257f587f7c9ec0026fe2'] = 'You can upload a maximum of 3 images.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_admin_acc66e14d297c1bfc20986bf593cb054'] = 'Thumbnails';
