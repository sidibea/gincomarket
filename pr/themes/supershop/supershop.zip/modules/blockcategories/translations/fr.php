<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}blanktheme>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Bloc catégories';
$_MODULE['<{blockcategories}blanktheme>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Ajoute un bloc proposant une navigation au sein de vos catégories de produits';
$_MODULE['<{blockcategories}blanktheme>blockcategories_b15e7271053fe9dd22d80db100179085'] = 'Ce module nécessite d\'être greffé sur une colonne, mais votre thème n\'a pas de colonne.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Profondeur maximum : nombre invalide';
$_MODULE['<{blockcategories}blanktheme>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamic HTML : choix invalide';
$_MODULE['<{blockcategories}blanktheme>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcategories}blanktheme>blockcategories_1379a6b19242372c1f23cc9adedfcdd6'] = 'Catégorie racine';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c6d333d07d30f7b4c31a94bbd510bf88'] = 'Choisissez quelle catégorie afficher dans ce bloc. La catégorie actuelle est celle où le visiteur navigue actuellement.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_89b278a71f2be5f620307502326587a0'] = 'Catégorie d\'accueil';
$_MODULE['<{blockcategories}blanktheme>blockcategories_62381fc27e62649a16182a616de3f7ea'] = 'Catégorie actuelle';
$_MODULE['<{blockcategories}blanktheme>blockcategories_52b68aaa602d202c340d9e4e9157f276'] = 'Catégorie parente';
$_MODULE['<{blockcategories}blanktheme>blockcategories_199f6ead1ce5a19131b6b6c568306d81'] = 'Catégorie actuelle, ou, si elle n\'a pas de sous-catégorie, la catégorie parent';
$_MODULE['<{blockcategories}blanktheme>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Profondeur maximum';
$_MODULE['<{blockcategories}blanktheme>blockcategories_584d4e251b6f778eda9cfc2fc756b0b0'] = 'Détermine la profondeur maximale des catégories affichées (0 = infinie).';
$_MODULE['<{blockcategories}blanktheme>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamique';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c10efcaa2a8ff4eedaa3538fff78eb53'] = 'Activer l\'arbre dynamique (animé) pour les sous-catégories.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockcategories}blanktheme>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockcategories}blanktheme>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Trier';
$_MODULE['<{blockcategories}blanktheme>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'par nom';
$_MODULE['<{blockcategories}blanktheme>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'par position';
$_MODULE['<{blockcategories}blanktheme>blockcategories_06f1ac65b0a6a548339a38b348e64d79'] = 'Sens du tri';
$_MODULE['<{blockcategories}blanktheme>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'décroissant';
$_MODULE['<{blockcategories}blanktheme>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'croissant';
$_MODULE['<{blockcategories}blanktheme>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Nombre de colonnes pour le pied de page';
$_MODULE['<{blockcategories}blanktheme>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcategories}blanktheme>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_MODULE['<{blockcategories}blanktheme>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_MODULE['<{blockcategories}blanktheme>blockcategories_admin_c69d9eead832257f587f7c9ec0026fe2'] = 'Vous pouvez mettre en ligne 3 images au maximum.';
$_MODULE['<{blockcategories}blanktheme>blockcategories_admin_acc66e14d297c1bfc20986bf593cb054'] = 'Miniatures';
