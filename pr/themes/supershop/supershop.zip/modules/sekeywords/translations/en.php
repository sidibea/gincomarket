<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}blanktheme>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Search engine keywords';
$_MODULE['<{sekeywords}blanktheme>sekeywords_8effa630c1740a748801b881acb90fa6'] = 'Displays which keywords have led visitors to your website.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{sekeywords}blanktheme>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identify external search engine keywords';
$_MODULE['<{sekeywords}blanktheme>sekeywords_7acbda50735929f05f6f463e05bc7ead'] = 'This is one of the most common ways of finding a website through a search engine.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_4ad084c0b816ff9278765a00720caf32'] = 'Identifying the most popular keywords entered by your new visitors allows you to see the products you should put in front if you want to achieve better visibility in search engines.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'How does it work?';
$_MODULE['<{sekeywords}blanktheme>sekeywords_ec2184245585ba979912af9e34d738c6'] = 'When a visitor comes to your website, the web server notes the URL of the site he/she comes from. This module then parses the URL, and if it finds a reference to a known search engine, it finds the keywords in it.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_ef79a74a2fd296e19e8cc58cdae91d43'] = 'This module can recognize all the search engines listed in PrestaShop\'s Stats/Search Engine page -- and you can add more!';
$_MODULE['<{sekeywords}blanktheme>sekeywords_dcbcf5d190af87351a16edd5f132c657'] = 'IMPORTANT NOTE: in September 2013, Google chose to encrypt its searches queries using SSL. This means all the referer-based tools in the World (including this one) cannot identify Google keywords anymore.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d keyword matches your query.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d keywords match your query.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filter by keyword';
$_MODULE['<{sekeywords}blanktheme>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'And min occurrences';
$_MODULE['<{sekeywords}blanktheme>sekeywords_9639e32cab248434a17ab32237cb3b71'] = 'Apply';
$_MODULE['<{sekeywords}blanktheme>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Keywords';
$_MODULE['<{sekeywords}blanktheme>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occurrences';
$_MODULE['<{sekeywords}blanktheme>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
$_MODULE['<{sekeywords}blanktheme>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'No keywords';
$_MODULE['<{sekeywords}blanktheme>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = 'Top 10 keywords';
$_MODULE['<{sekeywords}blanktheme>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Others';
