<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}blanktheme>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Mots clés';
$_MODULE['<{sekeywords}blanktheme>sekeywords_8effa630c1740a748801b881acb90fa6'] = 'Affiche les mots clés qui ont mené les visiteurs jusqu\'à votre boutique.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{sekeywords}blanktheme>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identifier les mots-clés par moteurs de recherche externes';
$_MODULE['<{sekeywords}blanktheme>sekeywords_7acbda50735929f05f6f463e05bc7ead'] = 'Il s\'agit d\'une des manières les plus connues de trouver un site web par le biais d\'un moteur de recherche.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_4ad084c0b816ff9278765a00720caf32'] = 'Identifier les mots-clés les plus populaires saisis par vos nouveaux visiteurs vous permet de voir les produits que vous devriez mettre en avant si vous voulez avoir une meilleure visibilité dans les moteurs de recherche.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Comment ça marche ?';
$_MODULE['<{sekeywords}blanktheme>sekeywords_ec2184245585ba979912af9e34d738c6'] = 'Quand un visiteur arrive sur votre site, le serveur web note l\'adresse du site duquel il vient. Ce module analyse ensuite l\'URL, et s\'il y trouve une référence à une moteur de recherche connu, il y trouvera le mot-clé.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_ef79a74a2fd296e19e8cc58cdae91d43'] = 'Ce module peut reconnaître tous les moteurs de recherche listés dans la page Stats/Moteurs de recherche de PrestaShop -- et vous pouvez en ajouter d\'autres !';
$_MODULE['<{sekeywords}blanktheme>sekeywords_dcbcf5d190af87351a16edd5f132c657'] = 'NOTE IMPORTANTE : depuis septembre 2013, Google a choisi de chiffrer ses requêtes à l\'aide de SSL. Cela signifie que tous les outils basés sur les référants du monde (dont celui-ci) ne peuvent plus identifier les mots-clés en provenance de Google.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d mot-clé trouvé pour votre recherche.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d mots-clés trouvés pour votre recherche.';
$_MODULE['<{sekeywords}blanktheme>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filter par mot clé';
$_MODULE['<{sekeywords}blanktheme>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'et minimum d\'occurrences';
$_MODULE['<{sekeywords}blanktheme>sekeywords_9639e32cab248434a17ab32237cb3b71'] = 'Enregistrer';
$_MODULE['<{sekeywords}blanktheme>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Mots clés';
$_MODULE['<{sekeywords}blanktheme>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occurences';
$_MODULE['<{sekeywords}blanktheme>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{sekeywords}blanktheme>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Aucun mot clé';
$_MODULE['<{sekeywords}blanktheme>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = '10 premiers mots-clés';
$_MODULE['<{sekeywords}blanktheme>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
