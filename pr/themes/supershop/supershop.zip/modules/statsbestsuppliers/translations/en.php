<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_b5f5c19c8729b639d4d2a256fcb01a10'] = 'Empty record set returned';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_f5c493141bb4b2508c5938fd9353291a'] = 'Displaying %1$s of %2$s';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_2a0440eec72540c5b30d9199c01f348c'] = 'Quantity sold';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_ea067eb37801c5aab1a1c685eb97d601'] = 'Total paid';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_cc3eb9ba7d0e236f33023a4744d0693a'] = 'Best suppliers';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_37607fc64452028f4d484aa014071934'] = 'Adds a list of the best suppliers to the Stats dashboard.';
$_MODULE['<{statsbestsuppliers}blanktheme>statsbestsuppliers_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
