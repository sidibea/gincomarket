<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'An empty record-set was returned.';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = 'Displaying %1$s of %2$s';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_63d5049791d9d79d86e9a108b0a999ca'] = 'Reference';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Quantity sold';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Price sold';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_25f4b31e8f3baec8b2f266e05af88943'] = 'Quantity sold in a day';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Page views';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_7bd5825a187064017975513b95d7f7de'] = 'Available quantity for sale';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_950cf49f8ca529be64c924f16fcb5404'] = 'Best-selling products';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_15429f69e40860368f6e113e4cba5601'] = 'Adds a list of the best-selling products to the Stats dashboard.';
$_MODULE['<{statsbestproducts}blanktheme>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
