<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_fc02586aa99596947b184a01f43fb4ae'] = 'Contact information block';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'This module will allow you to display your e-store\'s contact information in a customizable block.';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration updated';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Company name';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Phone number';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Contact us';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'Tel';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'Email:';
$_MODULE['<{blockcontactinfos}blanktheme>blockcontactinfos_320abee94a07e976991e4df0d4afb319'] = 'Call us now:';
