<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dashgoals}blanktheme>dashgoals_86f5978d9b80124f509bdb71786e929e'] = 'January';
$_MODULE['<{dashgoals}blanktheme>dashgoals_659e59f062c75f81259d22786d6c44aa'] = 'February';
$_MODULE['<{dashgoals}blanktheme>dashgoals_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'March';
$_MODULE['<{dashgoals}blanktheme>dashgoals_3fcf026bbfffb63fb24b8de9d0446949'] = 'April';
$_MODULE['<{dashgoals}blanktheme>dashgoals_195fbb57ffe7449796d23466085ce6d8'] = 'May';
$_MODULE['<{dashgoals}blanktheme>dashgoals_688937ccaf2a2b0c45a1c9bbba09698d'] = 'June';
$_MODULE['<{dashgoals}blanktheme>dashgoals_1b539f6f34e8503c97f6d3421346b63c'] = 'July';
$_MODULE['<{dashgoals}blanktheme>dashgoals_41ba70891fb6f39327d8ccb9b1dafb84'] = 'August';
$_MODULE['<{dashgoals}blanktheme>dashgoals_cc5d90569e1c8313c2b1c2aab1401174'] = 'September';
$_MODULE['<{dashgoals}blanktheme>dashgoals_eca60ae8611369fe28a02e2ab8c5d12e'] = 'October';
$_MODULE['<{dashgoals}blanktheme>dashgoals_7e823b37564da492ca1629b4732289a8'] = 'November';
$_MODULE['<{dashgoals}blanktheme>dashgoals_82331503174acbae012b2004f6431fa5'] = 'December';
$_MODULE['<{dashgoals}blanktheme>dashgoals_e7935ae6c516d89405ec532359d2d75a'] = 'Traffic';
$_MODULE['<{dashgoals}blanktheme>dashgoals_233d48e63da77b092da350559d2f8382'] = 'visits';
$_MODULE['<{dashgoals}blanktheme>dashgoals_3bb1503332637805beddb73a2dd1fe1b'] = 'Conversion';
$_MODULE['<{dashgoals}blanktheme>dashgoals_71241798130f714cbd2786df3da2cf0b'] = 'Average cart value';
$_MODULE['<{dashgoals}blanktheme>dashgoals_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashgoals}blanktheme>dashgoals_9ac642c5ef334ea05256563f921bb304'] = 'Goal exceeded';
$_MODULE['<{dashgoals}blanktheme>dashgoals_7c103c9bbbaecee07ca898ed65667cbf'] = 'Goal not reached';
$_MODULE['<{dashgoals}blanktheme>dashgoals_eb233580dc419f03df5905f175606e4d'] = 'Goal set:';
$_MODULE['<{dashgoals}blanktheme>config_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{dashgoals}blanktheme>config_e7935ae6c516d89405ec532359d2d75a'] = 'Traffic';
$_MODULE['<{dashgoals}blanktheme>config_e4c3da18c66c0147144767efeb59198f'] = 'Conversion Rate';
$_MODULE['<{dashgoals}blanktheme>config_8c804960da61b637c548c951652b0cac'] = 'Average Cart Value';
$_MODULE['<{dashgoals}blanktheme>config_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashgoals}blanktheme>config_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{dashgoals}blanktheme>dashboard_zone_two_e7935ae6c516d89405ec532359d2d75a'] = 'Traffic';
$_MODULE['<{dashgoals}blanktheme>dashboard_zone_two_3bb1503332637805beddb73a2dd1fe1b'] = 'Conversion';
$_MODULE['<{dashgoals}blanktheme>dashboard_zone_two_8c804960da61b637c548c951652b0cac'] = 'Average Cart Value';
$_MODULE['<{dashgoals}blanktheme>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
