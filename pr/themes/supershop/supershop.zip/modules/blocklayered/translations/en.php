<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklayered}blanktheme>blocklayered-no-products_5c9838becf9bbce28ba90a7426daf171'] = 'There are no products.';
$_MODULE['<{blocklayered}blanktheme>blocklayered_84241e458cdd5162745500a59a3680f3'] = 'Layered navigation block';
$_MODULE['<{blocklayered}blanktheme>blocklayered_2d08fa8e157fe3f1875402cbd98aee1b'] = 'Displays a block with layered navigation filters.';
$_MODULE['<{blocklayered}blanktheme>blocklayered_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blocklayered}blanktheme>blocklayered_b3786b970611c1a3809dd51b630812a7'] = '\"%s\" is not a valid url';
$_MODULE['<{blocklayered}blanktheme>blocklayered_ccc12c5568381293a27db0232877937b'] = 'Filter template name required (cannot be empty)';
$_MODULE['<{blocklayered}blanktheme>blocklayered_8c97e587c1b4e519bec26f3903561da3'] = 'You must select at least one category.';
$_MODULE['<{blocklayered}blanktheme>blocklayered_817c37b9c1f5cd4a450dad384e63e6c7'] = 'Your filter';
$_MODULE['<{blocklayered}blanktheme>blocklayered_3185cefd67b575e582063148e4f15860'] = 'was updated successfully.';
$_MODULE['<{blocklayered}blanktheme>blocklayered_7ccab4d8de5d6b9bb61e99c7bba343ab'] = 'was added successfully.';
$_MODULE['<{blocklayered}blanktheme>blocklayered_fe016d3b990c2a9dd72ab6b45892f2ae'] = 'Settings saved successfully';
$_MODULE['<{blocklayered}blanktheme>blocklayered_0d07af70081a2421e2b2972609d699db'] = 'Filter template deleted, categories updated (reverted to default Filter template).';
$_MODULE['<{blocklayered}blanktheme>blocklayered_491f46aa6101560e9f1e0d55a063231b'] = 'Filter template not found';
$_MODULE['<{blocklayered}blanktheme>blocklayered_fa03eb688ad8aa1db593d33dabd89bad'] = 'Root';
$_MODULE['<{blocklayered}blanktheme>blocklayered_a3868119dc6858db57127fd26e6f9656'] = 'My template - %s';
$_MODULE['<{blocklayered}blanktheme>blocklayered_3601146c4e948c32b6424d2c0a7f0118'] = 'Price';
$_MODULE['<{blocklayered}blanktheme>blocklayered_8c489d0946f66d17d73f26366a4bf620'] = 'Weight';
$_MODULE['<{blocklayered}blanktheme>blocklayered_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_MODULE['<{blocklayered}blanktheme>blocklayered_019d1ca7d50cc54b995f60d456435e87'] = 'Used';
$_MODULE['<{blocklayered}blanktheme>blocklayered_6da03a74721a0554b7143254225cc08a'] = 'Refurbished';
$_MODULE['<{blocklayered}blanktheme>blocklayered_9e2941b3c81256fac10392aaca4ccfde'] = 'Condition';
$_MODULE['<{blocklayered}blanktheme>blocklayered_2d25c72c1b18e562f6654fff8e11711e'] = 'Not available';
$_MODULE['<{blocklayered}blanktheme>blocklayered_fcebe56087b9373f15514831184fa572'] = 'In stock';
$_MODULE['<{blocklayered}blanktheme>blocklayered_faeaec9eda6bc4c8cb6e1a9156a858be'] = 'Availability';
$_MODULE['<{blocklayered}blanktheme>blocklayered_c0bd7654d5b278e65f21cf4e9153fdb4'] = 'Manufacturer';
$_MODULE['<{blocklayered}blanktheme>blocklayered_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{blocklayered}blanktheme>blocklayered_78a5eb43deef9a7b5b9ce157b9d52ac4'] = 'price';
$_MODULE['<{blocklayered}blanktheme>blocklayered_7edabf994b76a00cbc60c95af337db8f'] = 'weight';
$_MODULE['<{blocklayered}blanktheme>blocklayered_32d2e6cd4bb1719c572ef470a3a525b6'] = 'My template %s';
$_MODULE['<{blocklayered}blanktheme>blocklayered_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalog';
$_MODULE['<{blocklayered}blanktheme>blocklayered_1262d1b9fbffb3a8e85ac9e4b449e989'] = 'Enabled filters:';
$_MODULE['<{blocklayered}blanktheme>blocklayered_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{blocklayered}blanktheme>blocklayered_9b569fa0e7896f0e96164b954265eac5'] = '%1$s: %2$s - %3$s';
$_MODULE['<{blocklayered}blanktheme>blocklayered_cf4c997f944b08d0eff346a32272998c'] = '%1$s: %2$s %4$s - %3$s %4$s';
$_MODULE['<{blocklayered}blanktheme>blocklayered_6c03a470e52036813f268bbfa0873529'] = '%1$s: %2$s';
$_MODULE['<{blocklayered}blanktheme>blocklayered_b47b72ddf8a3fa1949a7fb6bb5dbc60c'] = 'No filters';
$_MODULE['<{blocklayered}blanktheme>blocklayered_75954a3c6f2ea54cb9dff249b6b5e8e6'] = 'Range:';
$_MODULE['<{blocklayered}blanktheme>blocklayered_5da618e8e4b89c66fe86e32cdafde142'] = 'From';
$_MODULE['<{blocklayered}blanktheme>blocklayered_01b6e20344b68835c5ed1ddedf20d531'] = 'to';
$_MODULE['<{blocklayered}blanktheme>blocklayered_146ffe2fd9fa5bec3b63b52543793ec7'] = 'Show more';
$_MODULE['<{blocklayered}blanktheme>blocklayered_c74ea6dbff701bfa23819583c52ebd97'] = 'Show less';
$_MODULE['<{blocklayered}blanktheme>blocklayered_8524de963f07201e5c086830d370797f'] = 'Loading...';
$_MODULE['<{blocklayered}blanktheme>add_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{blocklayered}blanktheme>add_51e17eed0057675de4bde1b34206bb12'] = 'New filters template';
$_MODULE['<{blocklayered}blanktheme>add_f8263d99054a4cdb3428196f078fa212'] = 'Template name:';
$_MODULE['<{blocklayered}blanktheme>add_4284fda63513b7da70b5d8f032900580'] = 'Only as a reminder';
$_MODULE['<{blocklayered}blanktheme>add_5d9632c49fb1586eed7123afe2bd806f'] = 'Categories used for this template:';
$_MODULE['<{blocklayered}blanktheme>add_c2d0bf5ad42279c519cdcb4a94eb46b6'] = 'Choose shop association:';
$_MODULE['<{blocklayered}blanktheme>add_60266302eeda2ac9775c3a2036ae25ca'] = 'Filters:';
$_MODULE['<{blocklayered}blanktheme>add_88ec58dbbe7a8b727200696cfca4df3d'] = 'You can drag and drop filters to adjust position';
$_MODULE['<{blocklayered}blanktheme>add_29da3cb8b65298a3e88f5041e9fb9761'] = 'Total filters: %s';
$_MODULE['<{blocklayered}blanktheme>add_a4f642ec06cf1e96bcac483ce1fff234'] = 'Selected filters: %s';
$_MODULE['<{blocklayered}blanktheme>add_cfbc982f8fb7a0cc3abb3c85c795ab41'] = 'Sub-categories filter';
$_MODULE['<{blocklayered}blanktheme>add_379d3973e10dfd90c475060f31b9ae74'] = 'Filter result limit:';
$_MODULE['<{blocklayered}blanktheme>add_af605ea55ee39e54c444f217e346048f'] = 'No limit';
$_MODULE['<{blocklayered}blanktheme>add_284fd1ee8a33e84e08699ba0bbc44943'] = 'Filter style:';
$_MODULE['<{blocklayered}blanktheme>add_4f8222964f9a317cef99dddc23a121bd'] = 'Checkbox';
$_MODULE['<{blocklayered}blanktheme>add_07a9ca8c8228dd3399141e228034fedf'] = 'Radio button';
$_MODULE['<{blocklayered}blanktheme>add_5204077231fc7164e2269e96b584dd95'] = 'Drop-down list';
$_MODULE['<{blocklayered}blanktheme>add_cd50ff1c5332f9920acf8173c4aab425'] = 'Product stock filter';
$_MODULE['<{blocklayered}blanktheme>add_048c1728a0a6cf36f56c9dcdd23d8a14'] = 'Product condition filter';
$_MODULE['<{blocklayered}blanktheme>add_02ecc2cbb645a2b859deba6907334cc8'] = 'Product manufacturer filter';
$_MODULE['<{blocklayered}blanktheme>add_cc72ed9534a489b5d2e5882735bf1364'] = 'Product weight filter (slider)';
$_MODULE['<{blocklayered}blanktheme>add_2d9b9a764fb0be4be10e1b2fce63f561'] = 'Slider';
$_MODULE['<{blocklayered}blanktheme>add_7e650380ef2b9cec2f2a96e6266ca93d'] = 'Inputs area';
$_MODULE['<{blocklayered}blanktheme>add_010359888c6e811caee8e540221f0a21'] = 'List of values';
$_MODULE['<{blocklayered}blanktheme>add_0649bb392812f99ff6b0e2ba160675fa'] = 'Product price filter (slider)';
$_MODULE['<{blocklayered}blanktheme>add_88abab51d4f2e6732b518911bfca58a4'] = 'Attribute group: %1$s (%2$d attributes)';
$_MODULE['<{blocklayered}blanktheme>add_e38ebd31243143bf3f3bd3810b5fc156'] = 'Attribute group: %1$s (%2$d attribute)';
$_MODULE['<{blocklayered}blanktheme>add_ee59f74265cd7f85d0ad30206a1a89b0'] = 'This group will allow user to select a color';
$_MODULE['<{blocklayered}blanktheme>add_7d06fc6f3166570e5d8995088066c0a2'] = 'Feature: %1$s (%2$d values)';
$_MODULE['<{blocklayered}blanktheme>add_57d6fd5e5b9c215d6edac66b67e65773'] = 'Feature: %1$s (%2$d value)';
$_MODULE['<{blocklayered}blanktheme>add_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocklayered}blanktheme>add_18c6120643596bd2626f3b0720b1df3a'] = 'You must select at least one category';
$_MODULE['<{blocklayered}blanktheme>add_dc3f85827350641490287c65c0c4ddf8'] = 'You must select at least one filter';
$_MODULE['<{blocklayered}blanktheme>add_841458c43f0de2d163857cb64435b767'] = 'Selected filters: %s';
$_MODULE['<{blocklayered}blanktheme>add_1.6_51e17eed0057675de4bde1b34206bb12'] = 'New filters template';
$_MODULE['<{blocklayered}blanktheme>add_1.6_f8263d99054a4cdb3428196f078fa212'] = 'Template name:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_4284fda63513b7da70b5d8f032900580'] = 'Only as a reminder';
$_MODULE['<{blocklayered}blanktheme>add_1.6_5d9632c49fb1586eed7123afe2bd806f'] = 'Categories used for this template:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_c2d0bf5ad42279c519cdcb4a94eb46b6'] = 'Choose shop association:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_88ec58dbbe7a8b727200696cfca4df3d'] = 'You can drag and drop filters to adjust position';
$_MODULE['<{blocklayered}blanktheme>add_1.6_60266302eeda2ac9775c3a2036ae25ca'] = 'Filters:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_29da3cb8b65298a3e88f5041e9fb9761'] = 'Total filters: %s';
$_MODULE['<{blocklayered}blanktheme>add_1.6_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>add_1.6_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>add_1.6_cfbc982f8fb7a0cc3abb3c85c795ab41'] = 'Sub-categories filter';
$_MODULE['<{blocklayered}blanktheme>add_1.6_379d3973e10dfd90c475060f31b9ae74'] = 'Filter result limit:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_af605ea55ee39e54c444f217e346048f'] = 'No limit';
$_MODULE['<{blocklayered}blanktheme>add_1.6_284fd1ee8a33e84e08699ba0bbc44943'] = 'Filter style:';
$_MODULE['<{blocklayered}blanktheme>add_1.6_4f8222964f9a317cef99dddc23a121bd'] = 'Checkbox';
$_MODULE['<{blocklayered}blanktheme>add_1.6_07a9ca8c8228dd3399141e228034fedf'] = 'Radio button';
$_MODULE['<{blocklayered}blanktheme>add_1.6_5204077231fc7164e2269e96b584dd95'] = 'Drop-down list';
$_MODULE['<{blocklayered}blanktheme>add_1.6_cd50ff1c5332f9920acf8173c4aab425'] = 'Product stock filter';
$_MODULE['<{blocklayered}blanktheme>add_1.6_048c1728a0a6cf36f56c9dcdd23d8a14'] = 'Product condition filter';
$_MODULE['<{blocklayered}blanktheme>add_1.6_02ecc2cbb645a2b859deba6907334cc8'] = 'Product manufacturer filter';
$_MODULE['<{blocklayered}blanktheme>add_1.6_cc72ed9534a489b5d2e5882735bf1364'] = 'Product weight filter (slider)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_2d9b9a764fb0be4be10e1b2fce63f561'] = 'Slider';
$_MODULE['<{blocklayered}blanktheme>add_1.6_7e650380ef2b9cec2f2a96e6266ca93d'] = 'Inputs area';
$_MODULE['<{blocklayered}blanktheme>add_1.6_010359888c6e811caee8e540221f0a21'] = 'List of values';
$_MODULE['<{blocklayered}blanktheme>add_1.6_0649bb392812f99ff6b0e2ba160675fa'] = 'Product price filter (slider)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_88abab51d4f2e6732b518911bfca58a4'] = 'Attribute group: %1$s (%2$d attributes)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_e38ebd31243143bf3f3bd3810b5fc156'] = 'Attribute group: %1$s (%2$d attribute)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_ee59f74265cd7f85d0ad30206a1a89b0'] = 'This group will allow user to select a color';
$_MODULE['<{blocklayered}blanktheme>add_1.6_7d06fc6f3166570e5d8995088066c0a2'] = 'Feature: %1$s (%2$d values)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_57d6fd5e5b9c215d6edac66b67e65773'] = 'Feature: %1$s (%2$d value)';
$_MODULE['<{blocklayered}blanktheme>add_1.6_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocklayered}blanktheme>add_1.6_18c6120643596bd2626f3b0720b1df3a'] = 'You must select at least one category';
$_MODULE['<{blocklayered}blanktheme>add_1.6_dc3f85827350641490287c65c0c4ddf8'] = 'You must select at least one filter';
$_MODULE['<{blocklayered}blanktheme>view_df2bbc994d10995dcffdf96dbb7acbb1'] = 'Indexes and caches';
$_MODULE['<{blocklayered}blanktheme>view_ad3e7eb269d8ba0ac388267627f45b5a'] = 'Indexing is in progress. Please do not leave this page';
$_MODULE['<{blocklayered}blanktheme>view_5e2420d2318025812dc3e231ddb66b0b'] = 'Index all missing prices';
$_MODULE['<{blocklayered}blanktheme>view_9612e005e96ad32b8830be4d0377e7e6'] = 'Rebuild entire price index';
$_MODULE['<{blocklayered}blanktheme>view_d47f700b6db025d98cae0b340ed847e9'] = 'Build attribute index';
$_MODULE['<{blocklayered}blanktheme>view_341ce134fbec9978d185ff533931b1b3'] = 'Build URL index';
$_MODULE['<{blocklayered}blanktheme>view_53795c3624ae2361363780589aa2aa42'] = 'You can set a cron job that will rebuild price index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_e43b32b88c77e49f06144cd1ffaeba96'] = 'You can set a cron job that will rebuild attribute index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_94f6d9bfb2c36037040b5764e73dca47'] = 'You can set a cron job that will rebuild URL index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_16349835364cf839e6670b0de7da6362'] = 'A nightly rebuild is recommended.';
$_MODULE['<{blocklayered}blanktheme>view_dc83eb2d8601743d8111c5150b93fc71'] = 'Filters templates';
$_MODULE['<{blocklayered}blanktheme>view_2198220edde014ff59601bb2646fed00'] = 'Filters templates (%d)';
$_MODULE['<{blocklayered}blanktheme>view_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklayered}blanktheme>view_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{blocklayered}blanktheme>view_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{blocklayered}blanktheme>view_f7f19392da30e81c3abf433ce7b8ca38'] = 'Created on';
$_MODULE['<{blocklayered}blanktheme>view_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
$_MODULE['<{blocklayered}blanktheme>view_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{blocklayered}blanktheme>view_eb0728df77683ac0f7210ed0d4a18d62'] = 'Do you really want to delete this filter template?';
$_MODULE['<{blocklayered}blanktheme>view_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blocklayered}blanktheme>view_058eeeba77f547f8a9a295a0efd4f6cd'] = 'No filter template found.';
$_MODULE['<{blocklayered}blanktheme>view_49e61d3c2ed19d967aa62a2cc64b5d12'] = 'Add new filters template';
$_MODULE['<{blocklayered}blanktheme>view_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{blocklayered}blanktheme>view_73a0fc0e322b9bc84628ea8d122cba7c'] = 'Hide filter values when no product is matching';
$_MODULE['<{blocklayered}blanktheme>view_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>view_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>view_8531c73de81b9ed94322dda7cf947daa'] = 'Show the number of matching products';
$_MODULE['<{blocklayered}blanktheme>view_ee61c015043c79c1370fc14980dd27b9'] = 'Show products from subcategories';
$_MODULE['<{blocklayered}blanktheme>view_a19399fa42f1ab059401a14b9f13eba1'] = 'Category filter depth (0 for no limits, 1 by default)';
$_MODULE['<{blocklayered}blanktheme>view_3e652bd299bb3ee3d458c0dcc7fd706e'] = 'Use tax to filter price';
$_MODULE['<{blocklayered}blanktheme>view_bb17448782eea2b49a97deac234e9851'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Condition filter';
$_MODULE['<{blocklayered}blanktheme>view_affe7250d1c6cfb3ac0dd054376d4b55'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Availability filter';
$_MODULE['<{blocklayered}blanktheme>view_e1d2fdc12d2e2303a2853e2ba4ff6524'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Manufacturer filter';
$_MODULE['<{blocklayered}blanktheme>view_eaa38d85cd4f2e76882142aad173a1c1'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Category filter';
$_MODULE['<{blocklayered}blanktheme>view_cf565402d32b79d33f626252949a6941'] = 'Save configuration';
$_MODULE['<{blocklayered}blanktheme>view_56fc8142961f1f3e9f9ec0c178881b69'] = '(in progress)';
$_MODULE['<{blocklayered}blanktheme>view_8c83a87ac8ee57d9bcd79d1aa9243bc0'] = 'URL indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_49afa0d9ad5c1f8bf5413b9dc8a252c9'] = 'Attribute indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_9ea5bab5df9a3f3abaa64951daf07e9b'] = 'URL indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_414301b329318b3e916c5b91b0ca9126'] = 'Attribute indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_fa059e7a64ab37fe21b01a220b6c073f'] = 'Price indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_b55143bb1f46af4207ea4b5eb8e844ed'] = 'Price indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_7cf7d150dd287df0a8e17eeb4cf2161d'] = '(in progress, %s products price to index)';
$_MODULE['<{blocklayered}blanktheme>view_8524de963f07201e5c086830d370797f'] = 'Loading...';
$_MODULE['<{blocklayered}blanktheme>view_eb9c805f7590679f0742ba0ea0a3e77f'] = 'You selected -All categories-: all existing filter templates will be deleted. Is it OK?';
$_MODULE['<{blocklayered}blanktheme>view_18c6120643596bd2626f3b0720b1df3a'] = 'You must select at least one category';
$_MODULE['<{blocklayered}blanktheme>view_1.6_df2bbc994d10995dcffdf96dbb7acbb1'] = 'Indexes and caches';
$_MODULE['<{blocklayered}blanktheme>view_1.6_ad3e7eb269d8ba0ac388267627f45b5a'] = 'Indexing is in progress. Please do not leave this page';
$_MODULE['<{blocklayered}blanktheme>view_1.6_5e2420d2318025812dc3e231ddb66b0b'] = 'Index all missing prices';
$_MODULE['<{blocklayered}blanktheme>view_1.6_9612e005e96ad32b8830be4d0377e7e6'] = 'Rebuild entire price index';
$_MODULE['<{blocklayered}blanktheme>view_1.6_d47f700b6db025d98cae0b340ed847e9'] = 'Build attribute index';
$_MODULE['<{blocklayered}blanktheme>view_1.6_341ce134fbec9978d185ff533931b1b3'] = 'Build URL index';
$_MODULE['<{blocklayered}blanktheme>view_1.6_53795c3624ae2361363780589aa2aa42'] = 'You can set a cron job that will rebuild price index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_1.6_e43b32b88c77e49f06144cd1ffaeba96'] = 'You can set a cron job that will rebuild attribute index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_1.6_94f6d9bfb2c36037040b5764e73dca47'] = 'You can set a cron job that will rebuild URL index using the following URL:';
$_MODULE['<{blocklayered}blanktheme>view_1.6_16349835364cf839e6670b0de7da6362'] = 'A nightly rebuild is recommended.';
$_MODULE['<{blocklayered}blanktheme>view_1.6_dc83eb2d8601743d8111c5150b93fc71'] = 'Filters templates';
$_MODULE['<{blocklayered}blanktheme>view_1.6_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklayered}blanktheme>view_1.6_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{blocklayered}blanktheme>view_1.6_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{blocklayered}blanktheme>view_1.6_f7f19392da30e81c3abf433ce7b8ca38'] = 'Created on';
$_MODULE['<{blocklayered}blanktheme>view_1.6_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
$_MODULE['<{blocklayered}blanktheme>view_1.6_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{blocklayered}blanktheme>view_1.6_7761b816560ae2618f40143bf3e585c8'] = 'Do you really want to delete this filter template';
$_MODULE['<{blocklayered}blanktheme>view_1.6_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blocklayered}blanktheme>view_1.6_058eeeba77f547f8a9a295a0efd4f6cd'] = 'No filter template found.';
$_MODULE['<{blocklayered}blanktheme>view_1.6_ae2b83a081959fff7ab2e96f4ce972d1'] = 'Add new template';
$_MODULE['<{blocklayered}blanktheme>view_1.6_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{blocklayered}blanktheme>view_1.6_73a0fc0e322b9bc84628ea8d122cba7c'] = 'Hide filter values when no product is matching';
$_MODULE['<{blocklayered}blanktheme>view_1.6_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>view_1.6_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>view_1.6_8531c73de81b9ed94322dda7cf947daa'] = 'Show the number of matching products';
$_MODULE['<{blocklayered}blanktheme>view_1.6_ee61c015043c79c1370fc14980dd27b9'] = 'Show products from subcategories';
$_MODULE['<{blocklayered}blanktheme>view_1.6_a19399fa42f1ab059401a14b9f13eba1'] = 'Category filter depth (0 for no limits, 1 by default)';
$_MODULE['<{blocklayered}blanktheme>view_1.6_3e652bd299bb3ee3d458c0dcc7fd706e'] = 'Use tax to filter price';
$_MODULE['<{blocklayered}blanktheme>view_1.6_bb17448782eea2b49a97deac234e9851'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Condition filter';
$_MODULE['<{blocklayered}blanktheme>view_1.6_affe7250d1c6cfb3ac0dd054376d4b55'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Availability filter';
$_MODULE['<{blocklayered}blanktheme>view_1.6_e1d2fdc12d2e2303a2853e2ba4ff6524'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Manufacturer filter';
$_MODULE['<{blocklayered}blanktheme>view_1.6_eaa38d85cd4f2e76882142aad173a1c1'] = 'Allow indexing robots (Google, Yahoo!, Bing, etc.) to use the Category filter';
$_MODULE['<{blocklayered}blanktheme>view_1.6_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocklayered}blanktheme>view_1.6_56fc8142961f1f3e9f9ec0c178881b69'] = '(in progress)';
$_MODULE['<{blocklayered}blanktheme>view_1.6_8c83a87ac8ee57d9bcd79d1aa9243bc0'] = 'URL indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_1.6_49afa0d9ad5c1f8bf5413b9dc8a252c9'] = 'Attribute indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_1.6_9ea5bab5df9a3f3abaa64951daf07e9b'] = 'URL indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_1.6_414301b329318b3e916c5b91b0ca9126'] = 'Attribute indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_1.6_fa059e7a64ab37fe21b01a220b6c073f'] = 'Price indexing finished';
$_MODULE['<{blocklayered}blanktheme>view_1.6_b55143bb1f46af4207ea4b5eb8e844ed'] = 'Price indexing failed';
$_MODULE['<{blocklayered}blanktheme>view_1.6_7cf7d150dd287df0a8e17eeb4cf2161d'] = '(in progress, %s products price to index)';
$_MODULE['<{blocklayered}blanktheme>view_1.6_8524de963f07201e5c086830d370797f'] = 'Loading...';
$_MODULE['<{blocklayered}blanktheme>view_1.6_eb9c805f7590679f0742ba0ea0a3e77f'] = 'You selected -All categories-: all existing filter templates will be deleted. Is it OK?';
$_MODULE['<{blocklayered}blanktheme>view_1.6_18c6120643596bd2626f3b0720b1df3a'] = 'You must select at least one category';
$_MODULE['<{blocklayered}blanktheme>attribute_form_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>attribute_form_56275a38c626cbd17c0447d9391b1ab4'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_form_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>attribute_form_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>attribute_form_ad77792302a1f606d8839ebdc6c07e1a'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_form_1.6_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>attribute_form_1.6_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>attribute_form_1.6_56275a38c626cbd17c0447d9391b1ab4'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_form_1.6_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>attribute_form_1.6_ad77792302a1f606d8839ebdc6c07e1a'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_56275a38c626cbd17c0447d9391b1ab4'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_ad77792302a1f606d8839ebdc6c07e1a'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_0bcff42b5aed2b0e4501ed178e4f2510'] = 'Indexable';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_57b5952263e4fd4b8749787283abf85a'] = 'Use this attribute in URL generated by the layered navigation module.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_56275a38c626cbd17c0447d9391b1ab4'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_ad77792302a1f606d8839ebdc6c07e1a'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this attribute. By default, PrestaShop uses the attribute\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_0bcff42b5aed2b0e4501ed178e4f2510'] = 'Indexable';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>attribute_group_form_1.6_57b5952263e4fd4b8749787283abf85a'] = 'Use this attribute in URL generated by the layered navigation module.';
$_MODULE['<{blocklayered}blanktheme>feature_form_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>feature_form_bc40dafe9618ddeea3f01bf6df090432'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this feature. By default, PrestaShop uses the feature\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_form_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>feature_form_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>feature_form_989bf7df8a803fcbf82801b1b0811aac'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this feature. By default, PrestaShop uses the feature\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_form_0bcff42b5aed2b0e4501ed178e4f2510'] = 'Indexable';
$_MODULE['<{blocklayered}blanktheme>feature_form_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>feature_form_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>feature_form_57b5952263e4fd4b8749787283abf85a'] = 'Use this attribute in URL generated by the layered navigation module.';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_bc40dafe9618ddeea3f01bf6df090432'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this feature. By default, PrestaShop uses the feature\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_989bf7df8a803fcbf82801b1b0811aac'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this feature. By default, PrestaShop uses the feature\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_0bcff42b5aed2b0e4501ed178e4f2510'] = 'Indexable';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blocklayered}blanktheme>feature_form_1.6_57b5952263e4fd4b8749787283abf85a'] = 'Use this attribute in URL generated by the layered navigation module.';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_a6c8c88e5e16cba7b9d65ca76dc0a45c'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this feature\'s value. By default, PrestaShop uses the value\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_26029c4864b0b6843acfe55ee14ba807'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this feature\'s value. By default, PrestaShop uses the value\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_1.6_28034a200e932f22b324a4dda1bb9f64'] = 'Invalid characters: ;=#{}_';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_1.6_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_1.6_a6c8c88e5e16cba7b9d65ca76dc0a45c'] = 'When the Layered Navigation Block module is enabled, you can get more detailed URLs by choosing the word that best represent this feature\'s value. By default, PrestaShop uses the value\'s name, but you can change that setting using this field.';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_1.6_9e11e4b371570340ca07913bc4783a7a'] = 'Meta title';
$_MODULE['<{blocklayered}blanktheme>feature_value_form_1.6_26029c4864b0b6843acfe55ee14ba807'] = 'When the Layered Navigation Block module is enabled, you can get more detailed page titles by choosing the word that best represent this feature\'s value. By default, PrestaShop uses the value\'s name, but you can change that setting using this field.';
